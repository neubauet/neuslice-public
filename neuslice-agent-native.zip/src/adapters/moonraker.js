/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/**
 * Moonraker adapter (Klipper via Moonraker REST API)
 *
 * Full feature parity with bambu.js:
 *   connect()                  — verify reachability + discover extruders
 *   printFile(handle, path, opts) — extract gcode from 3mf if needed, upload, start print
 *   getStatus()                — state, progress, layers, temps, filament inventory
 *   cancelJob()                — cancel active print
 *   extractFilamentInventory() — multi-extruder tool inventory with sensor data
 *
 * Klipper/Moonraker does not have an AMS concept — filament selection is
 * handled per-extruder (T0, T1, …). When the customer picks a color/slot
 * in the NeuSlice UI, we use the opts.filament_slot to log which extruder
 * was selected. For single-extruder printers (most Klipper setups), there
 * is only one slot (extruder-0) and no action is needed.
 *
 * Moonraker API reference: https://moonraker.readthedocs.io/en/latest/web_api/
 *
 * Environment variables:
 *   KLIPPER_HOST       required  e.g. http://192.168.1.100:7125
 *                                (also accepted as MOONRAKER_HOST for compat)
 *   KLIPPER_API_KEY    optional  (set in moonraker.conf if trusted_clients is restricted)
 *                                (also accepted as MOONRAKER_API_KEY)
 */

import fetch    from 'node-fetch'
import FormData from 'form-data'
import AdmZip   from 'adm-zip'
import { readFile } from 'node:fs/promises'
import { basename }  from 'node:path'
import log from '../logger.js'

export const name = 'moonraker'

// ── Helpers ──────────────────────────────────────────────────────────────────

function headers(apiKey) {
  return apiKey ? { 'X-Api-Key': apiKey } : {}
}

async function mr_get(host, apiKey, path, timeout_ms = 10_000) {
  const res = await fetch(`${host}${path}`, {
    headers: headers(apiKey),
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) throw new Error(`Moonraker GET ${path} failed: ${res.status}`)
  return res.json()
}

async function mr_post(host, apiKey, path, body, timeout_ms = 30_000) {
  const res = await fetch(`${host}${path}`, {
    method: 'POST',
    headers: { ...headers(apiKey), 'Content-Type': 'application/json' },
    body: body != null ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Moonraker POST ${path} failed: ${res.status} — ${text}`)
  }
  return res.json()
}

/**
 * The NeuSlice slicer wraps gcode in a .3mf ZIP container.
 * Moonraker only accepts raw .gcode files — extract it before upload.
 * Falls back to the original buffer if it's already plain gcode.
 *
 * @returns {{ buffer: Buffer, filename: string }}
 */
function extract_gcode_from_3mf(rawBuffer, originalFilename) {
  try {
    const zip = new AdmZip(rawBuffer)
    const entries = zip.getEntries()
    const gcodeEntry = entries.find(e =>
      e.entryName.toLowerCase().endsWith('.gcode') && !e.isDirectory
    )
    if (gcodeEntry) {
      const gcodeFilename = basename(gcodeEntry.entryName)
      log.info({ original: originalFilename, extracted: gcodeFilename }, 'Klipper: extracted gcode from 3mf ZIP')
      return { buffer: gcodeEntry.getData(), filename: gcodeFilename }
    }
  } catch {
    // Not a ZIP — already plain gcode
  }
  // Use original filename but strip .3mf extension if present
  const filename = originalFilename.replace(/\.3mf$/i, '.gcode')
  return { buffer: rawBuffer, filename }
}

// ── connect ──────────────────────────────────────────────────────────────────

export async function connect(config, opts = {}) {
  const host   = config?.host   ?? process.env.KLIPPER_HOST   ?? process.env.MOONRAKER_HOST
  const apiKey = config?.apiKey ?? process.env.KLIPPER_API_KEY ?? process.env.MOONRAKER_API_KEY ?? ''

  if (!host) throw new Error('Klipper/Moonraker: KLIPPER_HOST is required')

  const info = await mr_get(host, apiKey, '/server/info')
  const klipperState = info?.result?.klippy_state ?? 'unknown'
  if (!['ready', 'startup'].includes(klipperState)) {
    throw new Error(`Klipper state is "${klipperState}" — printer may not be connected`)
  }

  // Discover extruder count for filament inventory and multi-tool support
  const configResult = await mr_get(host, apiKey, '/printer/objects/list')
    .catch(() => ({ result: { objects: [] } }))
  const objects = configResult?.result?.objects ?? []
  const extruderNames = objects.filter(o => /^extruder\d*$/.test(o))
  if (extruderNames.length === 0) extruderNames.push('extruder')  // safe default

  // Fetch filament sensor and config for each extruder so we can surface
  // color/type info in the inventory (requires operator to configure sensors)
  const filamentConfig = await fetch_filament_config(host, apiKey, objects)

  log.info({ host, extruderCount: extruderNames.length, klipperState }, 'Klipper: connected')
  return { host, apiKey, extruderNames, filamentConfig, defaultFilamentTypes: opts.defaultFilamentTypes ?? null }
}

/**
 * Fetch filament sensor + variable store data that enriches extruder inventory.
 * These are best-effort — not all Klipper setups have these configured.
 */
async function fetch_filament_config(host, apiKey, objects) {
  try {
    // Save_variables module lets operators store filament type/color per extruder
    // e.g.: SAVE_VARIABLE VARIABLE=extruder0_filament_type VALUE='"PLA"'
    //       SAVE_VARIABLE VARIABLE=extruder0_filament_color VALUE='"#FF0000"'
    const hasVarFile = objects.includes('save_variables')
    if (!hasVarFile) return {}

    const varsResult = await mr_get(host, apiKey, '/server/database/item?namespace=variables')
    return varsResult?.result?.value ?? {}
  } catch {
    return {}
  }
}

// ── printFile ─────────────────────────────────────────────────────────────────

/**
 * @param {object} handle       - from connect()
 * @param {string} localPath    - path to .gcode.3mf file on disk
 * @param {object} opts
 * @param {string} opts.filament_color  - hex color customer selected (informational for Klipper)
 * @param {string} opts.filament_slot   - slot key e.g. "extruder-0" (selects tool for multi-extruder)
 */
export async function printFile(handle, localPath, opts = {}) {
  const { host, apiKey, extruderNames } = handle
  const { filament_color = null, filament_slot = null } = opts

  // Read the file (3mf wrapper from NeuSlice slicer)
  const rawBuffer = await readFile(localPath)
  const originalFilename = basename(localPath)

  // Moonraker only accepts raw .gcode — extract from 3mf if needed
  const { buffer: gcodeBuffer, filename } = extract_gcode_from_3mf(rawBuffer, originalFilename)

  // For multi-extruder setups: determine which tool (T0, T1, …) to activate.
  // Single-extruder setups (most Klipper) only have extruder-0, nothing to do.
  const toolIndex = resolve_tool_index(filament_slot, extruderNames)
  if (toolIndex > 0) {
    log.info({ filament_slot, toolIndex }, 'Klipper: switching to tool T' + toolIndex)
    // Inject a T<n> command at the start of the gcode by prepending it in memory
    // so the printer starts with the right extruder active.
    // We prepend to the buffer — note this modifies the upload only, not the file on disk.
    const toolChange = Buffer.from(`T${toolIndex}\n`)
    const withToolChange = Buffer.concat([toolChange, gcodeBuffer])
    await upload_and_print(host, apiKey, withToolChange, filename)
  } else {
    await upload_and_print(host, apiKey, gcodeBuffer, filename)
  }

  log.info({ filename, filament_color, filament_slot, toolIndex }, 'Klipper: print started')
}

/**
 * Resolve which tool index to use from a filament_slot key like "extruder-2".
 * Returns 0 (default tool) if slot is null, unrecognised, or only one extruder exists.
 */
function resolve_tool_index(filament_slot, extruderNames) {
  if (!filament_slot) return 0
  const m = filament_slot.match(/^extruder-(\d+)$/)
  if (!m) return 0
  const idx = parseInt(m[1], 10)
  // Bounds check — don't request a tool the printer doesn't have
  if (idx >= (extruderNames?.length ?? 1)) {
    log.warn({ filament_slot, extruderCount: extruderNames?.length }, 'Klipper: requested tool index out of range — defaulting to T0')
    return 0
  }
  return idx
}

async function upload_and_print(host, apiKey, buffer, filename) {
  // Upload gcode to Moonraker's gcodes virtual filesystem
  const form = new FormData()
  form.append('file', buffer, { filename, contentType: 'application/octet-stream' })
  form.append('root', 'gcodes')

  const uploadRes = await fetch(`${host}/server/files/upload`, {
    method: 'POST',
    headers: { ...headers(apiKey), ...form.getHeaders() },
    body: form,
  })
  if (!uploadRes.ok) {
    const text = await uploadRes.text()
    throw new Error(`Klipper upload failed: ${uploadRes.status} — ${text}`)
  }

  // Start the print
  await mr_post(host, apiKey, '/printer/print/start', { filename })
}

// ── extractFilamentInventory ──────────────────────────────────────────────────
//
// Builds a slot list consistent with the Bambu AMS inventory shape so the
// NeuSlice UI can show per-extruder filament info for multi-tool Klipper setups.
// Single-extruder printers get one slot: extruder-0.
//
// Color and type come from:
//   1. Moonraker save_variables namespace (operator-configured via macros)
//   2. Filament switch/motion sensor detection (runout only, no color/type)
//   3. Graceful null defaults when nothing is configured

export function extractFilamentInventory(extruderData, configData) {
  const slots = []
  const vars  = configData ?? {}

  for (const [key, vals] of Object.entries(extruderData ?? {})) {
    if (!/^extruder\d*$/.test(key)) continue
    const index = key === 'extruder' ? 0 : parseInt(key.replace('extruder', ''), 10)

    // Filament runout sensor for this extruder (optional, operator-configured)
    const sensorKey = `filament_switch_sensor extruder${index}_sensor`
    const motionKey = `filament_motion_sensor extruder${index}_sensor`
    const sensorData = configData?.[sensorKey] ?? configData?.[motionKey] ?? {}
    const filament_detected = sensorData.filament_detected

    // Operator-stored filament metadata via SAVE_VARIABLE macros (optional)
    const stored_type  = vars[`extruder${index}_filament_type`]  ?? null
    const stored_color = vars[`extruder${index}_filament_color`] ?? null
    const stored_brand = vars[`extruder${index}_filament_brand`] ?? null

    slots.push({
      slot:        `extruder-${index}`,
      type:        stored_type,
      color:       stored_color,
      color_name:  null,   // Klipper has no color-name concept
      brand:       stored_brand,
      // If sensor is present and detects no filament, show 0% — otherwise null (unknown)
      remain_pct:  filament_detected === false ? 0 : null,
      temp_min:    vals.min_extrude_temp ?? null,
      temp_max:    vals.max_temp         ?? null,
    })
  }

  return slots
}

// ── getStatus ─────────────────────────────────────────────────────────────────

export async function getStatus(handle) {
  const { host, apiKey, extruderNames, filamentConfig } = handle

  // Build a single query for everything we need
  const extruderQuery = (extruderNames ?? ['extruder']).join('&')
  const queryPath =
    `/printer/objects/query?print_stats&display_status&heater_bed&${extruderQuery}`

  const data   = await mr_get(host, apiKey, queryPath)
  const status = data?.result?.status ?? {}

  const print_stats    = status.print_stats    ?? {}
  const display_status = status.display_status ?? {}
  const heater_bed     = status.heater_bed     ?? {}

  const state_raw    = (print_stats.state ?? '').toLowerCase()
  const progress_pct = Math.round((display_status.progress ?? 0) * 100)
  const layer_num    = print_stats.info?.current_layer ?? 0
  const total_layers = print_stats.info?.total_layer   ?? 0

  // Estimate remaining time from elapsed duration + progress
  // Moonraker exposes print_duration (active printing time, excludes pauses)
  const print_duration = print_stats.print_duration ?? 0
  let remaining_time_s = 0
  if (progress_pct > 0 && progress_pct < 100) {
    const total_estimated = print_duration / (progress_pct / 100)
    remaining_time_s = Math.max(0, Math.round(total_estimated - print_duration))
  }

  // Temperatures — primary extruder + bed
  const primaryExtruder = status[(extruderNames ?? ['extruder'])[0]] ?? status.extruder ?? {}
  const temperatures = {
    bed:           heater_bed.temperature      ?? 0,
    bed_target:    heater_bed.target           ?? 0,
    nozzle:        primaryExtruder.temperature ?? 0,
    nozzle_target: primaryExtruder.target      ?? 0,
  }

  // Filament inventory from all extruder objects + stored variable config
  const extruderData = {}
  for (const eName of (extruderNames ?? ['extruder'])) {
    if (status[eName]) extruderData[eName] = status[eName]
  }
  const filament_inventory_raw = extractFilamentInventory(extruderData, { ...status, ...(filamentConfig ?? {}) })

  // Overlay default_filament_types from the node's stored config when the agent
  // cannot detect type (Klipper without save_variables macros).
  // Only fills slots where type is null — never overrides a detected type.
  const default_types = handle.defaultFilamentTypes
  const filament_inventory = (Array.isArray(default_types) && default_types.length > 0)
    ? filament_inventory_raw.map((slot, i) => ({
        ...slot,
        type: slot.type ?? default_types[i] ?? default_types[0] ?? null,
      }))
    : filament_inventory_raw

  // ── State mapping ──────────────────────────────────────────────────────
  if (state_raw === 'printing' || state_raw === 'paused') {
    // Stale-data guard: Moonraker sometimes holds a 100%/complete-looking
    // state briefly after a print finishes before transitioning to 'complete'.
    // Detect this and report idle so the agent doesn't get stuck in polling.
    const looks_stale = progress_pct >= 100 && total_layers > 0 && layer_num >= total_layers
    if (looks_stale) {
      return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
    }

    return {
      state: state_raw === 'paused' ? 'paused' : 'printing',
      progress_pct,
      layer_num,
      total_layers,
      remaining_time_s,
      temperatures,
      filament_inventory,
    }
  }

  if (state_raw === 'complete' || state_raw === 'standby' || state_raw === '') {
    return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  if (state_raw === 'error') {
    // Surface the Klipper error message for diagnostics
    const message = print_stats.message ?? 'unknown error'
    log.warn({ host, klipper_error: message }, 'Klipper reported error state')
    return { state: 'error', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory, error_message: message }
  }

  if (state_raw === 'cancelled') {
    // Cancelled by user/server -- printer is free, map to idle so the agent
    // marks itself available again and doesn't show as unavailable.
    return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  // startup / shutdown / unknown — report idle so agent waits for Klipper to come up
  return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
}

// ── cancelJob ─────────────────────────────────────────────────────────────────

export async function cancelJob(handle) {
  const { host, apiKey } = handle
  await mr_post(host, apiKey, '/printer/print/cancel', null)
  log.info({ host }, 'Klipper: print cancelled')
}
