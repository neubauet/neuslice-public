/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/**
 * Moonraker adapter (Klipper via Moonraker REST API)
 *
 * Full feature parity with bambu.js:
 *   connect()                  — verify reachability + discover extruders
 *   printFile(handle, path, opts) — extract gcode from 3mf if needed, upload, start print
 *   getStatus()                — state, progress, layers, temps, filament inventory
 *   cancelJob()                — cancel active print
 *   extractFilamentInventory() — multi-extruder tool inventory with sensor data
 *
 * Klipper/Moonraker does not have an AMS concept — filament selection is
 * handled per-extruder (T0, T1, …). When the customer picks a color/slot
 * in the NeuSlice UI, we use the opts.filament_slot to log which extruder
 * was selected. For single-extruder printers (most Klipper setups), there
 * is only one slot (extruder-0) and no action is needed.
 *
 * Moonraker API reference: https://moonraker.readthedocs.io/en/latest/web_api/
 *
 * Environment variables:
 *   KLIPPER_HOST       required  e.g. http://192.168.1.100:7125
 *                                (also accepted as MOONRAKER_HOST for compat)
 *   KLIPPER_API_KEY    optional  (set in moonraker.conf if trusted_clients is restricted)
 *                                (also accepted as MOONRAKER_API_KEY)
 */

import fetch    from 'node-fetch'
import FormData from 'form-data'
import AdmZip   from 'adm-zip'
import { readFile } from 'node:fs/promises'
import { basename }  from 'node:path'
import log from '../logger.js'

export const name = 'moonraker'

/**
 * Publish Creality CFS lanes as filament slots.
 *
 * Still off by default, but the reason has changed. It was off because lane
 * selection did not exist, so publishing lanes could only ever produce a silent
 * wrong-colour print. printFile() now retargets the start block's tool change,
 * which is proven against real Creality Print output but has never run on the
 * physical machine.
 *
 * What remains before flipping this on is a supervised print on the one K2 we
 * have access to — and it belongs to someone else, so a wrong-colour print
 * costs more than a failed job would. Slice-inspect first: confirm the uploaded
 * g-code carries the expected T<n>, then print.
 *
 * Read per-node from the node's own config (`cfs_inventory`), because one agent
 * can serve several printers and only some of them have a CFS — a process-wide
 * env var would switch all of them at once. This constant is only the fallback
 * for a single-node install with no config entry.
 */
const CFS_ENABLED_FALLBACK = process.env.NEUSLICE_CFS_INVENTORY === '1'

/**
 * Decide whether this node publishes CFS lanes. Most authoritative first:
 *
 *   1. opts.cfsInventory    — the node doc, fetched from the backend at boot.
 *      This is the remote switch, and the reason it wins: turning lanes OFF for
 *      a misbehaving printer must not be defeatable by a stale env var on the
 *      owner's machine, which we cannot reach.
 *   2. config.cfs_inventory — the local printers.d/ entry, for an operator
 *      working directly on the box.
 *   3. the env var          — single-node install fallback.
 *
 * `??` at every step, never `||`: an explicit `false` is a decision and must
 * not fall through to a lower-priority source that says true.
 */
export function resolveCfsEnabled(opts, config, fallback = CFS_ENABLED_FALLBACK) {
  return opts?.cfsInventory ?? config?.cfs_inventory ?? fallback
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function headers(apiKey) {
  return apiKey ? { 'X-Api-Key': apiKey } : {}
}

async function mr_get(host, apiKey, path, timeout_ms = 10_000) {
  const res = await fetch(`${host}${path}`, {
    headers: headers(apiKey),
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) throw new Error(`Moonraker GET ${path} failed: ${res.status}`)
  return res.json()
}

async function mr_post(host, apiKey, path, body, timeout_ms = 30_000) {
  const res = await fetch(`${host}${path}`, {
    method: 'POST',
    headers: { ...headers(apiKey), 'Content-Type': 'application/json' },
    body: body != null ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Moonraker POST ${path} failed: ${res.status} — ${text}`)
  }
  return res.json()
}

/**
 * The NeuSlice slicer wraps gcode in a .3mf ZIP container.
 * Moonraker only accepts raw .gcode files — extract it before upload.
 * Falls back to the original buffer if it's already plain gcode.
 *
 * @returns {{ buffer: Buffer, filename: string }}
 */
function extract_gcode_from_3mf(rawBuffer, originalFilename) {
  try {
    const zip = new AdmZip(rawBuffer)
    const entries = zip.getEntries()
    const gcodeEntry = entries.find(e =>
      e.entryName.toLowerCase().endsWith('.gcode') && !e.isDirectory
    )
    if (gcodeEntry) {
      const gcodeFilename = basename(gcodeEntry.entryName)
      log.info({ original: originalFilename, extracted: gcodeFilename }, 'Klipper: extracted gcode from 3mf ZIP')
      return { buffer: gcodeEntry.getData(), filename: gcodeFilename }
    }
  } catch {
    // Not a ZIP — already plain gcode
  }
  // Use original filename but strip .3mf extension if present
  const filename = originalFilename.replace(/\.3mf$/i, '.gcode')
  return { buffer: rawBuffer, filename }
}

// ── connect ──────────────────────────────────────────────────────────────────

export async function connect(config, opts = {}) {
  const host   = config?.host   ?? process.env.KLIPPER_HOST   ?? process.env.MOONRAKER_HOST
  const apiKey = config?.apiKey ?? process.env.KLIPPER_API_KEY ?? process.env.MOONRAKER_API_KEY ?? ''

  if (!host) throw new Error('Klipper/Moonraker: KLIPPER_HOST is required')

  const info = await mr_get(host, apiKey, '/server/info')
  const klipperState = info?.result?.klippy_state ?? 'unknown'
  if (!['ready', 'startup'].includes(klipperState)) {
    throw new Error(`Klipper state is "${klipperState}" — printer may not be connected`)
  }

  // Discover extruder count for filament inventory and multi-tool support
  const configResult = await mr_get(host, apiKey, '/printer/objects/list')
    .catch(() => ({ result: { objects: [] } }))
  const objects = configResult?.result?.objects ?? []
  const extruderNames = objects.filter(o => /^extruder\d*$/.test(o))
  if (extruderNames.length === 0) extruderNames.push('extruder')  // safe default

  // Fetch filament sensor and config for each extruder so we can surface
  // color/type info in the inventory (requires operator to configure sensors)
  const filamentConfig = await fetch_filament_config(host, apiKey, objects)

  // Creality's fork publishes its multi-lane filament system as `box`.
  const hasCfs = objects.includes('box')

  const cfsEnabled = resolveCfsEnabled(opts, config)

  log.info(
    { host, extruderCount: extruderNames.length, klipperState, hasCfs, cfsEnabled },
    'Klipper: connected',
  )
  if (hasCfs && !cfsEnabled) {
    log.warn({ host },
      'Klipper: a Creality CFS is attached but lane inventory is disabled — reporting extruder slots only. ' +
      'Set cfs_inventory on the node config (or NEUSLICE_CFS_INVENTORY=1) to enable it.')
  }

  return {
    host, apiKey, extruderNames, filamentConfig, hasCfs, cfsEnabled,
    defaultFilamentTypes: opts.defaultFilamentTypes ?? null,
  }
}

/**
 * Apply refreshed node settings to a live handle, without reconnecting.
 *
 * Called on the agent's periodic opts refresh. Before this existed, the CFS
 * gate was read once at process start, which made it a boot parameter wearing a
 * switch's clothing: flipping it in the dashboard did nothing until someone
 * restarted the container — including flipping it OFF, which is the direction
 * that matters when a printer is misbehaving and we have no shell access to it.
 *
 * Only mutates what actually changed, so the log line is a real event.
 *
 * @param {object} handle from connect()
 * @param {object} opts   from parse_node_opts()
 */
export function applyNodeOpts(handle, opts) {
  if (!handle || !opts) return handle

  if (typeof opts.cfsInventory === 'boolean' && opts.cfsInventory !== handle.cfsEnabled) {
    handle.cfsEnabled = opts.cfsInventory
    log.info({ cfsEnabled: handle.cfsEnabled, hasCfs: handle.hasCfs },
      `Klipper: CFS lane inventory ${handle.cfsEnabled ? 'enabled' : 'disabled'} by node config`)
  }

  if (Array.isArray(opts.defaultFilamentTypes) && opts.defaultFilamentTypes.length > 0) {
    handle.defaultFilamentTypes = opts.defaultFilamentTypes
  }

  return handle
}

/**
 * Fetch filament sensor + variable store data that enriches extruder inventory.
 * These are best-effort — not all Klipper setups have these configured.
 */
async function fetch_filament_config(host, apiKey, objects) {
  try {
    // Save_variables module lets operators store filament type/color per extruder
    // e.g.: SAVE_VARIABLE VARIABLE=extruder0_filament_type VALUE='"PLA"'
    //       SAVE_VARIABLE VARIABLE=extruder0_filament_color VALUE='"#FF0000"'
    const hasVarFile = objects.includes('save_variables')
    if (!hasVarFile) return {}

    const varsResult = await mr_get(host, apiKey, '/server/database/item?namespace=variables')
    return varsResult?.result?.value ?? {}
  } catch {
    return {}
  }
}

// ── printFile ─────────────────────────────────────────────────────────────────

/**
 * @param {object} handle       - from connect()
 * @param {string} localPath    - path to .gcode.3mf file on disk
 * @param {object} opts
 * @param {string} opts.filament_color  - hex color customer selected (informational for Klipper)
 * @param {string} opts.filament_slot   - slot key e.g. "extruder-0" (selects tool for multi-extruder)
 * @param {string[]} opts.filament_slots - multi-filament: one slot key per g-code
 *   filament slot, in slot order. Takes precedence over the single
 *   filament_slot/filament_color pair, which stays the single-colour path
 *   unchanged. Only CFS lane keys are accepted here; see remapTools.
 */
export async function printFile(handle, localPath, opts = {}) {
  const { host, apiKey, extruderNames, hasCfs } = handle
  const { filament_color = null, filament_slot = null, filament_slots = null } = opts

  // Read the file (3mf wrapper from NeuSlice slicer)
  const rawBuffer = await readFile(localPath)
  const originalFilename = basename(localPath)

  // Moonraker only accepts raw .gcode — extract from 3mf if needed
  const { buffer: gcodeBuffer, filename } = extract_gcode_from_3mf(rawBuffer, originalFilename)

  // ── Multi-filament: the whole mapping, not one tool ────────────────────────
  // The backend sends filament_slots only for a job its slice job recorded as
  // multi-colour, and only after validating one distinct loaded slot per file
  // filament. A single-element array cannot reach here (multi-colour implies
  // filament_count > 1), so anything shorter falls through to the single path.
  if (Array.isArray(filament_slots) && filament_slots.length > 1) {
    const lanes = filament_slots.map(cfsSlotKeyToLaneIndex)
    if (lanes.some(l => l === null)) {
      // Every other slot-key family reaching here would be a printer we have not
      // built multi-material for. Printing anyway would run the whole model on
      // whichever lane happens to be threaded — a silent single-colour print of
      // a job the customer paid a multi-colour price for.
      throw new Error(
        `Klipper: multi-filament job carries slot keys this printer cannot resolve ` +
        `(${filament_slots.join(', ')}). Only Creality CFS lanes (cfs-<1-4>-<A-D>) are ` +
        `supported for multi-material; refusing rather than printing it in one colour.`,
      )
    }

    // The mapping was validated against this node's published inventory, which
    // only carries cfs-* keys when a unit is actually attached — so this should
    // be unreachable. It is here because the failure it catches (a mapping that
    // outlived the unit being unplugged) selects lanes the machine does not
    // have, and Klipper answers an unknown tool by carrying on rather than
    // stopping.
    if (!hasCfs) {
      throw new Error(
        'Klipper: multi-filament job routed to a printer with no CFS attached. ' +
        'Refusing rather than selecting lanes the machine does not have.',
      )
    }

    const outgoing = remapTools(gcodeBuffer, lanes)
    await upload_and_print(host, apiKey, outgoing, filename)
    log.info({ filename, filament_slots, lanes, tools: lanes.length },
      'Klipper: multi-filament print started')
    return
  }

  // Which tool the print must start on. Two sources, one mechanism:
  //   - a CFS lane ("cfs-1-D") → the flat lane index the printer resolves T<n>
  //     against; confirmed against Creality Print output, which selects a lane
  //     with a bare T<n> and nothing else.
  //   - a second extruder ("extruder-1") → that extruder's index.
  const cfsLane   = cfsSlotKeyToLane(filament_slot)
  const toolIndex = cfsLane
    ? cfsSlotKeyToLaneIndex(filament_slot)
    : resolve_tool_index(filament_slot, extruderNames)

  let outgoing = gcodeBuffer
  if (toolIndex > 0) {
    log.info({ filament_slot, cfsLane, toolIndex }, `Klipper: targeting tool T${toolIndex}`)
    // Rewrite the start block's tool change. Prepending a T<n> here used to be
    // the implementation and never worked — the profile's own tool change runs
    // afterwards and overrides it, so every job silently printed on T0.
    outgoing = retargetInitialTool(gcodeBuffer, toolIndex)
  }

  await upload_and_print(host, apiKey, outgoing, filename)

  log.info({ filename, filament_color, filament_slot, cfsLane, toolIndex }, 'Klipper: print started')
}

/**
 * Point a single-material g-code at a different tool.
 *
 * The slicer already emits exactly one tool change, from the profile's
 * machine_start_gcode (`T[initial_no_support_extruder]`, which resolves to T0
 * for a one-filament roster). Prepending another T<n> ahead of the file does
 * NOT work: the start block's own tool change runs afterwards and wins. The
 * only thing that changes the tool is rewriting that line.
 *
 * Refuses anything it cannot reason about rather than guessing, because every
 * failure here is a wrong-colour print on a paid job:
 *   - zero tool changes  → nothing to retarget; the profile is not what we think
 *   - two or more, mixed → a genuine multi-material file; rewriting the first
 *                          line would corrupt the colour sequence
 *   - two or more, same  → a machine start block (Snapmaker U1: two bare T0s in
 *                          its Klipper prep). Not multi-material, but the tool
 *                          cannot be moved one line at a time either, so a U1
 *                          prints on T0 and the owner loads tool 1.
 *
 * @param {Buffer} gcode      raw g-code bytes
 * @param {number} toolIndex  0-based tool to select
 * @returns {Buffer} rewritten g-code, byte-identical apart from that one line
 * @throws if the file does not contain exactly one tool change
 */
export function retargetInitialTool(gcode, toolIndex) {
  const text  = gcode.toString('utf8')
  // Tool changes sit on their own line. Tolerate trailing comments and CRLF,
  // but not an inline T within another command.
  const TOOL_LINE = /^T(\d+)[ \t]*(;.*)?$/gm
  const matches = [...text.matchAll(TOOL_LINE)]

  if (matches.length !== 1) {
    // Distinguish the two ways "more than one" happens, because they need
    // opposite fixes and the old message asserted the wrong one for a
    // toolchanger. A Snapmaker U1 slice carries TWO bare T0 lines and is not
    // multi-material at all: both sit in the machine's own start block (its
    // Klipper prep — bed foreign-object check, then rough-home/nozzle-clean),
    // and every one of them would have to move together to change the tool.
    // Retargeting only the first would run half the prep on the wrong toolhead,
    // so this refuses until that is designed and proven on a real U1.
    const distinct = new Set(matches.map(m => m[1]))
    const looks_like_start_block = matches.length > 1 && distinct.size === 1
    throw new Error(
      `Klipper: expected exactly one tool change to retarget, found ${matches.length}. ` +
      (matches.length === 0
        ? 'The sliced g-code has no tool change — refusing rather than printing on the loaded lane.'
        : looks_like_start_block
          ? `All ${matches.length} select the same tool (T${[...distinct][0]}), so this is a machine start ` +
            'block rather than a colour sequence — a toolchanger (e.g. Snapmaker U1) whose tool ' +
            'cannot be reassigned one line at a time. Load the filament in tool 1 and print on T0.'
          : 'This looks like a multi-material file; refusing rather than corrupting the colour sequence.'),
    )
  }

  const [full, current, comment] = matches[0]
  const replacement = `T${toolIndex}${comment ? ' ' + comment : ''}`
  if (Number(current) === toolIndex) return gcode   // already correct, don't touch the bytes

  const at = matches[0].index
  return Buffer.concat([
    Buffer.from(text.slice(0, at), 'utf8'),
    Buffer.from(replacement, 'utf8'),
    Buffer.from(text.slice(at + full.length), 'utf8'),
  ])
}

/**
 * Point a multi-material g-code at the CFS lanes the customer chose.
 *
 * The Bambu path does this at dispatch and never touches the file: one g-code,
 * plus an `ams_mapping` array in the print command naming the tray that feeds
 * each filament slot. A CFS has no such channel — `T<n>` IS the lane (T0 = bay 1
 * lane A, T3 = bay 1 lane D, T4 = bay 2 lane A), confirmed against a 4-colour
 * Creality Print reference that consumed all four lanes with bare T0..T3 and no
 * M8200 or BOX_* macro anywhere in it. So the customer's choice has to be
 * written INTO the g-code, and this is where that happens.
 *
 * The slicer stays deliberately lane-blind: it slices an N-filament file into
 * tools T0..T(N-1) in the FILE's own slot order, whatever lanes were picked.
 * This applies the permutation. Purge survives untouched, because flush volumes
 * are computed per colour PAIR and a permutation preserves pairs — slot 1 → slot
 * 2 costs the same flush whichever bays those two spools sit in.
 *
 * Refuses rather than guessing, on the same grounds as retargetInitialTool:
 * every failure here is a wrong-colour print on a job someone has paid for, and
 * a wrong lane is invisible until the part comes off the bed.
 *
 * @param {Buffer}   gcode       raw g-code bytes
 * @param {number[]} laneIndices 0-based lane per filament slot, in slot order —
 *   laneIndices[i] is the lane the g-code's T<i> must become
 * @returns {Buffer} rewritten g-code, byte-identical apart from the tool lines
 * @throws if the mapping is unusable, or the g-code is not the shape we sliced
 */
export function remapTools(gcode, laneIndices) {
  if (!Array.isArray(laneIndices) || laneIndices.length === 0) {
    throw new Error('Klipper: remapTools needs one lane index per filament slot')
  }
  if (!laneIndices.every(n => Number.isInteger(n) && n >= 0)) {
    throw new Error(`Klipper: lane indices must be non-negative integers, got [${laneIndices.join(', ')}]`)
  }
  // Two filament slots on one lane prints both in that lane's colour with
  // nothing anywhere reporting a problem. The backend already refuses a mapping
  // that reuses a slot; this is the same rule, held closest to the printer.
  if (new Set(laneIndices).size !== laneIndices.length) {
    throw new Error(
      `Klipper: two filaments map to the same CFS lane ([${laneIndices.join(', ')}]) — ` +
      'refusing rather than printing them both in one colour.',
    )
  }

  const text = gcode.toString('utf8')

  // A tool index used as a PARAMETER of another command (`M104 T1 S220`) would
  // survive this rewrite still pointing at the pre-remap slot. We have never
  // seen one in Creality output, which is exactly why an unannounced one has to
  // stop the job rather than pass through. Only G/M lines are scanned, and only
  // up to their comment: a Klipper macro line such as
  // `EXCLUDE_OBJECT_DEFINE NAME=T1` carries a user-supplied object name, not a
  // tool index, and must not be mistaken for one.
  for (const m of text.matchAll(/^[ \t]*[GM]\d+([^\n;]*)/gm)) {
    if (/(?:^|[ \t])T\d+\b/.test(m[1])) {
      throw new Error(
        'Klipper: the sliced g-code selects a tool inside another command ' +
        `("${m[0].trim().slice(0, 60)}"), which this remap would leave pointing at the ` +
        'wrong lane. Refusing rather than printing part of the model in the wrong colour.',
      )
    }
  }

  const TOOL_LINE = /^T(\d+)[ \t]*(;.*)?$/gm
  const matches = [...text.matchAll(TOOL_LINE)]
  if (matches.length === 0) {
    throw new Error(
      'Klipper: this is a multi-filament job but its g-code has no tool change at all. ' +
      'The slice did not come out multi-material; refusing rather than printing it in one colour.',
    )
  }

  // Every tool the file selects must be a slot the mapping covers. A higher one
  // means the g-code and the mapping came from different files. The reverse —
  // a mapped slot the plate never actually uses — is fine and left alone.
  const seen = [...new Set(matches.map(m => Number(m[1])))].sort((a, b) => a - b)
  const uncovered = seen.filter(t => t >= laneIndices.length)
  if (uncovered.length > 0) {
    throw new Error(
      `Klipper: the g-code selects T${uncovered.join(', T')} but this job maps only ` +
      `${laneIndices.length} filament slot${laneIndices.length === 1 ? '' : 's'}. ` +
      'The mapping does not belong to this file; refusing.',
    )
  }

  // Identity — the customer's lanes already match the slice. Leave the bytes
  // alone so the container's md5 stays valid and there is nothing to get wrong.
  if (seen.every(t => laneIndices[t] === t)) return gcode

  return Buffer.from(
    text.replace(TOOL_LINE, (_full, current, comment) =>
      `T${laneIndices[Number(current)]}${comment ? ' ' + comment : ''}`),
    'utf8',
  )
}

/**
 * Resolve which tool index to use from a filament_slot key like "extruder-2".
 * Returns 0 (default tool) if slot is null, unrecognised, or only one extruder exists.
 */
function resolve_tool_index(filament_slot, extruderNames) {
  if (!filament_slot) return 0
  const m = filament_slot.match(/^extruder-(\d+)$/)
  if (!m) return 0
  const idx = parseInt(m[1], 10)
  // Bounds check — don't request a tool the printer doesn't have
  if (idx >= (extruderNames?.length ?? 1)) {
    log.warn({ filament_slot, extruderCount: extruderNames?.length }, 'Klipper: requested tool index out of range — defaulting to T0')
    return 0
  }
  return idx
}

async function upload_and_print(host, apiKey, buffer, filename) {
  // Upload gcode to Moonraker's gcodes virtual filesystem
  const form = new FormData()
  form.append('file', buffer, { filename, contentType: 'application/octet-stream' })
  form.append('root', 'gcodes')

  const uploadRes = await fetch(`${host}/server/files/upload`, {
    method: 'POST',
    headers: { ...headers(apiKey), ...form.getHeaders() },
    body: form,
  })
  if (!uploadRes.ok) {
    const text = await uploadRes.text()
    throw new Error(`Klipper upload failed: ${uploadRes.status} — ${text}`)
  }

  // Start the print
  await mr_post(host, apiKey, '/printer/print/start', { filename })
}

// ── extractFilamentInventory ──────────────────────────────────────────────────
//
// Builds a slot list consistent with the Bambu AMS inventory shape so the
// NeuSlice UI can show per-extruder filament info for multi-tool Klipper setups.
// Single-extruder printers get one slot: extruder-0.
//
// Color and type come from:
//   1. Moonraker save_variables namespace (operator-configured via macros)
//   2. Filament switch/motion sensor detection (runout only, no color/type)
//   3. Graceful null defaults when nothing is configured

export function extractFilamentInventory(extruderData, configData) {
  const slots = []
  const vars  = configData ?? {}

  for (const [key, vals] of Object.entries(extruderData ?? {})) {
    if (!/^extruder\d*$/.test(key)) continue
    const index = key === 'extruder' ? 0 : parseInt(key.replace('extruder', ''), 10)

    // Filament runout sensor for this extruder (optional, operator-configured)
    const sensorKey = `filament_switch_sensor extruder${index}_sensor`
    const motionKey = `filament_motion_sensor extruder${index}_sensor`
    const sensorData = configData?.[sensorKey] ?? configData?.[motionKey] ?? {}
    const filament_detected = sensorData.filament_detected

    // Operator-stored filament metadata via SAVE_VARIABLE macros (optional)
    const stored_type  = vars[`extruder${index}_filament_type`]  ?? null
    const stored_color = vars[`extruder${index}_filament_color`] ?? null
    const stored_brand = vars[`extruder${index}_filament_brand`] ?? null

    slots.push({
      slot:        `extruder-${index}`,
      type:        stored_type,
      color:       stored_color,
      color_name:  null,   // Klipper has no color-name concept
      brand:       stored_brand,
      // If sensor is present and detects no filament, show 0% — otherwise null (unknown)
      remain_pct:  filament_detected === false ? 0 : null,
      temp_min:    vals.min_extrude_temp ?? null,
      temp_max:    vals.max_temp         ?? null,
    })
  }

  return slots
}

// ── Creality CFS (multi-lane filament system) ────────────────────────────────
//
// Creality's Klipper fork exposes its filament system through a `box` object
// rather than through extruders — the machine has ONE extruder and N lanes, so
// the extruder-per-slot model above sees a single typeless slot and drops every
// spool in the unit. `box` holds up to four units (T1..T4), each with four lanes
// (A..D) stored as PARALLEL ARRAYS indexed 0-3.
//
// Two things about this payload will bite anyone who trusts it (see the captured
// fixture in ./fixtures/creality-cfs-k2.json):
//
//   1. It is Python serialised loosely. Absent values arrive as the *string*
//      "None", and as "-1" or numeric -1. All three are truthy in JS, so a
//      plain `?? null` or `if (v)` reads an empty lane as populated.
//   2. Colours are seven characters — a leading nibble then RRGGBB
//      ("0ffa800" is #FFA800), not the six or eight chars hex normally implies.
//
// Material arrives as an opaque code ("000001"); `same_material` is the decoder
// ring, grouping lanes that share a material AND colour:
//   [ ["000001", "0ffffff", ["T1A"], "PLA"], … ]

const CFS_LANE_LETTERS = ['A', 'B', 'C', 'D']
const CFS_MAX_UNITS    = 4

/**
 * Read a CFS scalar, collapsing Creality's absent-value sentinels to null.
 * "None", "-1", -1 and "" all mean "no value" and are all truthy as-is.
 */
function cfs_value(raw) {
  if (raw === null || raw === undefined) return null
  const s = String(raw).trim()
  if (s === '' || s === 'None' || s === '-1') return null
  return s
}

/**
 * Normalise a CFS colour ("0ffa800") to the "#FFA800" the rest of NeuSlice uses.
 * Returns null for sentinels and anything that isn't six hex digits once the
 * leading nibble is stripped.
 */
export function normalizeCfsColor(raw) {
  const v = cfs_value(raw)
  if (!v) return null
  const stripped = v.replace(/^#/, '')
  const hex = stripped.length === 7 ? stripped.slice(1) : stripped
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null
  return `#${hex.toUpperCase()}`
}

/**
 * Build lane→material-name and code→material-name lookups from `same_material`.
 * Lane wins over code: the same code can in principle be grouped under
 * different names, and the lane entry is the more specific statement.
 */
function cfs_material_names(same_material) {
  const byLane = new Map()
  const byCode = new Map()
  for (const entry of same_material ?? []) {
    if (!Array.isArray(entry) || entry.length < 4) continue
    const [code, , lanes, name] = entry
    const label = cfs_value(name)
    if (!label) continue
    const codeKey = cfs_value(code)
    if (codeKey && !byCode.has(codeKey)) byCode.set(codeKey, label)
    for (const lane of Array.isArray(lanes) ? lanes : []) {
      const laneKey = cfs_value(lane)
      if (laneKey) byLane.set(laneKey, label)
    }
  }
  return { byLane, byCode }
}

/**
 * Convert a NeuSlice CFS slot key ("cfs-1-B") to the printer's native lane id
 * ("T1B"), which is what `box.map` and the BOX_* macros speak. Returns null for
 * any key that is not a CFS slot, so callers can tell "not mine" from "mine".
 */
export function cfsSlotKeyToLane(slot_key) {
  const m = /^cfs-([1-4])-([A-D])$/.exec(slot_key ?? '')
  return m ? `T${m[1]}${m[2]}` : null
}

/**
 * Convert a CFS slot key to the 0-based lane index M8200 expects as `I`.
 *
 * M8200 is the machine-facing entry point (the one the slicer emits) and it
 * does NOT take a lane name — it takes an integer and derives the name itself:
 *
 *   {% set addr = (I / 4 + 1)|int|string %}
 *   {% set num  = (I % 4)|int %}
 *   {% set tnn  = 'T' + addr + ['A','B','C','D'][num] %}
 *
 * So I is a flat index across all four bays: 0→T1A, 3→T1D, 4→T2A, 15→T4D.
 * Returns null for any key that is not a CFS slot.
 */
export function cfsSlotKeyToLaneIndex(slot_key) {
  const m = /^cfs-([1-4])-([A-D])$/.exec(slot_key ?? '')
  if (!m) return null
  const unit   = Number(m[1])
  const letter = CFS_LANE_LETTERS.indexOf(m[2])
  return (unit - 1) * CFS_LANE_LETTERS.length + letter
}

/**
 * Build the filament inventory for a Creality CFS from the `box` object.
 * Returns [] when no unit is attached, so callers can fall back to the
 * extruder-based inventory.
 *
 * @param {object} box - status.box from /printer/objects/query?box
 */
export function extractCfsInventory(box) {
  const slots = []
  if (!box || typeof box !== 'object') return slots

  const { byLane, byCode } = cfs_material_names(box.same_material)

  for (let unitNum = 1; unitNum <= CFS_MAX_UNITS; unitNum++) {
    const unitKey = `T${unitNum}`
    const unit    = box[unitKey]
    if (!unit || typeof unit !== 'object') continue

    // An empty bay reports type "None" and -1 across every lane array.
    if (cfs_value(unit.type) === null) continue

    const colors    = Array.isArray(unit.color_value)   ? unit.color_value   : []
    const materials = Array.isArray(unit.material_type) ? unit.material_type : []
    const venders   = Array.isArray(unit.vender)        ? unit.vender        : []

    for (let i = 0; i < CFS_LANE_LETTERS.length; i++) {
      const letter = CFS_LANE_LETTERS[i]
      const laneId = `${unitKey}${letter}`

      const color = normalizeCfsColor(colors[i])
      const code  = cfs_value(materials[i])
      // No colour and no material code — nothing is loaded in this lane.
      if (!color && !code) continue

      // "unknown" is what the unit reports for a spool with no RFID tag; it is
      // a placeholder, not a brand, so don't surface it to customers as one.
      const vender = cfs_value(venders[i])
      const brand  = vender && vender.toLowerCase() !== 'unknown' ? vender : null

      slots.push({
        slot:       `cfs-${unitNum}-${letter}`,
        type:       byLane.get(laneId) ?? (code ? byCode.get(code) ?? null : null),
        color,
        color_name: null,          // CFS reports no colour names
        brand,
        // Deliberately null. The unit reports remain_len "100" for every lane on
        // an RFID-less spool, which is a default rather than a measurement —
        // publishing it would tell a customer a nearly-empty spool is full.
        // Confirming the real semantics needs a tagged spool or watching the
        // value decrement across a print.
        remain_pct: null,
        temp_min:   null,          // not reported per lane
        temp_max:   null,
      })
    }
  }

  return slots
}

// ── getStatus ─────────────────────────────────────────────────────────────────

export async function getStatus(handle) {
  const { host, apiKey, extruderNames, filamentConfig } = handle

  // Build a single query for everything we need
  const extruderQuery = (extruderNames ?? ['extruder']).join('&')
  const cfsQuery      = (handle.hasCfs && handle.cfsEnabled) ? '&box' : ''
  const queryPath =
    `/printer/objects/query?print_stats&display_status&heater_bed&${extruderQuery}${cfsQuery}`

  const data   = await mr_get(host, apiKey, queryPath)
  const status = data?.result?.status ?? {}

  const print_stats    = status.print_stats    ?? {}
  const display_status = status.display_status ?? {}
  const heater_bed     = status.heater_bed     ?? {}

  const state_raw    = (print_stats.state ?? '').toLowerCase()
  const progress_pct = Math.round((display_status.progress ?? 0) * 100)
  const layer_num    = print_stats.info?.current_layer ?? 0
  const total_layers = print_stats.info?.total_layer   ?? 0

  // Estimate remaining time from elapsed duration + progress
  // Moonraker exposes print_duration (active printing time, excludes pauses)
  const print_duration = print_stats.print_duration ?? 0
  let remaining_time_s = 0
  if (progress_pct > 0 && progress_pct < 100) {
    const total_estimated = print_duration / (progress_pct / 100)
    remaining_time_s = Math.max(0, Math.round(total_estimated - print_duration))
  }

  // Temperatures — primary extruder + bed
  const primaryExtruder = status[(extruderNames ?? ['extruder'])[0]] ?? status.extruder ?? {}
  const temperatures = {
    bed:           heater_bed.temperature      ?? 0,
    bed_target:    heater_bed.target           ?? 0,
    nozzle:        primaryExtruder.temperature ?? 0,
    nozzle_target: primaryExtruder.target      ?? 0,
  }

  // Filament inventory from all extruder objects + stored variable config
  const extruderData = {}
  for (const eName of (extruderNames ?? ['extruder'])) {
    if (status[eName]) extruderData[eName] = status[eName]
  }
  // A CFS makes the extruder-per-slot model wrong: one extruder, N lanes. When
  // a unit is present and reporting lanes, those ARE the inventory — otherwise
  // fall back to the extruder view (and to it entirely when the unit is empty).
  const cfs_inventory = (handle.hasCfs && handle.cfsEnabled)
    ? extractCfsInventory(status.box)
    : []
  const filament_inventory_raw = cfs_inventory.length > 0
    ? cfs_inventory
    : extractFilamentInventory(extruderData, { ...status, ...(filamentConfig ?? {}) })

  // Overlay default_filament_types from the node's stored config when the agent
  // cannot detect type (Klipper without save_variables macros).
  // Only fills slots where type is null — never overrides a detected type.
  const default_types = handle.defaultFilamentTypes
  const filament_inventory = (Array.isArray(default_types) && default_types.length > 0)
    ? filament_inventory_raw.map((slot, i) => ({
        ...slot,
        type: slot.type ?? default_types[i] ?? default_types[0] ?? null,
      }))
    : filament_inventory_raw

  // ── State mapping ──────────────────────────────────────────────────────
  if (state_raw === 'printing' || state_raw === 'paused') {
    // Stale-data guard: Moonraker sometimes holds a 100%/complete-looking
    // state briefly after a print finishes before transitioning to 'complete'.
    // Detect this and report idle so the agent doesn't get stuck in polling.
    const looks_stale = progress_pct >= 100 && total_layers > 0 && layer_num >= total_layers
    if (looks_stale) {
      return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
    }

    return {
      state: state_raw === 'paused' ? 'paused' : 'printing',
      progress_pct,
      layer_num,
      total_layers,
      remaining_time_s,
      temperatures,
      filament_inventory,
    }
  }

  if (state_raw === 'complete' || state_raw === 'standby' || state_raw === '') {
    return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  if (state_raw === 'error') {
    // Surface the Klipper error message for diagnostics
    const message = print_stats.message ?? 'unknown error'
    log.warn({ host, klipper_error: message }, 'Klipper reported error state')
    return { state: 'error', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory, error_message: message }
  }

  if (state_raw === 'cancelled') {
    // Cancelled by user/server -- printer is free, map to idle so the agent
    // marks itself available again and doesn't show as unavailable.
    return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  // startup / shutdown / unknown — report idle so agent waits for Klipper to come up
  return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
}

// ── cancelJob ─────────────────────────────────────────────────────────────────

export async function cancelJob(handle) {
  const { host, apiKey } = handle
  await mr_post(host, apiKey, '/printer/print/cancel', null)
  log.info({ host }, 'Klipper: print cancelled')
}
