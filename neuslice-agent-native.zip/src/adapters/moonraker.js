/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/**
 * Moonraker adapter (Klipper via Moonraker REST API)
 *
 * Full feature parity with bambu.js:
 *   connect()                  — verify reachability + discover extruders
 *   printFile(handle, path, opts) — extract gcode from 3mf if needed, upload, start print
 *   getStatus()                — state, progress, layers, temps, filament inventory
 *   cancelJob()                — cancel active print
 *   extractFilamentInventory() — multi-extruder tool inventory with sensor data
 *
 * Klipper/Moonraker does not have an AMS concept — filament selection is
 * handled per-extruder (T0, T1, …). When the customer picks a color/slot
 * in the NeuSlice UI, we use the opts.filament_slot to log which extruder
 * was selected. For single-extruder printers (most Klipper setups), there
 * is only one slot (extruder-0) and no action is needed.
 *
 * Moonraker API reference: https://moonraker.readthedocs.io/en/latest/web_api/
 *
 * Environment variables:
 *   KLIPPER_HOST       required  e.g. http://192.168.1.100:7125
 *                                (also accepted as MOONRAKER_HOST for compat)
 *   KLIPPER_API_KEY    optional  (set in moonraker.conf if trusted_clients is restricted)
 *                                (also accepted as MOONRAKER_API_KEY)
 */

import fetch    from 'node-fetch'
import FormData from 'form-data'
import AdmZip   from 'adm-zip'
import { readFile } from 'node:fs/promises'
import { basename }  from 'node:path'
import log from '../logger.js'

export const name = 'moonraker'

/**
 * Publish Creality CFS lanes as filament slots.
 *
 * Still off by default, but the reason has changed. It was off because lane
 * selection did not exist, so publishing lanes could only ever produce a silent
 * wrong-colour print. printFile() now retargets the start block's tool change,
 * which is proven against real Creality Print output but has never run on the
 * physical machine.
 *
 * What remains before flipping this on is a supervised print on the one K2 we
 * have access to — and it belongs to someone else, so a wrong-colour print
 * costs more than a failed job would. Slice-inspect first: confirm the uploaded
 * g-code carries the expected T<n>, then print.
 *
 * Read per-node from the node's own config (`cfs_inventory`), because one agent
 * can serve several printers and only some of them have a CFS — a process-wide
 * env var would switch all of them at once. This constant is only the fallback
 * for a single-node install with no config entry.
 */
const CFS_ENABLED_FALLBACK = process.env.NEUSLICE_CFS_INVENTORY === '1'

// ── Helpers ──────────────────────────────────────────────────────────────────

function headers(apiKey) {
  return apiKey ? { 'X-Api-Key': apiKey } : {}
}

async function mr_get(host, apiKey, path, timeout_ms = 10_000) {
  const res = await fetch(`${host}${path}`, {
    headers: headers(apiKey),
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) throw new Error(`Moonraker GET ${path} failed: ${res.status}`)
  return res.json()
}

async function mr_post(host, apiKey, path, body, timeout_ms = 30_000) {
  const res = await fetch(`${host}${path}`, {
    method: 'POST',
    headers: { ...headers(apiKey), 'Content-Type': 'application/json' },
    body: body != null ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Moonraker POST ${path} failed: ${res.status} — ${text}`)
  }
  return res.json()
}

/**
 * The NeuSlice slicer wraps gcode in a .3mf ZIP container.
 * Moonraker only accepts raw .gcode files — extract it before upload.
 * Falls back to the original buffer if it's already plain gcode.
 *
 * @returns {{ buffer: Buffer, filename: string }}
 */
function extract_gcode_from_3mf(rawBuffer, originalFilename) {
  try {
    const zip = new AdmZip(rawBuffer)
    const entries = zip.getEntries()
    const gcodeEntry = entries.find(e =>
      e.entryName.toLowerCase().endsWith('.gcode') && !e.isDirectory
    )
    if (gcodeEntry) {
      const gcodeFilename = basename(gcodeEntry.entryName)
      log.info({ original: originalFilename, extracted: gcodeFilename }, 'Klipper: extracted gcode from 3mf ZIP')
      return { buffer: gcodeEntry.getData(), filename: gcodeFilename }
    }
  } catch {
    // Not a ZIP — already plain gcode
  }
  // Use original filename but strip .3mf extension if present
  const filename = originalFilename.replace(/\.3mf$/i, '.gcode')
  return { buffer: rawBuffer, filename }
}

// ── connect ──────────────────────────────────────────────────────────────────

export async function connect(config, opts = {}) {
  const host   = config?.host   ?? process.env.KLIPPER_HOST   ?? process.env.MOONRAKER_HOST
  const apiKey = config?.apiKey ?? process.env.KLIPPER_API_KEY ?? process.env.MOONRAKER_API_KEY ?? ''

  if (!host) throw new Error('Klipper/Moonraker: KLIPPER_HOST is required')

  const info = await mr_get(host, apiKey, '/server/info')
  const klipperState = info?.result?.klippy_state ?? 'unknown'
  if (!['ready', 'startup'].includes(klipperState)) {
    throw new Error(`Klipper state is "${klipperState}" — printer may not be connected`)
  }

  // Discover extruder count for filament inventory and multi-tool support
  const configResult = await mr_get(host, apiKey, '/printer/objects/list')
    .catch(() => ({ result: { objects: [] } }))
  const objects = configResult?.result?.objects ?? []
  const extruderNames = objects.filter(o => /^extruder\d*$/.test(o))
  if (extruderNames.length === 0) extruderNames.push('extruder')  // safe default

  // Fetch filament sensor and config for each extruder so we can surface
  // color/type info in the inventory (requires operator to configure sensors)
  const filamentConfig = await fetch_filament_config(host, apiKey, objects)

  // Creality's fork publishes its multi-lane filament system as `box`.
  const hasCfs = objects.includes('box')

  // Per-node gate. `cfs_inventory` comes from the node's own config entry, so a
  // multi-node agent can have it on for the K2 and off for everything else;
  // the env var is only the single-node fallback.
  const cfsEnabled = config?.cfs_inventory ?? CFS_ENABLED_FALLBACK

  log.info(
    { host, extruderCount: extruderNames.length, klipperState, hasCfs, cfsEnabled },
    'Klipper: connected',
  )
  if (hasCfs && !cfsEnabled) {
    log.warn({ host },
      'Klipper: a Creality CFS is attached but lane inventory is disabled — reporting extruder slots only. ' +
      'Set cfs_inventory on the node config (or NEUSLICE_CFS_INVENTORY=1) to enable it.')
  }

  return {
    host, apiKey, extruderNames, filamentConfig, hasCfs, cfsEnabled,
    defaultFilamentTypes: opts.defaultFilamentTypes ?? null,
  }
}

/**
 * Fetch filament sensor + variable store data that enriches extruder inventory.
 * These are best-effort — not all Klipper setups have these configured.
 */
async function fetch_filament_config(host, apiKey, objects) {
  try {
    // Save_variables module lets operators store filament type/color per extruder
    // e.g.: SAVE_VARIABLE VARIABLE=extruder0_filament_type VALUE='"PLA"'
    //       SAVE_VARIABLE VARIABLE=extruder0_filament_color VALUE='"#FF0000"'
    const hasVarFile = objects.includes('save_variables')
    if (!hasVarFile) return {}

    const varsResult = await mr_get(host, apiKey, '/server/database/item?namespace=variables')
    return varsResult?.result?.value ?? {}
  } catch {
    return {}
  }
}

// ── printFile ─────────────────────────────────────────────────────────────────

/**
 * @param {object} handle       - from connect()
 * @param {string} localPath    - path to .gcode.3mf file on disk
 * @param {object} opts
 * @param {string} opts.filament_color  - hex color customer selected (informational for Klipper)
 * @param {string} opts.filament_slot   - slot key e.g. "extruder-0" (selects tool for multi-extruder)
 */
export async function printFile(handle, localPath, opts = {}) {
  const { host, apiKey, extruderNames } = handle
  const { filament_color = null, filament_slot = null } = opts

  // Read the file (3mf wrapper from NeuSlice slicer)
  const rawBuffer = await readFile(localPath)
  const originalFilename = basename(localPath)

  // Moonraker only accepts raw .gcode — extract from 3mf if needed
  const { buffer: gcodeBuffer, filename } = extract_gcode_from_3mf(rawBuffer, originalFilename)

  // Which tool the print must start on. Two sources, one mechanism:
  //   - a CFS lane ("cfs-1-D") → the flat lane index the printer resolves T<n>
  //     against; confirmed against Creality Print output, which selects a lane
  //     with a bare T<n> and nothing else.
  //   - a second extruder ("extruder-1") → that extruder's index.
  const cfsLane   = cfsSlotKeyToLane(filament_slot)
  const toolIndex = cfsLane
    ? cfsSlotKeyToLaneIndex(filament_slot)
    : resolve_tool_index(filament_slot, extruderNames)

  let outgoing = gcodeBuffer
  if (toolIndex > 0) {
    log.info({ filament_slot, cfsLane, toolIndex }, `Klipper: targeting tool T${toolIndex}`)
    // Rewrite the start block's tool change. Prepending a T<n> here used to be
    // the implementation and never worked — the profile's own tool change runs
    // afterwards and overrides it, so every job silently printed on T0.
    outgoing = retargetInitialTool(gcodeBuffer, toolIndex)
  }

  await upload_and_print(host, apiKey, outgoing, filename)

  log.info({ filename, filament_color, filament_slot, cfsLane, toolIndex }, 'Klipper: print started')
}

/**
 * Point a single-material g-code at a different tool.
 *
 * The slicer already emits exactly one tool change, from the profile's
 * machine_start_gcode (`T[initial_no_support_extruder]`, which resolves to T0
 * for a one-filament roster). Prepending another T<n> ahead of the file does
 * NOT work: the start block's own tool change runs afterwards and wins. The
 * only thing that changes the tool is rewriting that line.
 *
 * Refuses anything it cannot reason about rather than guessing, because every
 * failure here is a wrong-colour print on a paid job:
 *   - zero tool changes  → nothing to retarget; the profile is not what we think
 *   - two or more        → a genuine multi-material file; rewriting the first
 *                          line would corrupt the colour sequence
 *
 * @param {Buffer} gcode      raw g-code bytes
 * @param {number} toolIndex  0-based tool to select
 * @returns {Buffer} rewritten g-code, byte-identical apart from that one line
 * @throws if the file does not contain exactly one tool change
 */
export function retargetInitialTool(gcode, toolIndex) {
  const text  = gcode.toString('utf8')
  // Tool changes sit on their own line. Tolerate trailing comments and CRLF,
  // but not an inline T within another command.
  const TOOL_LINE = /^T(\d+)[ \t]*(;.*)?$/gm
  const matches = [...text.matchAll(TOOL_LINE)]

  if (matches.length !== 1) {
    throw new Error(
      `Klipper: expected exactly one tool change to retarget, found ${matches.length}. ` +
      (matches.length === 0
        ? 'The sliced g-code has no tool change — refusing rather than printing on the loaded lane.'
        : 'This looks like a multi-material file; refusing rather than corrupting the colour sequence.'),
    )
  }

  const [full, current, comment] = matches[0]
  const replacement = `T${toolIndex}${comment ? ' ' + comment : ''}`
  if (Number(current) === toolIndex) return gcode   // already correct, don't touch the bytes

  const at = matches[0].index
  return Buffer.concat([
    Buffer.from(text.slice(0, at), 'utf8'),
    Buffer.from(replacement, 'utf8'),
    Buffer.from(text.slice(at + full.length), 'utf8'),
  ])
}

/**
 * Resolve which tool index to use from a filament_slot key like "extruder-2".
 * Returns 0 (default tool) if slot is null, unrecognised, or only one extruder exists.
 */
function resolve_tool_index(filament_slot, extruderNames) {
  if (!filament_slot) return 0
  const m = filament_slot.match(/^extruder-(\d+)$/)
  if (!m) return 0
  const idx = parseInt(m[1], 10)
  // Bounds check — don't request a tool the printer doesn't have
  if (idx >= (extruderNames?.length ?? 1)) {
    log.warn({ filament_slot, extruderCount: extruderNames?.length }, 'Klipper: requested tool index out of range — defaulting to T0')
    return 0
  }
  return idx
}

async function upload_and_print(host, apiKey, buffer, filename) {
  // Upload gcode to Moonraker's gcodes virtual filesystem
  const form = new FormData()
  form.append('file', buffer, { filename, contentType: 'application/octet-stream' })
  form.append('root', 'gcodes')

  const uploadRes = await fetch(`${host}/server/files/upload`, {
    method: 'POST',
    headers: { ...headers(apiKey), ...form.getHeaders() },
    body: form,
  })
  if (!uploadRes.ok) {
    const text = await uploadRes.text()
    throw new Error(`Klipper upload failed: ${uploadRes.status} — ${text}`)
  }

  // Start the print
  await mr_post(host, apiKey, '/printer/print/start', { filename })
}

// ── extractFilamentInventory ──────────────────────────────────────────────────
//
// Builds a slot list consistent with the Bambu AMS inventory shape so the
// NeuSlice UI can show per-extruder filament info for multi-tool Klipper setups.
// Single-extruder printers get one slot: extruder-0.
//
// Color and type come from:
//   1. Moonraker save_variables namespace (operator-configured via macros)
//   2. Filament switch/motion sensor detection (runout only, no color/type)
//   3. Graceful null defaults when nothing is configured

export function extractFilamentInventory(extruderData, configData) {
  const slots = []
  const vars  = configData ?? {}

  for (const [key, vals] of Object.entries(extruderData ?? {})) {
    if (!/^extruder\d*$/.test(key)) continue
    const index = key === 'extruder' ? 0 : parseInt(key.replace('extruder', ''), 10)

    // Filament runout sensor for this extruder (optional, operator-configured)
    const sensorKey = `filament_switch_sensor extruder${index}_sensor`
    const motionKey = `filament_motion_sensor extruder${index}_sensor`
    const sensorData = configData?.[sensorKey] ?? configData?.[motionKey] ?? {}
    const filament_detected = sensorData.filament_detected

    // Operator-stored filament metadata via SAVE_VARIABLE macros (optional)
    const stored_type  = vars[`extruder${index}_filament_type`]  ?? null
    const stored_color = vars[`extruder${index}_filament_color`] ?? null
    const stored_brand = vars[`extruder${index}_filament_brand`] ?? null

    slots.push({
      slot:        `extruder-${index}`,
      type:        stored_type,
      color:       stored_color,
      color_name:  null,   // Klipper has no color-name concept
      brand:       stored_brand,
      // If sensor is present and detects no filament, show 0% — otherwise null (unknown)
      remain_pct:  filament_detected === false ? 0 : null,
      temp_min:    vals.min_extrude_temp ?? null,
      temp_max:    vals.max_temp         ?? null,
    })
  }

  return slots
}

// ── Creality CFS (multi-lane filament system) ────────────────────────────────
//
// Creality's Klipper fork exposes its filament system through a `box` object
// rather than through extruders — the machine has ONE extruder and N lanes, so
// the extruder-per-slot model above sees a single typeless slot and drops every
// spool in the unit. `box` holds up to four units (T1..T4), each with four lanes
// (A..D) stored as PARALLEL ARRAYS indexed 0-3.
//
// Two things about this payload will bite anyone who trusts it (see the captured
// fixture in ./fixtures/creality-cfs-k2.json):
//
//   1. It is Python serialised loosely. Absent values arrive as the *string*
//      "None", and as "-1" or numeric -1. All three are truthy in JS, so a
//      plain `?? null` or `if (v)` reads an empty lane as populated.
//   2. Colours are seven characters — a leading nibble then RRGGBB
//      ("0ffa800" is #FFA800), not the six or eight chars hex normally implies.
//
// Material arrives as an opaque code ("000001"); `same_material` is the decoder
// ring, grouping lanes that share a material AND colour:
//   [ ["000001", "0ffffff", ["T1A"], "PLA"], … ]

const CFS_LANE_LETTERS = ['A', 'B', 'C', 'D']
const CFS_MAX_UNITS    = 4

/**
 * Read a CFS scalar, collapsing Creality's absent-value sentinels to null.
 * "None", "-1", -1 and "" all mean "no value" and are all truthy as-is.
 */
function cfs_value(raw) {
  if (raw === null || raw === undefined) return null
  const s = String(raw).trim()
  if (s === '' || s === 'None' || s === '-1') return null
  return s
}

/**
 * Normalise a CFS colour ("0ffa800") to the "#FFA800" the rest of NeuSlice uses.
 * Returns null for sentinels and anything that isn't six hex digits once the
 * leading nibble is stripped.
 */
export function normalizeCfsColor(raw) {
  const v = cfs_value(raw)
  if (!v) return null
  const stripped = v.replace(/^#/, '')
  const hex = stripped.length === 7 ? stripped.slice(1) : stripped
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null
  return `#${hex.toUpperCase()}`
}

/**
 * Build lane→material-name and code→material-name lookups from `same_material`.
 * Lane wins over code: the same code can in principle be grouped under
 * different names, and the lane entry is the more specific statement.
 */
function cfs_material_names(same_material) {
  const byLane = new Map()
  const byCode = new Map()
  for (const entry of same_material ?? []) {
    if (!Array.isArray(entry) || entry.length < 4) continue
    const [code, , lanes, name] = entry
    const label = cfs_value(name)
    if (!label) continue
    const codeKey = cfs_value(code)
    if (codeKey && !byCode.has(codeKey)) byCode.set(codeKey, label)
    for (const lane of Array.isArray(lanes) ? lanes : []) {
      const laneKey = cfs_value(lane)
      if (laneKey) byLane.set(laneKey, label)
    }
  }
  return { byLane, byCode }
}

/**
 * Convert a NeuSlice CFS slot key ("cfs-1-B") to the printer's native lane id
 * ("T1B"), which is what `box.map` and the BOX_* macros speak. Returns null for
 * any key that is not a CFS slot, so callers can tell "not mine" from "mine".
 */
export function cfsSlotKeyToLane(slot_key) {
  const m = /^cfs-([1-4])-([A-D])$/.exec(slot_key ?? '')
  return m ? `T${m[1]}${m[2]}` : null
}

/**
 * Convert a CFS slot key to the 0-based lane index M8200 expects as `I`.
 *
 * M8200 is the machine-facing entry point (the one the slicer emits) and it
 * does NOT take a lane name — it takes an integer and derives the name itself:
 *
 *   {% set addr = (I / 4 + 1)|int|string %}
 *   {% set num  = (I % 4)|int %}
 *   {% set tnn  = 'T' + addr + ['A','B','C','D'][num] %}
 *
 * So I is a flat index across all four bays: 0→T1A, 3→T1D, 4→T2A, 15→T4D.
 * Returns null for any key that is not a CFS slot.
 */
export function cfsSlotKeyToLaneIndex(slot_key) {
  const m = /^cfs-([1-4])-([A-D])$/.exec(slot_key ?? '')
  if (!m) return null
  const unit   = Number(m[1])
  const letter = CFS_LANE_LETTERS.indexOf(m[2])
  return (unit - 1) * CFS_LANE_LETTERS.length + letter
}

/**
 * Build the filament inventory for a Creality CFS from the `box` object.
 * Returns [] when no unit is attached, so callers can fall back to the
 * extruder-based inventory.
 *
 * @param {object} box - status.box from /printer/objects/query?box
 */
export function extractCfsInventory(box) {
  const slots = []
  if (!box || typeof box !== 'object') return slots

  const { byLane, byCode } = cfs_material_names(box.same_material)

  for (let unitNum = 1; unitNum <= CFS_MAX_UNITS; unitNum++) {
    const unitKey = `T${unitNum}`
    const unit    = box[unitKey]
    if (!unit || typeof unit !== 'object') continue

    // An empty bay reports type "None" and -1 across every lane array.
    if (cfs_value(unit.type) === null) continue

    const colors    = Array.isArray(unit.color_value)   ? unit.color_value   : []
    const materials = Array.isArray(unit.material_type) ? unit.material_type : []
    const venders   = Array.isArray(unit.vender)        ? unit.vender        : []

    for (let i = 0; i < CFS_LANE_LETTERS.length; i++) {
      const letter = CFS_LANE_LETTERS[i]
      const laneId = `${unitKey}${letter}`

      const color = normalizeCfsColor(colors[i])
      const code  = cfs_value(materials[i])
      // No colour and no material code — nothing is loaded in this lane.
      if (!color && !code) continue

      // "unknown" is what the unit reports for a spool with no RFID tag; it is
      // a placeholder, not a brand, so don't surface it to customers as one.
      const vender = cfs_value(venders[i])
      const brand  = vender && vender.toLowerCase() !== 'unknown' ? vender : null

      slots.push({
        slot:       `cfs-${unitNum}-${letter}`,
        type:       byLane.get(laneId) ?? (code ? byCode.get(code) ?? null : null),
        color,
        color_name: null,          // CFS reports no colour names
        brand,
        // Deliberately null. The unit reports remain_len "100" for every lane on
        // an RFID-less spool, which is a default rather than a measurement —
        // publishing it would tell a customer a nearly-empty spool is full.
        // Confirming the real semantics needs a tagged spool or watching the
        // value decrement across a print.
        remain_pct: null,
        temp_min:   null,          // not reported per lane
        temp_max:   null,
      })
    }
  }

  return slots
}

// ── getStatus ─────────────────────────────────────────────────────────────────

export async function getStatus(handle) {
  const { host, apiKey, extruderNames, filamentConfig } = handle

  // Build a single query for everything we need
  const extruderQuery = (extruderNames ?? ['extruder']).join('&')
  const cfsQuery      = (handle.hasCfs && handle.cfsEnabled) ? '&box' : ''
  const queryPath =
    `/printer/objects/query?print_stats&display_status&heater_bed&${extruderQuery}${cfsQuery}`

  const data   = await mr_get(host, apiKey, queryPath)
  const status = data?.result?.status ?? {}

  const print_stats    = status.print_stats    ?? {}
  const display_status = status.display_status ?? {}
  const heater_bed     = status.heater_bed     ?? {}

  const state_raw    = (print_stats.state ?? '').toLowerCase()
  const progress_pct = Math.round((display_status.progress ?? 0) * 100)
  const layer_num    = print_stats.info?.current_layer ?? 0
  const total_layers = print_stats.info?.total_layer   ?? 0

  // Estimate remaining time from elapsed duration + progress
  // Moonraker exposes print_duration (active printing time, excludes pauses)
  const print_duration = print_stats.print_duration ?? 0
  let remaining_time_s = 0
  if (progress_pct > 0 && progress_pct < 100) {
    const total_estimated = print_duration / (progress_pct / 100)
    remaining_time_s = Math.max(0, Math.round(total_estimated - print_duration))
  }

  // Temperatures — primary extruder + bed
  const primaryExtruder = status[(extruderNames ?? ['extruder'])[0]] ?? status.extruder ?? {}
  const temperatures = {
    bed:           heater_bed.temperature      ?? 0,
    bed_target:    heater_bed.target           ?? 0,
    nozzle:        primaryExtruder.temperature ?? 0,
    nozzle_target: primaryExtruder.target      ?? 0,
  }

  // Filament inventory from all extruder objects + stored variable config
  const extruderData = {}
  for (const eName of (extruderNames ?? ['extruder'])) {
    if (status[eName]) extruderData[eName] = status[eName]
  }
  // A CFS makes the extruder-per-slot model wrong: one extruder, N lanes. When
  // a unit is present and reporting lanes, those ARE the inventory — otherwise
  // fall back to the extruder view (and to it entirely when the unit is empty).
  const cfs_inventory = (handle.hasCfs && handle.cfsEnabled)
    ? extractCfsInventory(status.box)
    : []
  const filament_inventory_raw = cfs_inventory.length > 0
    ? cfs_inventory
    : extractFilamentInventory(extruderData, { ...status, ...(filamentConfig ?? {}) })

  // Overlay default_filament_types from the node's stored config when the agent
  // cannot detect type (Klipper without save_variables macros).
  // Only fills slots where type is null — never overrides a detected type.
  const default_types = handle.defaultFilamentTypes
  const filament_inventory = (Array.isArray(default_types) && default_types.length > 0)
    ? filament_inventory_raw.map((slot, i) => ({
        ...slot,
        type: slot.type ?? default_types[i] ?? default_types[0] ?? null,
      }))
    : filament_inventory_raw

  // ── State mapping ──────────────────────────────────────────────────────
  if (state_raw === 'printing' || state_raw === 'paused') {
    // Stale-data guard: Moonraker sometimes holds a 100%/complete-looking
    // state briefly after a print finishes before transitioning to 'complete'.
    // Detect this and report idle so the agent doesn't get stuck in polling.
    const looks_stale = progress_pct >= 100 && total_layers > 0 && layer_num >= total_layers
    if (looks_stale) {
      return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
    }

    return {
      state: state_raw === 'paused' ? 'paused' : 'printing',
      progress_pct,
      layer_num,
      total_layers,
      remaining_time_s,
      temperatures,
      filament_inventory,
    }
  }

  if (state_raw === 'complete' || state_raw === 'standby' || state_raw === '') {
    return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  if (state_raw === 'error') {
    // Surface the Klipper error message for diagnostics
    const message = print_stats.message ?? 'unknown error'
    log.warn({ host, klipper_error: message }, 'Klipper reported error state')
    return { state: 'error', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory, error_message: message }
  }

  if (state_raw === 'cancelled') {
    // Cancelled by user/server -- printer is free, map to idle so the agent
    // marks itself available again and doesn't show as unavailable.
    return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }

  // startup / shutdown / unknown — report idle so agent waits for Klipper to come up
  return { state: 'idle', progress_pct: 0, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
}

// ── cancelJob ─────────────────────────────────────────────────────────────────

export async function cancelJob(handle) {
  const { host, apiKey } = handle
  await mr_post(host, apiKey, '/printer/print/cancel', null)
  log.info({ host }, 'Klipper: print cancelled')
}
