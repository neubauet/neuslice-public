/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { getBearerToken, selectPrinter, printerSerial, slotKeyToTrayId, buildAmsMapping } from './bambu.js'

/**
 * Tests for getBearerToken()'s credential handling.
 *
 * When no username/password is configured the agent authenticates writes with an
 * API key (X-API-Key), so getBearerToken must NOT attempt a login — a blank-cred
 * login POST just 401s on an auth-enabled Bambuddy and aborts the job. Verified
 * against a real auth-enabled Bambuddy that a scoped X-API-Key clears the auth
 * layer on POST /queue and /archives/upload; these tests lock in the agent side.
 *
 * The unreachable host (port 0) is the discriminator: if the early return were
 * missing, getBearerToken would try to fetch and reject — so a clean `null`
 * proves no login was attempted.
 *
 * Run: node --test src/adapters/bambu.test.js
 */
const UNREACHABLE = 'http://127.0.0.1:0'

test('returns null when username is missing (no login attempted)', async () => {
  assert.equal(await getBearerToken(UNREACHABLE, '', 'pw'), null)
})

test('returns null when password is missing (no login attempted)', async () => {
  assert.equal(await getBearerToken(UNREACHABLE, 'user', ''), null)
})

test('returns null when both credentials are missing (no login attempted)', async () => {
  assert.equal(await getBearerToken(UNREACHABLE, undefined, undefined), null)
})

/*
 * SMA-1 — binding beats position.
 *
 * These are plain unit tests with no fetch() anywhere, which is the entire
 * reason selectPrinter() was extracted from connect(). The guarantee under test
 * is the one that costs money when it breaks: on a Bambuddy hosting two
 * printers, a bound node must drive the machine it names, not printers[0].
 */

const P1 = { id: 1, name: 'Garage X1C',  serial_number: '00M09A1234567890' };
const P2 = { id: 7, name: 'Office P1S',  serial_number: '00M09B0987654321' };
const TWO = [P1, P2];

test('SMA-1: a node bound to the second printer selects it, not printers[0]', () => {
  const r = selectPrinter(TWO, { serial: P2.serial_number });
  assert.equal(r.printer.id, 7);
  assert.equal(r.matchedBy, 'serial');
  assert.equal(r.ambiguous, true);
  assert.equal(r.rosterCount, 2);
});

test('SMA-1: an unbound node on a SINGLE-printer Bambuddy still selects correctly (back-compat)', () => {
  const r = selectPrinter([P1], {});
  assert.equal(r.printer.id, 1);
  assert.equal(r.matchedBy, 'position');
  // Not ambiguous — this is the case §6 allows to be auto-backfilled.
  assert.equal(r.ambiguous, false);
});

test('an unbound node on a multi-printer Bambuddy is reported AMBIGUOUS', () => {
  // The selection still has to return something — the agent must connect. What
  // matters is that it tells the truth about how it got there, so the backend
  // can refuse to persist the guess (§6 scoped backfill).
  const r = selectPrinter(TWO, {});
  assert.equal(r.matchedBy, 'position');
  assert.equal(r.ambiguous, true);
});

test('explicit printerId wins over a bound serial', () => {
  // BAMBU_PRINTER_ID is a deliberate operator override; it outranks a binding
  // the backend inferred.
  const r = selectPrinter(TWO, { printerId: '1', serial: P2.serial_number });
  assert.equal(r.printer.id, 1);
  assert.equal(r.matchedBy, 'explicit_id');
});

test('explicit printerId absent from the roster is still honoured', () => {
  // GET /printers/{id} is the authority, not the list — a stale or partial
  // roster must not silently redirect an explicitly configured node.
  const r = selectPrinter(TWO, { printerId: '99' });
  assert.equal(r.printer.id, '99');
  assert.equal(r.matchedBy, 'explicit_id');
});

test('a bound serial that has vanished from the roster falls through, it does not throw', () => {
  const r = selectPrinter(TWO, { serial: 'SERIAL-THAT-IS-GONE' });
  assert.equal(r.matchedBy, 'position');
  assert.equal(r.ambiguous, true);
});

test('bound numeric id is used when no serial matches', () => {
  const r = selectPrinter(TWO, { boundPrinterId: 7 });
  assert.equal(r.printer.id, 7);
  assert.equal(r.matchedBy, 'bound_id');
});

test('selection order is serial BEFORE bound id when both are set', () => {
  const r = selectPrinter(TWO, { serial: P2.serial_number, boundPrinterId: 1 });
  assert.equal(r.printer.id, 7, 'serial is the robust key and must win');
});

test('empty roster throws rather than returning undefined', () => {
  assert.throws(() => selectPrinter([], {}), /empty printer roster/);
  assert.throws(() => selectPrinter(null, {}), /empty printer roster/);
});

// ── serial extraction — Q-1 resolved: serial_number is THE field (SMA-N3) ─────

test('printerSerial reads serial_number, the Q-1-confirmed canonical field', () => {
  // A real value from a live Bambuddy P1S (Q-1 spike, 2026-07-26).
  assert.equal(printerSerial({ serial_number: '01P09C531901280' }), '01P09C531901280');
  // Numeric is coerced (defensive) but the key is still serial_number.
  assert.equal(printerSerial({ serial_number: 42 }), '42');
});

test('printerSerial ignores legacy/guessed serial keys — only serial_number counts', () => {
  // Before Q-1 ran, SERIAL_KEYS guessed at dev_id/sn/etc. Now that the field is
  // pinned, a stray key must NOT be honoured as a binding key — the wrong serial
  // is worse than none (it binds a node to a machine it does not own).
  assert.equal(printerSerial({ dev_id: 'A1' }), null);
  assert.equal(printerSerial({ sn: 42 }), null);
  assert.equal(printerSerial({ serial: 'B2' }), null);
});

test('printerSerial returns null when serial_number is absent — the id-bound fallback branch', () => {
  // Retained belt-and-suspenders: if some Bambuddy build omits the field, binding
  // degrades to the numeric id and the node is flagged id_bound (SMA-2). The
  // branch must keep existing even though the live roster always carries a serial.
  assert.equal(printerSerial({ id: 1, name: 'Garage X1C' }), null);
  assert.equal(printerSerial({ serial_number: '   ' }), null);
  assert.equal(printerSerial(null), null);
});

test('a roster with no serials anywhere is selected positionally and flagged ambiguous', () => {
  const r = selectPrinter([{ id: 1, name: 'a' }, { id: 2, name: 'b' }], { serial: 'X' });
  assert.equal(r.serial, null);
  assert.equal(r.ambiguous, true);
});

// ── ams_mapping: slot keys → Bambu tray IDs ──────────────────────────────────
// ams_mapping is positional — index i is the g-code's filament slot i+1 and the
// value is the tray to pull it from. Length and order are load-bearing: a wrong
// entry prints the wrong colour with no error anywhere, so these lock down the
// arithmetic and the all-or-nothing rule.

test('slotKeyToTrayId: AMS unit N slot S maps to N*4 + S', () => {
  assert.equal(slotKeyToTrayId('ams-0-0'), 0);
  assert.equal(slotKeyToTrayId('ams-0-3'), 3);
  assert.equal(slotKeyToTrayId('ams-1-0'), 4);   // second unit starts at 4
  assert.equal(slotKeyToTrayId('ams-1-3'), 7);
  assert.equal(slotKeyToTrayId('ams-3-3'), 15);  // fourth unit, last slot
});

test('slotKeyToTrayId: the external spool is tray 254, whatever its index', () => {
  assert.equal(slotKeyToTrayId('vt-0'), 254);
  assert.equal(slotKeyToTrayId('vt-1'), 254);
});

test('slotKeyToTrayId: unparseable keys return null rather than a wrong tray', () => {
  for (const bad of [null, undefined, '', 'ams-0', 'ams--1', 'ams-a-b', 'tray-2', 'AMS-0-0']) {
    assert.equal(slotKeyToTrayId(bad), null, JSON.stringify(bad));
  }
});

test('buildAmsMapping: a fully resolved multi-slot plan maps in order', () => {
  assert.deepEqual(buildAmsMapping(['ams-0-0', 'ams-0-1', 'ams-0-2']), [0, 1, 2]);
  // Order is preserved exactly as given — not sorted, not deduped.
  assert.deepEqual(buildAmsMapping(['ams-0-2', 'ams-0-0', 'vt-0']), [2, 0, 254]);
});

test('buildAmsMapping: one unresolved slot voids the whole mapping', () => {
  // Returning [0, 2] for a 3-slot file would shift slot 3's colour onto slot 2.
  // null means "send no mapping at all" — Bambuddy then auto-selects the plate.
  assert.equal(buildAmsMapping(['ams-0-0', null, 'ams-0-2']), null);
  assert.equal(buildAmsMapping(['ams-0-0', 'garbage']), null);
});

test('buildAmsMapping: empty or non-array input yields no mapping', () => {
  for (const bad of [[], null, undefined, 'ams-0-0', {}]) {
    assert.equal(buildAmsMapping(bad), null, JSON.stringify(bad));
  }
});

test('buildAmsMapping: a single-slot plan still produces a one-element mapping', () => {
  // The single-colour path must keep working through the same helper.
  assert.deepEqual(buildAmsMapping(['ams-0-1']), [1]);
});
