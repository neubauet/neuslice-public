/*
 * SMA-N3 — repeatable Bambuddy REST contract test.
 *
 * The native gate (spec §3.5): does the Bambuddy the agent talks to — container OR the
 * native Windows Bambuddy service — still expose the exact fields bambu.js consumes?
 * A Bambuddy version/build that drops `serial_number` or changes the status shape would
 * silently break the agent on a real printer; this catches it in a test instead.
 *
 * OPT-IN. Set BAMBUDDY_URL (+ optional BAMBUDDY_API_KEY) to run it against a live
 * Bambuddy; with no URL every case is SKIPPED (not failed), so CI never flakes on it.
 * It is read-only — it never uploads, queues, or prints.
 *
 *   BAMBUDDY_URL=http://127.0.0.1:8000 node --test src/adapters/bambu.contract.test.js
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { printerSerial, selectPrinter } from './bambu.js'

const BASE = process.env.BAMBUDDY_URL?.replace(/\/+$/, '')
const API_KEY = process.env.BAMBUDDY_API_KEY ?? ''
const skip = BASE ? false : 'set BAMBUDDY_URL to run the live Bambuddy contract test (SMA-N3)'
const headers = API_KEY ? { 'X-API-Key': API_KEY } : {}

async function getJSON(path) {
  const res = await fetch(`${BASE}${path}`, { headers })
  assert.ok(res.ok, `GET ${path} → ${res.status}`)
  return res.json()
}

// The load-bearing one: the roster's identity fields, especially the Q-1 serial.
test('SMA-N3: GET /api/v1/printers/ exposes id, name and a non-empty serial_number', { skip }, async () => {
  const printers = await getJSON('/api/v1/printers/')
  assert.ok(Array.isArray(printers), 'the roster must be an array')
  assert.ok(printers.length > 0, 'at least one printer is needed to validate the contract')

  for (const p of printers) {
    assert.ok(p.id != null, 'printer.id is present (selectPrinter/connect key off it)')
    assert.equal(typeof p.name, 'string', 'printer.name is a string')
    // Q-1 pinned this: serial_number is str, unique, non-nullable. It is the robust
    // node↔printer binding key — a build that drops it must fail here, not on a printer.
    assert.equal(typeof p.serial_number, 'string', 'printer.serial_number is a string')
    assert.ok(p.serial_number.trim().length > 0, 'printer.serial_number is non-empty')
    // The agent's own extractor must read exactly this field (SERIAL_KEYS = ['serial_number']).
    assert.equal(printerSerial(p), p.serial_number, 'printerSerial() extracts serial_number')
  }

  // selectPrinter must bind by serial against the real roster (the US-1 guarantee).
  const first = printers[0]
  const chosen = selectPrinter(printers, { serial: first.serial_number })
  assert.equal(String(chosen.printer.id), String(first.id), 'serial binding selects that printer')
  assert.equal(chosen.matchedBy, 'serial')
})

// connect() reads data.name from the single-printer endpoint (the list is not the authority).
test('SMA-N3: GET /api/v1/printers/{id} returns a named printer', { skip }, async () => {
  const printers = await getJSON('/api/v1/printers/')
  const one = await getJSON(`/api/v1/printers/${printers[0].id}`)
  assert.equal(typeof one.name, 'string', 'connect() reads data.name from /printers/{id}')
})

// getStatus reads state/temperatures/ams/vt_tray — all with optional-chaining + defaults,
// so the hard contract is "200 + an object"; type-check the fields that ARE present.
test('SMA-N3: GET /api/v1/printers/{id}/status matches the shape getStatus reads', { skip }, async () => {
  const printers = await getJSON('/api/v1/printers/')
  const status = await getJSON(`/api/v1/printers/${printers[0].id}/status`)
  assert.equal(typeof status, 'object', 'status is a JSON object')
  if (status.state != null) assert.equal(typeof status.state, 'string', 'status.state is a string when present')
  if (status.temperatures != null) assert.equal(typeof status.temperatures, 'object', 'status.temperatures is an object when present')
  if (status.ams != null) assert.ok(Array.isArray(status.ams), 'status.ams is an array when present (extractFilamentInventory iterates it)')
  if (status.vt_tray != null) assert.ok(Array.isArray(status.vt_tray), 'status.vt_tray is an array when present')
})

// getBearerToken depends on /auth/login: 400 when auth is disabled, else access_token on success.
test('SMA-N3: POST /api/v1/auth/login behaves per auth mode', { skip }, async () => {
  const res = await fetch(`${BASE}/api/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify({ username: 'contract-probe', password: 'contract-probe' }),
  })
  if (res.status === 400) return // auth disabled — getBearerToken's documented branch
  if (res.ok) {
    const data = await res.json()
    assert.equal(typeof data.access_token, 'string', 'a successful login returns access_token')
  } else {
    // Auth enabled, bad probe creds → a normal auth rejection is fine (endpoint exists).
    assert.ok([401, 403].includes(res.status), `unexpected /auth/login status ${res.status}`)
  }
})
