/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import {
  extractCfsInventory,
  extractFilamentInventory,
  normalizeCfsColor,
  cfsSlotKeyToLane,
  cfsSlotKeyToLaneIndex,
  retargetInitialTool,
  resolveCfsEnabled,
} from './moonraker.js'

/**
 * Creality CFS lane inventory.
 *
 * The fixture is a verbatim capture from a customer's K2 Plus with one CFS unit
 * and four PLA spools — the machine that surfaced this: the agent reported
 * `slots: 1` forever because the extruder-per-slot model sees one extruder and
 * no lanes, and the single slot it did publish had a null type, which reached
 * POST /jobs and got rejected by Zod at the pay step.
 *
 * These tests are deliberately built on the real payload rather than a tidied
 * one. Creality serialises absent values as the STRING "None" and as "-1"/-1,
 * all truthy in JS, and colours carry a leading nibble — every one of those is
 * a way to read an empty bay as four loaded spools.
 *
 * Run: node --test src/adapters/moonraker.test.js
 */

const FIXTURE = JSON.parse(readFileSync(
  fileURLToPath(new URL('./fixtures/creality-cfs-k2.json', import.meta.url)),
  'utf8',
))
const BOX = FIXTURE.result.status.box

// ── The headline: four lanes, not one slot ───────────────────────────────────

test('CFS-1: extracts all four loaded lanes from a single-unit CFS', () => {
  const slots = extractCfsInventory(BOX)
  assert.equal(slots.length, 4, 'expected 4 lanes, the bug was that we published 1')
  assert.deepEqual(slots.map(s => s.slot), ['cfs-1-A', 'cfs-1-B', 'cfs-1-C', 'cfs-1-D'])
})

test('CFS-2: decodes each lane colour from the 7-char CFS form', () => {
  const slots = extractCfsInventory(BOX)
  assert.deepEqual(
    slots.map(s => s.color),
    ['#FFFFFF', '#FFA800', '#000000', '#FF1E1E'],
  )
})

test('CFS-3: resolves the opaque material code to a name via same_material', () => {
  const slots = extractCfsInventory(BOX)
  // Every lane is code "000001"; only same_material says that means PLA.
  assert.deepEqual(slots.map(s => s.type), ['PLA', 'PLA', 'PLA', 'PLA'])
})

test('CFS-4: every slot satisfies the inventory contract shared with bambu.js', () => {
  const keys = ['slot', 'type', 'color', 'color_name', 'brand', 'remain_pct', 'temp_min', 'temp_max']
  for (const slot of extractCfsInventory(BOX)) {
    assert.deepEqual(Object.keys(slot).sort(), [...keys].sort(), `slot ${slot.slot} shape`)
  }
})

// ── The sentinels — where a naive parser invents filament ────────────────────

test('CFS-5: empty bays T2..T4 contribute nothing despite being present objects', () => {
  const slots = extractCfsInventory(BOX)
  // T2/T3/T4 exist in the payload with full-length arrays of "-1". A truthiness
  // check on those arrays yields 12 phantom lanes.
  assert.ok(slots.every(s => s.slot.startsWith('cfs-1-')), 'only unit 1 is attached')
})

test('CFS-6: the string "None" is treated as absent, not as a value', () => {
  const box = {
    same_material: [],
    T1: {
      type: 'CFS',
      color_value:   ['None', 'None', 'None', 'None'],
      material_type: ['None', 'None', 'None', 'None'],
      vender:        ['None', 'None', 'None', 'None'],
    },
  }
  assert.deepEqual(extractCfsInventory(box), [], '"None" is truthy in JS — it must not read as a spool')
})

test('CFS-7: a bay whose type is the string "None" is skipped entirely', () => {
  const box = { same_material: [], T1: { ...BOX.T2 } }
  assert.deepEqual(extractCfsInventory(box), [])
})

test('CFS-8: numeric -1 sentinels are handled, not just the string form', () => {
  // T1 reports change_color_num as strings; T2 reports it as numbers. The same
  // inconsistency shows up in other arrays across firmware versions.
  const box = {
    same_material: [],
    T1: { type: 'CFS', color_value: [-1, -1, -1, -1], material_type: [-1, -1, -1, -1] },
  }
  assert.deepEqual(extractCfsInventory(box), [])
})

test('CFS-9: a partially loaded unit reports only its loaded lanes', () => {
  const box = {
    same_material: [['000002', '00000ff', ['T1C'], 'PETG']],
    T1: {
      type: 'CFS',
      color_value:   ['-1', 'None', '00000ff', '-1'],
      material_type: ['-1', 'None', '000002',  '-1'],
      vender:        ['-1', 'None', 'unknown', '-1'],
    },
  }
  const slots = extractCfsInventory(box)
  assert.equal(slots.length, 1)
  assert.equal(slots[0].slot, 'cfs-1-C')
  assert.equal(slots[0].type, 'PETG')
  assert.equal(slots[0].color, '#0000FF')
})

test('CFS-10: "unknown" vendor is not surfaced as a brand', () => {
  // Every lane on the real fixture has vender "unknown" (no RFID tag).
  assert.ok(extractCfsInventory(BOX).every(s => s.brand === null))
})

test('CFS-11: remain_pct is null, not the placeholder 100 the unit reports', () => {
  // remain_len is "100" on all four RFID-less lanes. Publishing that would tell
  // a customer a nearly-empty spool is full.
  assert.ok(extractCfsInventory(BOX).every(s => s.remain_pct === null))
})

// ── Multi-unit and degenerate input ──────────────────────────────────────────

test('CFS-12: lanes from a second attached unit get distinct slot keys', () => {
  const box = {
    same_material: [
      ['000001', '0ffffff', ['T1A'], 'PLA'],
      ['000003', '000ff00', ['T3B'], 'ABS'],
    ],
    T1: { type: 'CFS', color_value: ['0ffffff', '-1', '-1', '-1'], material_type: ['000001', '-1', '-1', '-1'] },
    T3: { type: 'CFS', color_value: ['-1', '000ff00', '-1', '-1'], material_type: ['-1', '000003', '-1', '-1'] },
  }
  const slots = extractCfsInventory(box)
  assert.deepEqual(slots.map(s => s.slot), ['cfs-1-A', 'cfs-3-B'])
  assert.deepEqual(slots.map(s => s.type), ['PLA', 'ABS'])
})

test('CFS-13: a lane with a colour but an unrecognised material code still appears', () => {
  // Losing a usable colour because the material is unknown is worse than a null
  // type — the customer can still see and pick the spool.
  const box = {
    same_material: [],
    T1: { type: 'CFS', color_value: ['0ff0000', '-1', '-1', '-1'], material_type: ['0000ff', '-1', '-1', '-1'] },
  }
  const slots = extractCfsInventory(box)
  assert.equal(slots.length, 1)
  assert.equal(slots[0].color, '#FF0000')
  assert.equal(slots[0].type, null)
})

test('CFS-14: missing / malformed box yields an empty inventory, never a throw', () => {
  for (const input of [undefined, null, {}, 'box', 42, []]) {
    assert.deepEqual(extractCfsInventory(input), [], `input ${JSON.stringify(input)}`)
  }
})

// ── Colour normalisation ─────────────────────────────────────────────────────

test('CFS-15: normalizeCfsColor strips the leading nibble and uppercases', () => {
  assert.equal(normalizeCfsColor('0ffa800'), '#FFA800')
  assert.equal(normalizeCfsColor('0000000'), '#000000')
  assert.equal(normalizeCfsColor('0ffffff'), '#FFFFFF')
})

test('CFS-16: normalizeCfsColor rejects sentinels and malformed values', () => {
  for (const bad of ['None', '-1', '', null, undefined, 'nothex', '0zzzzzz']) {
    assert.equal(normalizeCfsColor(bad), null, `should reject ${JSON.stringify(bad)}`)
  }
})

test('CFS-17: normalizeCfsColor accepts a plain 6-char hex unchanged', () => {
  assert.equal(normalizeCfsColor('ffa800'),  '#FFA800')
  assert.equal(normalizeCfsColor('#ffa800'), '#FFA800')
})

// ── Slot key ↔ native lane id ────────────────────────────────────────────────

test('CFS-18: slot keys map to the native lane ids the BOX_* macros speak', () => {
  assert.equal(cfsSlotKeyToLane('cfs-1-A'), 'T1A')
  assert.equal(cfsSlotKeyToLane('cfs-3-D'), 'T3D')
})

test('CFS-19: non-CFS slot keys return null so callers can tell them apart', () => {
  // printFile relies on this to decide whether to refuse the job. If
  // "extruder-0" ever returned a lane, every Klipper print would start failing.
  for (const key of ['extruder-0', 'ams-0-1', 'vt-0', '', null, undefined, 'cfs-5-A', 'cfs-1-E']) {
    assert.equal(cfsSlotKeyToLane(key), null, `should not be a lane: ${JSON.stringify(key)}`)
  }
})

// ── M8200 lane index ─────────────────────────────────────────────────────────
//
// M8200 is the machine-facing lane selector and takes an integer `I`, deriving
// the lane name itself. Getting this arithmetic wrong does not error — it loads
// a different spool, so it is worth checking against the macro rather than
// against a reading of the macro.

/**
 * A faithful JS transcription of the Jinja inside `gcode_macro M8200`, used as
 * an independent oracle. Kept deliberately literal — including the
 * true-division-then-truncate that `(I / 4 + 1)|int` performs — so it fails if
 * anyone "tidies" it into something that is not what the printer runs.
 */
function m8200_tnn(I) {
  const addr = Math.trunc(I / 4 + 1)
  const num  = I % 4
  return `T${addr}${['A', 'B', 'C', 'D'][num]}`
}

test('CFS-24: every slot key round-trips through M8200s own lane arithmetic', () => {
  for (let unit = 1; unit <= 4; unit++) {
    for (const letter of ['A', 'B', 'C', 'D']) {
      const key = `cfs-${unit}-${letter}`
      const I   = cfsSlotKeyToLaneIndex(key)
      assert.equal(
        m8200_tnn(I), cfsSlotKeyToLane(key),
        `${key}: I=${I} would load ${m8200_tnn(I)}, not ${cfsSlotKeyToLane(key)}`,
      )
    }
  }
})

test('CFS-25: the index is flat across bays, 0..15 with no gaps or repeats', () => {
  const all = []
  for (let unit = 1; unit <= 4; unit++) {
    for (const letter of ['A', 'B', 'C', 'D']) all.push(cfsSlotKeyToLaneIndex(`cfs-${unit}-${letter}`))
  }
  assert.deepEqual(all, Array.from({ length: 16 }, (_, i) => i))
})

test('CFS-26: the four lanes on the fixture map to I=0..3', () => {
  assert.deepEqual(
    extractCfsInventory(BOX).map(s => cfsSlotKeyToLaneIndex(s.slot)),
    [0, 1, 2, 3],
  )
  // The red lane the customer would pick is I=3 — not 0, which is what a
  // "just use the first lane" fallback would silently print.
  const red = extractCfsInventory(BOX).find(s => s.color === '#FF1E1E')
  assert.equal(cfsSlotKeyToLaneIndex(red.slot), 3)
})

/*
 * CFS-28 — the binding confirmed against real slicer output.
 *
 * Ground truth is a 4-colour Creality Print job for this exact printer
 * ("2x6 harpening guide 17 degrees", 84 tool changes, all four lanes consumed).
 * It emits bare `T<n>` and nothing else — no M8200, no BOX_*, and no lane or
 * slot declaration anywhere in the file. The only lane information present is
 * the header roster plus the tool index, so `T<n>` is positional over the
 * filament list and the list is in lane order.
 *
 * The tool histogram against filament consumption is what proves it rather than
 * suggests it: T2 fires exactly twice and filament 3 is 1.35 g, the least used
 * of the four.
 *
 *   T0 x27  49.30 g  #ffffff  white   T1A
 *   T1 x18  22.36 g  #ffa800  orange  T1B
 *   T2 x 2   1.35 g  #000000  black   T1C
 *   T3 x37  34.36 g  #ff1e1e  red     T1D
 */
test('CFS-28: slot keys produce the tool index Creality Print emits for that colour', () => {
  const confirmed = [
    { color: '#FFFFFF', slot: 'cfs-1-A', tool: 0 },
    { color: '#FFA800', slot: 'cfs-1-B', tool: 1 },
    { color: '#000000', slot: 'cfs-1-C', tool: 2 },
    { color: '#FF1E1E', slot: 'cfs-1-D', tool: 3 },
  ]
  const inventory = extractCfsInventory(BOX)
  for (const { color, slot, tool } of confirmed) {
    const found = inventory.find(s => s.color === color)
    assert.equal(found.slot, slot, `${color} should be lane ${slot}`)
    assert.equal(
      cfsSlotKeyToLaneIndex(found.slot), tool,
      `${color} must slice as T${tool} — any other index prints a different colour`,
    )
  }
})

test('CFS-27: non-CFS keys have no lane index', () => {
  for (const key of ['extruder-0', 'ams-0-1', 'vt-0', '', null, undefined, 'cfs-5-A', 'cfs-0-A']) {
    assert.equal(cfsSlotKeyToLaneIndex(key), null, `should have no index: ${JSON.stringify(key)}`)
  }
})

// ── Retargeting the tool change ──────────────────────────────────────────────
//
// How a lane actually gets selected. The slicer emits exactly one tool change
// from machine_start_gcode (`T[initial_no_support_extruder]` → T0 for a
// one-filament roster), and the printer resolves T<n> against its lane order.
//
// The previous implementation PREPENDED a T<n> ahead of the file, which never
// worked: the start block's own tool change runs afterwards and wins. CFS-31
// is the regression test for that specific mistake.

/** The real K2 start block, shaped exactly as our profile emits it. */
const K2_GCODE = [
  '; HEADER_BLOCK_START',
  '; generated by NeuSlice',
  '; HEADER_BLOCK_END',
  'M140 S0',
  'M104 S0',
  'START_PRINT EXTRUDER_TEMP=220 BED_TEMP=50',
  'T0',
  'M104 S220',
  'G1 Z3 F600',
  'M83',
  '; done',
  '',
].join('\n')

test('CFS-22: retargets the start block tool change to the requested lane', () => {
  const out = retargetInitialTool(Buffer.from(K2_GCODE), 3).toString()
  assert.match(out, /^T3$/m, 'should now select lane D')
  assert.doesNotMatch(out, /^T0$/m, 'the original T0 must be gone, not merely preceded')
})

test('CFS-23: nothing but that one line changes', () => {
  const out = retargetInitialTool(Buffer.from(K2_GCODE), 2).toString()
  assert.deepEqual(
    out.split('\n').filter(l => !/^T\d+$/.test(l)),
    K2_GCODE.split('\n').filter(l => !/^T\d+$/.test(l)),
    'every non-tool-change line must be byte-identical',
  )
  assert.equal(out.split('\n').length, K2_GCODE.split('\n').length, 'no lines added or removed')
})

test('CFS-29: refuses a file with no tool change rather than guessing', () => {
  const noTool = 'START_PRINT EXTRUDER_TEMP=220 BED_TEMP=50\nG1 Z3 F600\n'
  assert.throws(
    () => retargetInitialTool(Buffer.from(noTool), 2),
    /found 0/,
    'nothing to retarget means the profile is not what we think — do not print',
  )
})

test('CFS-30: refuses a genuine multi-material file rather than corrupting it', () => {
  // Rewriting only the first of many tool changes would silently scramble the
  // colour sequence for every subsequent change.
  const multi = 'T0\nG1 X1\nT3\nG1 X2\nT1\n'
  assert.throws(() => retargetInitialTool(Buffer.from(multi), 2), /found 3/)
})

test('CFS-31: REGRESSION — the tool change is replaced, not prepended', () => {
  // The old implementation did Buffer.concat([`T3\n`, gcode]). The start block's
  // own T0 then ran afterwards and won, so every job printed on lane A while
  // logging that it had switched. Assert ordering, not just presence.
  const out = retargetInitialTool(Buffer.from(K2_GCODE), 3).toString()
  const lines = out.split('\n')
  const startPrint = lines.findIndex(l => l.startsWith('START_PRINT'))
  const tool       = lines.findIndex(l => /^T\d+$/.test(l))
  assert.ok(tool > startPrint, 'the tool change must remain inside the start block')
  assert.equal(lines.filter(l => /^T\d+$/.test(l)).length, 1, 'exactly one tool change survives')
  assert.equal(lines[tool], 'T3')
})

test('CFS-32: an already-correct file is returned untouched', () => {
  const buf = Buffer.from(K2_GCODE)
  assert.equal(retargetInitialTool(buf, 0), buf, 'should not rewrite bytes needlessly')
})

test('CFS-33: a trailing comment on the tool change is preserved', () => {
  const withComment = 'START_PRINT\nT0 ; initial tool\nG1 Z3\n'
  const out = retargetInitialTool(Buffer.from(withComment), 1).toString()
  assert.match(out, /^T1 ; initial tool$/m)
})

test('CFS-34: the four fixture lanes each produce their own tool change', () => {
  // End to end over the real inventory: pick each lane, get a distinct tool.
  for (const slot of extractCfsInventory(BOX)) {
    const idx = cfsSlotKeyToLaneIndex(slot.slot)
    const out = retargetInitialTool(Buffer.from(K2_GCODE), idx).toString()
    assert.match(out, new RegExp(`^T${idx}$`, 'm'), `${slot.slot} (${slot.color}) should select T${idx}`)
  }
})

// ── The extruder path must be unchanged ──────────────────────────────────────

test('CFS-20: the extruder inventory still works for plain Klipper', () => {
  const slots = extractFilamentInventory(
    { extruder: { min_extrude_temp: 170, max_temp: 300 } },
    { extruder0_filament_type: 'PETG', extruder0_filament_color: '#00FF00' },
  )
  assert.equal(slots.length, 1)
  assert.equal(slots[0].slot, 'extruder-0')
  assert.equal(slots[0].type, 'PETG')
})

test('CFS-21: reproduces the reported bug — no save_variables means a typeless slot', () => {
  // This is exactly what coop's node published, and why the pay step 400'd:
  // one slot, type null. The frontend guard and CFS lanes each fix a half.
  const slots = extractFilamentInventory({ extruder: { min_extrude_temp: 170, max_temp: 300 } }, {})
  assert.equal(slots.length, 1)
  assert.equal(slots[0].type, null)
})

// ── The remote switch ────────────────────────────────────────────────────────
//
// The node doc is the only source we can change without shell access to the
// owner's machine, so it has to win. If a stale env var could beat it, turning
// lanes off for a misbehaving printer would be impossible from here.

test('CFS-35: the node doc beats local config and env', () => {
  assert.equal(resolveCfsEnabled({ cfsInventory: true }, { cfs_inventory: false }, false), true)
  assert.equal(resolveCfsEnabled({ cfsInventory: false }, { cfs_inventory: true }, true), false)
})

test('CFS-36: the kill switch cannot be defeated by the env fallback', () => {
  // The scenario that matters: a bad first print, and the owner is unreachable.
  assert.equal(resolveCfsEnabled({ cfsInventory: false }, null, true), false)
})

test('CFS-37: "not set" falls through rather than reading as off', () => {
  // null/undefined must not be coerced to false, or a node with no opinion
  // would permanently override the local config.
  assert.equal(resolveCfsEnabled({}, { cfs_inventory: true }, false), true)
  assert.equal(resolveCfsEnabled({ cfsInventory: null }, { cfs_inventory: true }, false), true)
  assert.equal(resolveCfsEnabled(null, null, true), true)
  assert.equal(resolveCfsEnabled(undefined, undefined, false), false)
})

test('CFS-38: local config is used when the backend says nothing', () => {
  assert.equal(resolveCfsEnabled(null, { cfs_inventory: true }, false), true)
  assert.equal(resolveCfsEnabled(null, { cfs_inventory: false }, true), false)
})
