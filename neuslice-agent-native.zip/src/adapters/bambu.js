/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import fetch from 'node-fetch'
import FormData from 'form-data'
import fs from 'fs'
import path from 'path'
import log from '../logger.js'

export const name = 'bambu'

/**
 * Build request headers for Bambuddy API calls.
 * Omits X-API-Key entirely when key is empty — Bambuddy in no-auth mode
 * (Path A fresh install) rejects requests that include a blank/invalid key.
 */
export function apiHeaders(apiKey) {
  return apiKey ? { 'X-API-Key': apiKey } : {}
}

/**
 * Auth headers for Bambuddy WRITE endpoints (upload, queue create, stop).
 * When Bambuddy has auth ENABLED we hold a Bearer token from getBearerToken().
 * When it has auth DISABLED, getBearerToken() returns null and these endpoints
 * accept the request unauthenticated — verified against a real no-auth Bambuddy:
 * upload/queue/stop all pass the auth layer with no Authorization header and only
 * validate content. Fall back to the API-key header for parity with the read path.
 */
export function writeAuthHeaders(bearerToken, apiKey) {
  return bearerToken ? { 'Authorization': `Bearer ${bearerToken}` } : apiHeaders(apiKey)
}

/**
 * Obtain a Bearer token for Bambuddy's write endpoints — or null when writes
 * should be authenticated another way (API key, or nothing).
 *
 * Returns null in two cases:
 *   1. No username/password configured. The owner authenticates writes with an
 *      API key instead — writeAuthHeaders() falls back to X-API-Key, which
 *      Bambuddy's upload/queue/stop endpoints accept (given the right key
 *      scopes) whether auth is enabled or not. Verified against an auth-ENABLED
 *      Bambuddy: a scoped X-API-Key clears the auth layer on POST /queue and
 *      /archives/upload — they fail only on content (400/422), never 401/403.
 *      Attempting a login with blank creds would just 401 and abort the job, so
 *      skip it entirely.
 *   2. Auth is DISABLED: /auth/login returns 400 {"detail":"Authentication is
 *      not enabled"} — you cannot log in to a server with no auth. Returning null
 *      lets the write go through unauthenticated, which no-auth Bambuddy accepts.
 *
 * A genuine 401 (auth enabled, username+password set but wrong) still throws —
 * that is a real misconfiguration the owner must fix, not something to swallow.
 */
export async function getBearerToken(host, username, password) {
  // No credentials → don't attempt a login. Writes authenticate via the API key
  // (X-API-Key) through writeAuthHeaders(); a blank-cred login POST would 401 on
  // an auth-enabled server and needlessly fail the job.
  if (!username || !password) return null

  const res = await fetch(`${host}/api/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  })
  if (res.status === 400) {
    const text = await res.text()
    if (text.includes('Authentication is not enabled')) {
      log.info?.({ host }, 'Bambuddy auth is disabled — proceeding without a Bearer token')
      return null
    }
    throw new Error(`Bambuddy login failed: 400 — ${text}`)
  }
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Bambuddy login failed: ${res.status} — ${text}`)
  }
  const data = await res.json()
  if (!data.access_token) throw new Error(`Bambuddy login returned no access_token: ${JSON.stringify(data)}`)
  return data.access_token
}

/*
 * ── Node↔printer binding (spec 2026-07-24 §3.1) ──────────────────────────────
 *
 * Q-1 (RESOLVED 2026-07-26): Bambuddy's GET /api/v1/printers/ exposes a stable
 * per-device `serial_number` — str, unique, non-nullable in the default response
 * schema (only `access_code` is permission-gated). Confirmed both in upstream
 * maziggy/bambuddy (models/printer.py, schemas/printer.py) and live against a
 * pinned deployment: a P1S returned "serial_number":"01P09C531901280". So the
 * binding primary key is the robust serial; the numeric id is only ever the
 * fallback.
 *
 * SERIAL_KEYS stays a one-element list on purpose: "no serial exposed" remains a
 * real, tested branch (bind by id and flag the node id-bound, SMA-2) — belt-and-
 * suspenders for a Bambuddy build that somehow omits the field — but the common
 * path now reads exactly one canonical key.
 */
const SERIAL_KEYS = ['serial_number']

/** Pull a printer's hardware serial out of a Bambuddy roster entry, or null. */
export function printerSerial(printer) {
  if (!printer || typeof printer !== 'object') return null
  for (const k of SERIAL_KEYS) {
    const v = printer[k]
    if (typeof v === 'string' && v.trim()) return v.trim()
    if (typeof v === 'number' && Number.isFinite(v)) return String(v)
  }
  return null
}

/**
 * Choose which printer in a Bambuddy roster this node drives.
 *
 * Selection order (spec §3.1) — the whole point is that position is LAST:
 *   1. explicit printerId  (BAMBU_PRINTER_ID / config.printerId)
 *   2. match on the bound serial
 *   3. match on the bound numeric id
 *   4. positional fallback — printers[0], and it WARNS on a multi-printer
 *      Bambuddy because that is the P1 collision case.
 *
 * Pure and fetch-free so SMA-1 is a plain unit test.
 *
 * @param {Array}  printers  roster from GET /api/v1/printers/
 * @param {object} binding   { printerId?, serial? } — the node's persisted binding
 * @returns {{ printer: object, matchedBy: 'explicit_id'|'serial'|'bound_id'|'position',
 *             serial: string|null, ambiguous: boolean, rosterCount: number }}
 */
export function selectPrinter(printers, binding = {}) {
  if (!Array.isArray(printers) || printers.length === 0) {
    throw new Error('selectPrinter: empty printer roster')
  }
  const rosterCount = printers.length
  const ambiguous   = rosterCount > 1
  const finish = (printer, matchedBy) => ({
    printer,
    matchedBy,
    serial: printerSerial(printer),
    ambiguous,
    rosterCount,
  })

  const wantId     = binding.printerId != null ? String(binding.printerId) : null
  const wantSerial = typeof binding.serial === 'string' && binding.serial.trim()
    ? binding.serial.trim()
    : null

  if (wantId) {
    const hit = printers.find(p => String(p?.id) === wantId)
    // An explicit id that is not in the roster is still honoured — the caller
    // set it deliberately, and GET /printers/{id} is the authority, not the list.
    if (hit) return finish(hit, 'explicit_id')
    return { printer: { id: wantId }, matchedBy: 'explicit_id', serial: null, ambiguous, rosterCount }
  }

  if (wantSerial) {
    const hit = printers.find(p => printerSerial(p) === wantSerial)
    if (hit) return finish(hit, 'serial')
    log.warn?.({ rosterCount }, '[bambu] bound serial not present in Bambuddy roster — falling through')
  }

  if (binding.boundPrinterId != null) {
    const hit = printers.find(p => String(p?.id) === String(binding.boundPrinterId))
    if (hit) return finish(hit, 'bound_id')
  }

  if (ambiguous) {
    log.warn?.(
      { rosterCount, chosen: printers[0]?.name, chosen_id: printers[0]?.id },
      '[bambu] POSITIONAL FALLBACK on a multi-printer Bambuddy — this node has no ' +
      'printer binding, so it may be driving the wrong machine. Register it from the ' +
      'detected-printers flow, or set BAMBU_PRINTER_ID, to bind it.'
    )
  }
  return finish(printers[0], 'position')
}

export async function connect(config) {
  const host     = config?.host     ?? process.env.BAMBU_HOST ?? process.env.BAMBUDDY_BASE_URL ?? 'http://localhost:8000'
  const apiKey   = config?.apiKey   ?? process.env.BAMBU_API_KEY   ?? ''
  const username = config?.username ?? process.env.BAMBU_USERNAME  ?? ''
  const password = config?.password ?? process.env.BAMBU_PASSWORD  ?? ''

  // Resolve which physical printer this node drives.
  //
  // We now ALWAYS fetch the roster, even when an explicit id is set: the roster
  // is what carries the serial, and the serial is what gets reported upward so
  // the backend can persist the binding (§3.1). Skipping the list would leave an
  // explicitly-configured node permanently unbound.
  const explicitId = config?.printerId ?? process.env.BAMBU_PRINTER_ID ?? null

  let printers = null
  try {
    const listRes = await fetch(`${host}/api/v1/printers/`, { headers: apiHeaders(apiKey) })
    if (!listRes.ok) throw new Error(`status ${listRes.status}`)
    printers = await listRes.json()
  } catch (err) {
    // With an explicit id we can still connect without the roster — we just
    // cannot bind. Without one, the roster IS the selection input, so this fails.
    if (!explicitId) {
      throw new Error(
        `Bambuddy connect failed (${err.message}) — could not fetch printer list. ` +
        `Check BAMBUDDY_BASE_URL (${host}) and make sure Bambuddy is running.`
      )
    }
    log.warn?.({ host, err: err.message }, '[bambu] roster fetch failed — connecting by explicit id, node will stay unbound')
  }

  let printerId = explicitId != null ? String(explicitId) : null
  let binding = { serial: null, matchedBy: 'explicit_id', ambiguous: false, rosterCount: 0 }

  if (Array.isArray(printers)) {
    if (printers.length === 0) {
      throw new Error(
        'No printers found in Bambuddy. Add your printer at ' +
        `${host} and restart the agent (docker compose restart neuslice-agent).`
      )
    }
    const chosen = selectPrinter(printers, {
      printerId:      explicitId,
      serial:         config?.serial ?? process.env.BAMBU_SERIAL ?? null,
      boundPrinterId: config?.boundPrinterId ?? null,
    })
    printerId = String(chosen.printer.id)
    binding = {
      serial:      chosen.serial,
      matchedBy:   chosen.matchedBy,
      ambiguous:   chosen.ambiguous,
      rosterCount: chosen.rosterCount,
    }
  }

  const res = await fetch(`${host}/api/v1/printers/${printerId}`, {
    headers: apiHeaders(apiKey),
  })
  if (!res.ok) {
    throw new Error(
      `Bambuddy connect failed (${res.status}) — ` +
      `check BAMBU_HOST/BAMBUDDY_BASE_URL, BAMBU_API_KEY, and BAMBU_PRINTER_ID`
    )
  }
  const data = await res.json()

  // The detail endpoint may carry the serial even when the list entry does not.
  const serial = binding.serial ?? printerSerial(data)

  // The full roster this Bambuddy exposes, in the transport shape the backend's
  // detection diff consumes (spec §3.3). Read by Agent._report_roster(); empty
  // when the list fetch failed (explicit-id connect) — nothing to detect then.
  const roster = Array.isArray(printers)
    ? printers.map(p => ({
        id:     p?.id != null ? String(p.id) : null,
        name:   typeof p?.name  === 'string' ? p.name  : null,
        model:  typeof p?.model === 'string' ? p.model : null,
        serial: printerSerial(p),
      }))
    : []

  return {
    host, apiKey, printerId, printerName: data.name, username, password,
    // Binding metadata — read by Agent._report_binding(), never sent to Bambuddy.
    binding: {
      serial,
      printerId,
      matchedBy:   binding.matchedBy,
      ambiguous:   binding.ambiguous,
      rosterCount: binding.rosterCount,
    },
    // Detection roster — read by Agent._report_roster(), never sent to Bambuddy.
    roster,
  }
}

/**
 * Convert an agent slot key (e.g. "ams-0-2") to a flat Bambu tray ID.
 * Bambu AMS tray IDs: AMS unit N, slot S  →  N*4 + S  (0-indexed)
 * External spool ("vt-0")  →  254
 * Returns null when the key cannot be parsed (caller falls back to auto).
 */
export function slotKeyToTrayId(slotKey) {
  if (!slotKey) return null
  if (slotKey.startsWith('vt-')) return 254
  const m = slotKey.match(/^ams-(\d+)-(\d+)$/)
  if (!m) return null
  return parseInt(m[1]) * 4 + parseInt(m[2])
}

/**
 * Build the ams_mapping array for a multi-filament print.
 *
 * ams_mapping is positional: index i is the g-code's filament slot i+1, and the
 * value is the physical Bambu tray to pull it from. That makes the array's
 * LENGTH and ORDER load-bearing — a short or reordered array silently prints
 * the wrong colours rather than failing, so this returns null (meaning "send no
 * mapping, let Bambuddy auto-select") unless every slot resolved.
 *
 * @param {Array<string|null>} slotKeys per filament slot, in slot order
 * @returns {number[]|null} tray IDs, or null if any slot is unresolved
 */
export function buildAmsMapping(slotKeys) {
  if (!Array.isArray(slotKeys) || slotKeys.length === 0) return null
  const trays = slotKeys.map(slotKeyToTrayId)
  if (trays.some(t => t === null)) return null
  return trays
}

export async function printFile(handle, localPath, opts = {}) {
  // filament_slots (plural) is the multi-filament form: one AMS slot key per
  // g-code filament slot, in slot order. When present it takes precedence over
  // the single filament_slot/filament_color pair, which stays the single-colour
  // path unchanged.
  const { filament_color = null, filament_slot = null, filament_slots = null } = opts

  // Step 1: get a Bearer token when username/password are configured. Returns
  // null for an API-key-only or no-auth Bambuddy — writeAuthHeaders() then
  // authenticates writes with the API key (or nothing) instead.
  const bearerToken = await getBearerToken(handle.host, handle.username, handle.password)

  // Step 2: upload .3mf to Bambuddy archive library.
  // Pass ?printer_id= so Bambuddy associates the archive with the correct
  // printer profile (P1S, X1C, etc.) rather than defaulting to the first printer.
  const form = new FormData()
  form.append('file', fs.createReadStream(localPath), path.basename(localPath))

  const uploadRes = await fetch(
    `${handle.host}/api/v1/archives/upload?printer_id=${handle.printerId}`,
    {
      method: 'POST',
      headers: {
        ...writeAuthHeaders(bearerToken, handle.apiKey),
        ...form.getHeaders(),
      },
      body: form,
    }
  )
  if (!uploadRes.ok) {
    const text = await uploadRes.text()
    throw new Error(`Bambuddy upload failed: ${uploadRes.status} — ${text}`)
  }
  const uploaded = await uploadRes.json()
  const archiveId = uploaded.id
  if (!archiveId) throw new Error(`Bambuddy upload returned no id: ${JSON.stringify(uploaded)}`)

  // Step 3: resolve AMS slot → Bambu tray ID for ams_mapping.
  // The ams_mapping array tells Bambu which physical tray to pull from for
  // each filament slot in the gcode (index = gcode slot, value = Bambu tray ID).
  // Fallback chain: explicit slot keys → color-match against live inventory → auto (omit)
  let ams_mapping = undefined

  // Multi-filament job: the backend resolved every slot before dispatch and sent
  // the whole ordered list. There is no color-match fallback here on purpose —
  // a partially-resolved multicolor mapping prints the wrong colours silently,
  // which is worse than letting Bambuddy auto-select the whole plate.
  if (Array.isArray(filament_slots) && filament_slots.length > 0) {
    ams_mapping = buildAmsMapping(filament_slots)
    if (ams_mapping) {
      log.info?.({ filament_slots, ams_mapping }, 'AMS mapping: multi-filament, using backend-resolved slots')
    } else {
      log.warn?.({ filament_slots }, 'AMS mapping: multi-filament slots did not all resolve — letting Bambuddy auto-select')
    }
  } else if (slotKeyToTrayId(filament_slot) !== null) {
    // Customer explicitly picked a single slot — honour it directly.
    const preferredTrayId = slotKeyToTrayId(filament_slot)
    ams_mapping = [preferredTrayId]
    log.info?.({ filament_slot, tray_id: preferredTrayId }, 'AMS mapping: using customer-selected slot')
  } else if (filament_color) {
    // No slot key — try to find a loaded tray whose color matches the hex the
    // customer selected.  normalizeColor() strips the alpha byte Bambuddy appends.
    // We accept a match within a small Euclidean distance (same hue, minor variance).
    try {
      const statusRes = await fetch(`${handle.host}/api/v1/printers/${handle.printerId}/status`, {
        headers: apiHeaders(handle.apiKey),
      })
      if (statusRes.ok) {
        const statusData = await statusRes.json()
        const inventory = extractFilamentInventory(statusData)
        const target = filament_color.replace(/^#/, '').toUpperCase().slice(0, 6)
        const hexDist = (a, b) => {
          const r1 = parseInt(a.slice(0,2),16), g1 = parseInt(a.slice(2,4),16), b1 = parseInt(a.slice(4,6),16)
          const r2 = parseInt(b.slice(0,2),16), g2 = parseInt(b.slice(2,4),16), b2 = parseInt(b.slice(4,6),16)
          return Math.sqrt((r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2)
        }
        // Find closest color match within tolerance 40 (≈15% per channel)
        let best = null, bestDist = 40
        for (const slot of inventory) {
          if (!slot.color) continue
          const slotHex = slot.color.replace(/^#/, '').toUpperCase().slice(0, 6)
          const dist = hexDist(target, slotHex)
          if (dist < bestDist) { bestDist = dist; best = slot }
        }
        if (best) {
          const tray_id = slotKeyToTrayId(best.slot)
          if (tray_id !== null) {
            ams_mapping = [tray_id]
            log.info?.({ filament_color, matched_slot: best.slot, tray_id, dist: bestDist }, 'AMS mapping: color-matched slot')
          }
        } else {
          log.info?.({ filament_color }, 'AMS mapping: no color match within tolerance — letting Bambuddy auto-select')
        }
      }
    } catch (e) {
      log.warn?.({ err: e.message }, 'AMS mapping: status fetch failed — falling back to auto')
    }
  }

  // Step 4: create a print queue item, which dispatches to the printer.
  //
  // This used to POST /archives/{id}/reprint. Bambuddy removed that endpoint —
  // it now answers 410 "Direct archive reprint has been removed. Create a print
  // queue item with POST /queue/." — so every job died here the moment the
  // printer's Bambuddy container updated.
  //
  // The reason reprint was chosen originally was that the generic queue
  // dispatch picked the wrong printer profile (an A1 profile for a P1S). That
  // is addressed here by sending `printer_id` explicitly in the body, which
  // PrintQueueItemCreate accepts — the profile follows the printer we name.
  //
  // Every flag below is sent explicitly even where it matches Bambuddy's
  // current default. These are print-safety and calibration settings, and
  // relying on an upstream default is exactly how this broke: defaults are
  // theirs to change. `nozzle_offset_cali` is deliberately NOT sent — the
  // reprint call never specified it, so we keep accepting Bambuddy's default
  // rather than inventing behaviour this code never had.
  const queueBody = {
    archive_id:      archiveId,
    printer_id:      handle.printerId,
    bed_levelling:   true,
    vibration_cali:  true,
    flow_cali:       false,
    layer_inspect:   false,
    timelapse:       false,
    use_ams:         true,
  }
  // manual_start defaults to false, so creating the item dispatches it — same
  // immediate-print semantics the reprint endpoint had.
  if (ams_mapping) queueBody.ams_mapping = ams_mapping

  const queueRes = await fetch(`${handle.host}/api/v1/queue/`, {
    method: 'POST',
    headers: {
      ...writeAuthHeaders(bearerToken, handle.apiKey),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(queueBody),
  })
  if (!queueRes.ok) {
    const text = await queueRes.text()
    throw new Error(`Bambuddy queue create failed: ${queueRes.status} — ${text}`)
  }
  const queued = await queueRes.json()

  handle._lastArchiveId = archiveId
  // PrintQueueItemResponse.id IS the queue item id, which is what the cancel
  // path (/queue/{id}/stop) needs. The old reprint response only sometimes
  // carried one, so cancellation was best-effort; now it is exact.
  handle._lastQueueId   = queued?.id ?? null
}

/**
 * Normalize an 8-char RGBA hex from Bambuddy (e.g. "FF5733FF") to "#FF5733".
 * If already 6 chars, just adds "#". Returns null for null/empty input.
 */
function normalizeColor(raw) {
  if (!raw) return null
  const hex = raw.replace(/^#/, '')
  const rgb = hex.length === 8 ? hex.slice(0, 6) : hex
  return `#${rgb.toUpperCase()}`
}

/**
 * Extract AMS tray and vt_tray filament inventory from a Bambuddy PrinterStatus response.
 * Returns an array of filament slot objects ready for Firestore storage.
 */
export function extractFilamentInventory(data) {
  const slots = []

  // AMS units: each unit has a `tray` array
  for (const unit of data.ams ?? []) {
    for (const tray of unit.tray ?? []) {
      if (!tray.tray_type) continue  // empty slot
      slots.push({
        slot:        `ams-${unit.id}-${tray.id}`,
        type:        tray.tray_type,
        color:       normalizeColor(tray.tray_color),
        color_name:  tray.tray_id_name   ?? null,
        brand:       tray.tray_sub_brands ?? null,
        remain_pct:  tray.remain          ?? 0,
        temp_min:    tray.nozzle_temp_min ?? null,
        temp_max:    tray.nozzle_temp_max ?? null,
      })
    }
  }

  // External spool tray (non-AMS)
  for (const tray of data.vt_tray ?? []) {
    if (!tray.tray_type) continue
    slots.push({
      slot:        `vt-${tray.id}`,
      type:        tray.tray_type,
      color:       normalizeColor(tray.tray_color),
      color_name:  tray.tray_id_name   ?? null,
      brand:       tray.tray_sub_brands ?? null,
      remain_pct:  tray.remain          ?? 0,
      temp_min:    tray.nozzle_temp_min ?? null,
      temp_max:    tray.nozzle_temp_max ?? null,
    })
  }

  return slots
}

export async function getStatus(handle) {
  const res = await fetch(`${handle.host}/api/v1/printers/${handle.printerId}/status`, {
    headers: apiHeaders(handle.apiKey),
  })
  if (!res.ok) throw new Error(`Bambuddy status failed: ${res.status}`)
  const data = await res.json()
  const raw = (data.state ?? '').toLowerCase()

  const temperatures = {
    bed:          data.temperatures?.bed         ?? 0,
    bed_target:   data.temperatures?.bed_target  ?? 0,
    nozzle:       data.temperatures?.nozzle      ?? 0,
    nozzle_target: data.temperatures?.nozzle_target ?? 0,
  }

  const filament_inventory = extractFilamentInventory(data)

  if (['printing', 'running', 'prepare', 'slicing'].includes(raw)) {
    const progress_pct  = data.progress     ?? 0
    const layer_num     = data.layer_num    ?? 0
    const total_layers  = data.total_layers ?? 0

    return {
      state:            'printing',
      progress_pct,
      layer_num,
      total_layers,
      remaining_time_s: (data.remaining_time ?? 0) * 60,  // Bambuddy returns minutes
      temperatures,
      filament_inventory,
    }
  } else if (['idle', 'finish', 'finished', 'standby', 'ready', ''].includes(raw)) {
    return { state: 'idle', progress_pct: 100, layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  } else {
    return { state: 'idle', progress_pct: 0,   layer_num: 0, total_layers: 0, remaining_time_s: 0, temperatures, filament_inventory }
  }
}

export async function cancelJob(handle) {
  // Cancel/stop use a Bearer token when username/password are set; otherwise the
  // API key (or nothing, for no-auth Bambuddy) via writeAuthHeaders().
  const bearerToken = await getBearerToken(handle.host, handle.username, handle.password)
  const bearer = writeAuthHeaders(bearerToken, handle.apiKey)

  // Cancel the queue item if we have one (stops it if printing, removes if pending)
  if (handle._lastQueueId) {
    const qRes = await fetch(`${handle.host}/api/v1/queue/${handle._lastQueueId}/stop`, {
      method: 'POST',
      headers: bearer,
    })
    if (!qRes.ok) {
      const text = await qRes.text()
      throw new Error(`Bambuddy queue stop failed: ${qRes.status} — ${text}`)
    }
    handle._lastQueueId = null
  }

  // Also send a direct print/stop to the printer in case the queue item
  // is already printing and the queue stop alone isn't enough.
  await fetch(`${handle.host}/api/v1/printers/${handle.printerId}/print/stop`, {
    method: 'POST',
    headers: bearer,
  })
  // Intentionally don't throw on the printer stop — if there's nothing printing
  // Bambuddy may return an error, which is fine.
}
