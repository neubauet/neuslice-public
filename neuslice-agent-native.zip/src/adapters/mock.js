export const name = 'mock'

let _state = 'idle'
let _progress_pct = 0

export async function connect(_config) {
  return {}
}

export async function printFile(_handle, _localPath) {
  _state = 'printing'
  _progress_pct = 0
}

export async function getStatus(_handle) {
  if (_state === 'printing') {
    _progress_pct = Math.min(_progress_pct + 5, 100)
    if (_progress_pct >= 100) {
      _state = 'idle'
      return { state: 'idle', progress_pct: 100 }
    }
    return { state: 'printing', progress_pct: _progress_pct }
  }
  return { state: 'idle', progress_pct: _progress_pct }
}

export async function cancelJob(_handle) {
  _state = 'idle'
  _progress_pct = 0
}
