/**
 * Adapter loader.
 *
 * Two entry points share one connect path:
 *   - load_adapter(opts)          single-agent boot — reads process.env (unchanged)
 *   - load_node_adapter(cfg,opts) supervisor boot — one node's own config object
 *
 * Auto-detects the correct adapter from env vars, or use PRINTER_ADAPTER to
 * force a specific one.
 *
 * Supported values for PRINTER_ADAPTER:
 *   bambu       Bambu Lab printers via Bambuddy
 *   klipper     Klipper printers via Moonraker REST API (alias: moonraker)
 *   moonraker   Same as klipper
 *   octoprint   OctoPrint-managed printers
 *   mock        In-memory stub for local development / testing
 *
 * Auto-detection order (first match wins):
 *   BAMBU_API_KEY or BAMBU_HOST  → bambu
 *   KLIPPER_HOST or MOONRAKER_HOST → klipper / moonraker
 *   OCTOPRINT_HOST               → octoprint
 *   (fallback)                   → mock
 */

/** Resolve the adapter name from env (auto-detect unless PRINTER_ADAPTER forces it). */
export function detect_adapter_name(env = process.env) {
  let name = env.PRINTER_ADAPTER?.toLowerCase()
  if (!name) {
    // BAMBUDDY_BASE_URL alone is enough to trigger the bambu adapter — covers
    // Path A (fresh install, no API key) where auth is disabled in Bambuddy.
    if (env.BAMBU_API_KEY || env.BAMBU_HOST || env.BAMBUDDY_BASE_URL) name = 'bambu'
    else if (env.KLIPPER_HOST || env.MOONRAKER_HOST)                 name = 'klipper'
    else if (env.OCTOPRINT_HOST)                                     name = 'octoprint'
    else                                                             name = 'mock'
  }
  return name === 'moonraker' ? 'klipper' : name
}

/** Dynamically import the adapter module for a (normalized) name. */
export async function import_adapter(name) {
  switch (name) {
    case 'bambu':     return import('./bambu.js')
    case 'klipper':   return import('./moonraker.js')
    case 'octoprint': return import('./octoprint.js')
    case 'mock':
    default:          return import('./mock.js')
  }
}

/**
 * Build the single-agent config object from env. Each adapter reads its own vars
 * inside connect() but we pass the object so tests can inject overrides. Shape is
 * unchanged from the original loader.
 */
export function env_adapter_config(name, env = process.env) {
  return {
    // Bambu — BAMBU_HOST takes priority; fall back to BAMBUDDY_BASE_URL (Path A no-auth)
    host:      env.BAMBU_HOST ?? env.BAMBUDDY_BASE_URL,
    apiKey:    env.BAMBU_API_KEY ?? '',   // empty string = no-auth mode
    printerId: env.BAMBU_PRINTER_ID,
    username:  env.BAMBU_USERNAME,
    password:  env.BAMBU_PASSWORD,
    // Klipper / Moonraker (prefer KLIPPER_* but fall back to MOONRAKER_*)
    ...(name === 'klipper' ? {
      host:   env.KLIPPER_HOST   ?? env.MOONRAKER_HOST,
      apiKey: env.KLIPPER_API_KEY ?? env.MOONRAKER_API_KEY ?? '',
    } : {}),
    // OctoPrint
    ...(name === 'octoprint' ? {
      host:    env.OCTOPRINT_HOST,
      api_key: env.OCTOPRINT_API_KEY,
    } : {}),
  }
}

/**
 * Build one node's config for the supervisor. Per-node values come from the
 * node's own config entry (printers.d/), with env fallbacks only for shared
 * infrastructure — most importantly the one Bambuddy every Bambu node dials
 * (BAMBUDDY_BASE_URL), while each node keeps its own serial-bound printerId.
 */
export function node_adapter_config(name, node_config = {}, env = process.env) {
  const c = node_config ?? {}
  switch (name) {
    case 'bambu':
      return {
        host:      c.host ?? env.BAMBU_HOST ?? env.BAMBUDDY_BASE_URL,
        apiKey:    c.apiKey ?? env.BAMBU_API_KEY ?? '',   // empty string = no-auth mode
        printerId: c.printerId ?? c.printer_id ?? env.BAMBU_PRINTER_ID,
        username:  c.username ?? env.BAMBU_USERNAME,
        password:  c.password ?? env.BAMBU_PASSWORD,
      }
    case 'klipper':
      return {
        host:   c.host ?? env.KLIPPER_HOST ?? env.MOONRAKER_HOST,
        apiKey: c.apiKey ?? env.KLIPPER_API_KEY ?? env.MOONRAKER_API_KEY ?? '',
      }
    case 'octoprint':
      return {
        host:    c.host ?? env.OCTOPRINT_HOST,
        api_key: c.api_key ?? env.OCTOPRINT_API_KEY,
      }
    case 'mock':
    default:
      return { ...c }
  }
}

/** Import + connect for a resolved (name, config). The shared tail of both loaders. */
export async function connect_adapter(name, config, opts = {}) {
  const adapter = await import_adapter(name)
  const handle = await adapter.connect(config, opts)
  return { adapter, handle }
}

/** Single-agent load — reads process.env. Behavior unchanged. */
export async function load_adapter(opts = {}) {
  const name = detect_adapter_name(process.env)
  const config = env_adapter_config(name, process.env)
  return connect_adapter(name, config, opts)
}

/**
 * Supervisor load — one node's own config. `cfg.adapter` may be null (a Bambu
 * node that shares the host Bambuddy omits it), in which case we default to
 * bambu. Returns { adapter, handle } just like load_adapter.
 */
export async function load_node_adapter(cfg, opts = {}) {
  const name = cfg.adapter ?? 'bambu'
  const config = node_adapter_config(name, cfg.config, process.env)
  return connect_adapter(name, config, opts)
}
