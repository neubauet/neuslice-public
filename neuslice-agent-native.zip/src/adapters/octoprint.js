import fetch from 'node-fetch'
import { readFile } from 'node:fs/promises'
import { basename } from 'node:path'
import FormData from 'form-data'

export const name = 'octoprint'

export async function connect(config) {
  const host = config?.host ?? process.env.OCTOPRINT_HOST
  const api_key = config?.api_key ?? process.env.OCTOPRINT_API_KEY
  if (!host) throw new Error('OctoPrint: OCTOPRINT_HOST is required')
  if (!api_key) throw new Error('OctoPrint: OCTOPRINT_API_KEY is required')

  const res = await fetch(`${host}/api/version`, {
    headers: { 'X-Api-Key': api_key },
  })
  if (!res.ok) throw new Error(`OctoPrint version check failed: ${res.status}`)
  return { host, api_key }
}

export async function printFile(handle, localPath) {
  const { host, api_key } = handle
  const fileContent = await readFile(localPath)
  const form = new FormData()
  form.append('file', fileContent, { filename: basename(localPath), contentType: 'text/plain' })
  form.append('print', 'true')

  const res = await fetch(`${host}/api/files/local`, {
    method: 'POST',
    headers: { 'X-Api-Key': api_key, ...form.getHeaders() },
    body: form,
  })
  if (!res.ok) throw new Error(`OctoPrint upload failed: ${res.status}`)
}

export async function getStatus(handle) {
  const { host, api_key } = handle
  const res = await fetch(`${host}/api/job`, {
    headers: { 'X-Api-Key': api_key },
  })
  if (!res.ok) throw new Error(`OctoPrint job status failed: ${res.status}`)
  const data = await res.json()
  const state = data.state
  const progress_pct = data.progress?.completion ?? 0

  if (state === 'Printing') {
    return { state: 'printing', progress_pct }
  } else if (state === 'Operational') {
    return { state: 'idle', progress_pct }
  } else {
    return { state: 'error', progress_pct: 0 }
  }
}

export async function cancelJob(handle) {
  const { host, api_key } = handle
  const res = await fetch(`${host}/api/job`, {
    method: 'POST',
    headers: { 'X-Api-Key': api_key, 'Content-Type': 'application/json' },
    body: JSON.stringify({ command: 'cancel' }),
  })
  if (!res.ok) throw new Error(`OctoPrint cancel failed: ${res.status}`)
}
