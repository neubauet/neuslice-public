/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
/**
 * Tests for resolve_adapter_env() — the sibling-container env resolution that
 * broke Bambu auto-deploy: a spawned Bambu sibling inherited none of the running
 * agent's Bambuddy connection settings, fell back to http://localhost:8000, and
 * crash-looped so the node never came online ("stuck at spawning").
 *
 * Run: node --test src/spawn.test.js
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

// spawn.js throws at import time when NEUSLICE_API_URL is unset (fail-fast guard
// against misconfigured agents). Set it, then import dynamically so the module
// evaluates cleanly under the test runner.
process.env.NEUSLICE_API_URL = 'https://backend.example.test'
const { resolve_adapter_env } = await import('./spawn.js')

test('bambu: backfills BAMBU_HOST from the spawning agent env when the payload omits it', () => {
  const out = resolve_adapter_env('bambu', {}, { BAMBU_HOST: 'http://192.168.1.50:8000', BAMBU_API_KEY: 'k' })
  assert.equal(out.BAMBU_HOST, 'http://192.168.1.50:8000')
  assert.equal(out.BAMBU_API_KEY, 'k')
})

test('bambu: falls back to BAMBUDDY_BASE_URL for the host (installer writes that key)', () => {
  const out = resolve_adapter_env('bambu', {}, { BAMBUDDY_BASE_URL: 'http://bambuddy:8000' })
  assert.equal(out.BAMBU_HOST, 'http://bambuddy:8000')
})

test('bambu: never inherits BAMBU_PRINTER_ID (would mis-target a second printer)', () => {
  const out = resolve_adapter_env('bambu', {}, { BAMBU_HOST: 'http://h:8000', BAMBU_PRINTER_ID: '1' })
  assert.equal(out.BAMBU_PRINTER_ID, undefined)
})

test('bambu: throws SPAWN_REJECTED when no host can be resolved (no crash-loop container)', () => {
  assert.throws(() => resolve_adapter_env('bambu', {}, {}), /SPAWN_REJECTED.*Bambuddy host/)
})

test('bambu: an explicit adapter_env host wins over the agent env', () => {
  const out = resolve_adapter_env(
    'bambu',
    { BAMBU_HOST: 'http://from-payload:8000' },
    { BAMBU_HOST: 'http://from-agent:8000' },
  )
  assert.equal(out.BAMBU_HOST, 'http://from-payload:8000')
})

test('bambu: drops newline-smuggled values (env-injection guard)', () => {
  // A value with a newline could smuggle a second env var past the key allowlist.
  const out = resolve_adapter_env('bambu', {}, { BAMBU_HOST: 'http://h:8000', BAMBU_API_KEY: 'a\nEVIL=1' })
  assert.equal(out.BAMBU_API_KEY, undefined)
})

test('klipper: passes allowlisted payload through and needs no Bambu host', () => {
  const out = resolve_adapter_env('klipper', { MOONRAKER_HOST: 'http://192.168.1.9:7125', NOPE: 'x' }, {})
  assert.equal(out.MOONRAKER_HOST, 'http://192.168.1.9:7125')
  assert.equal(out.NOPE, undefined) // not in the klipper allowlist
})
