/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/**
 * NEUSLICE_API_URL is the backend ORIGIN, not the REST root.
 *
 * The WebSocket lives at `<origin>/ws`, so the env var cannot carry the
 * `/api/v1` prefix — but every REST route does live under it
 * (`app.use('/api/v1/nodes', …)`). Installers write the bare origin
 * (`BACKEND_URL="https://…run.app"`), which means any REST call built as
 * `${api_url}/nodes/…` hits a 404.
 *
 * That is not hypothetical. Four call sites did exactly that, and because each
 * one treats a failed fetch as "no data" rather than an error, all four failed
 * silently in production:
 *
 *   - node opts      → cfs_inventory and default_filament_types never applied
 *   - /jobs/current  → an agent restarting mid-print never resumed the job
 *   - /nodes?agent   → supervisor drift reconcile fell back
 *   - /nodes/:id     → the fallback then flagged every real node as an orphan,
 *                      because it reads a 404 as "this node does not exist"
 *
 * camera.js had it right all along with a hardcoded `/api/v1`, which is what
 * made the inconsistency invisible: the one path anyone exercised worked.
 */

/**
 * Build the REST base from the configured origin.
 *
 * Idempotent and tolerant of trailing slashes, so it is safe to call on a value
 * that already ends in /api/v1 — some installs may have been hand-corrected,
 * and double-prefixing would be a fresh 404.
 *
 * @param {string} api_url backend origin, e.g. https://host or https://host/api/v1
 * @returns {string} e.g. https://host/api/v1
 */
export function api_base(api_url) {
  const trimmed = String(api_url ?? '').trim().replace(/\/+$/, '');
  return `${trimmed.replace(/\/api\/v1$/, '')}/api/v1`;
}
