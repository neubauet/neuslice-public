/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parse_node_opts, fetch_node_opts } from './node_opts.js'

/**
 * Node settings delivered over the API rather than the container environment.
 *
 * Run: node --test src/node_opts.test.js
 *
 * The parsing rule that matters: only a well-formed value is carried. Anything
 * missing or wrong-typed must be ABSENT from the result, not present-and-false —
 * the adapter treats absence as "no opinion, use my default" and a spurious
 * false would override local config the operator set on the machine.
 */

test('OPTS-1: a real boolean is carried through', () => {
  assert.equal(parse_node_opts({ cfs_inventory: true }).cfsInventory, true)
  assert.equal(parse_node_opts({ cfs_inventory: false }).cfsInventory, false)
})

test('OPTS-2: unset stays absent rather than becoming false', () => {
  for (const data of [{}, { cfs_inventory: null }, { cfs_inventory: undefined }]) {
    assert.ok(!('cfsInventory' in parse_node_opts(data)), JSON.stringify(data))
  }
})

test('OPTS-3: a wrong-typed value is ignored, not coerced', () => {
  // The Firestore console defaults new fields to string, so "true" is the most
  // likely bad value in practice. Coercing it would flip a printer on because
  // a non-empty string is truthy.
  for (const v of ['true', 'false', 1, 0, {}, []]) {
    assert.ok(!('cfsInventory' in parse_node_opts({ cfs_inventory: v })), JSON.stringify(v))
  }
})

test('OPTS-4: default_filament_types is carried only when non-empty', () => {
  assert.deepEqual(parse_node_opts({ default_filament_types: ['PETG'] }).defaultFilamentTypes, ['PETG'])
  assert.ok(!('defaultFilamentTypes' in parse_node_opts({ default_filament_types: [] })))
  assert.ok(!('defaultFilamentTypes' in parse_node_opts({ default_filament_types: 'PETG' })))
})

test('OPTS-5: a malformed document yields empty opts without throwing', () => {
  for (const data of [null, undefined, 'nope', 42]) {
    assert.deepEqual(parse_node_opts(data), {}, JSON.stringify(data))
  }
})

test('OPTS-6: a non-OK response throws rather than returning empty opts', async () => {
  // Empty opts are indistinguishable from "the owner cleared every setting".
  // The caller has to be able to tell a blip from a real change, or a 500 would
  // silently revert a node to defaults.
  const fetchImpl = async () => ({ ok: false, status: 503 })
  await assert.rejects(
    () => fetch_node_opts('http://api', 'n1', 't', { fetchImpl }),
    /503/,
  )
})

test('OPTS-7: fetch targets the node under /api/v1 and authenticates with its own token', async () => {
  // The prefix is the whole point. NEUSLICE_API_URL is the ORIGIN (the WebSocket
  // lives at <origin>/ws), while every REST route is mounted under /api/v1 — so a
  // bare `${api_url}/nodes/x` 404s, the catch reads it as "no settings", and the
  // node silently keeps its defaults. That is exactly what happened: #146 fixed
  // four call sites and missed this one, because it greps as `fetchImpl(` rather
  // than `fetch(`, and this is the one that carries cfs_inventory.
  let seen
  const fetchImpl = async (url, init) => {
    seen = { url, auth: init.headers.Authorization }
    return { ok: true, json: async () => ({ cfs_inventory: true }) }
  }
  const opts = await fetch_node_opts('https://backend.run.app', 'node-9', 'tok-abc', { fetchImpl })
  assert.equal(seen.url, 'https://backend.run.app/api/v1/nodes/node-9')
  assert.equal(seen.auth, 'Bearer tok-abc')
  assert.equal(opts.cfsInventory, true)
})

test('OPTS-8: an api_url that already carries the prefix is not double-prefixed', async () => {
  let seen
  const fetchImpl = async (url) => { seen = url; return { ok: true, json: async () => ({}) } }
  await fetch_node_opts('https://backend.run.app/api/v1', 'n1', 't', { fetchImpl })
  assert.equal(seen, 'https://backend.run.app/api/v1/nodes/n1')
})
