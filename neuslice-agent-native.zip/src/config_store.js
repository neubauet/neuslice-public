/*
 * config_store.js — the supervisor's local per-node config (spec §3.4, Q-5).
 *
 * One JSON file per node under printers.d/ (Q-5 → per-file, decided 2026-07-27):
 * adding or removing a printer is a single atomic file write/delete, so the 3c
 * agent-pull write model never has to read-modify-write a shared file and a bad
 * write can't corrupt other nodes.
 *
 * Each file: { node_id, token, adapter?, config? }
 *   - node_id / token : required (the node's identity + agent bearer token)
 *   - adapter         : 'bambu' | 'klipper' | 'octoprint' | 'mock' (optional;
 *                       Bambu shares one Bambuddy so a file may omit it)
 *   - config          : adapter connection settings, e.g. Klipper { host, apiKey }
 *
 * The parse is pure and defensive: this file is on the owner's disk but the
 * agent-pull path (3c) writes into it from a relayed browser value, so a
 * malformed entry is skipped with a warning, never crashes the boot.
 *
 * The WRITE side (3c, SMA-7c(d) + SMA-7) is the security-critical half: the agent
 * is now the ONLY party that validates relayed VALUES (the backend filters keys,
 * not values), and it must land them at platform-appropriate permissions.
 */

import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import log from './logger.js'

const NODE_ID_RE = /^[A-Za-z0-9_-]{1,64}$/
const VALID_ADAPTERS = new Set(['bambu', 'klipper', 'octoprint', 'mock'])

/**
 * True if a value is safe to serialize into the store: a string with no control
 * character. A control char (newline, NUL, DEL, …) is how a hostile relayed value
 * would smuggle a second setting or corrupt the JSON the supervisor re-reads, so
 * the agent — the only party that validates VALUES now (the backend filters keys,
 * not values) — rejects it before it touches disk. SMA-7c(d), the spawn.js
 * safe_env_value discipline widened from \r\n to every control char. Implemented as
 * a char-code scan (not a regex) so the source carries no literal control bytes.
 */
export function safe_config_value(v) {
  if (typeof v !== 'string') return false
  for (let i = 0; i < v.length; i++) {
    const c = v.charCodeAt(i)
    if (c < 0x20 || c === 0x7f) return false
  }
  return true
}

/**
 * Parse + validate one config file's contents. Returns the normalized entry, or
 * null (with a warning) if it can't be a usable node config.
 */
export function parse_node_config(raw, source = '<config>') {
  let obj
  try {
    obj = JSON.parse(raw)
  } catch {
    log.warn?.({ source }, '[config] not valid JSON — skipping')
    return null
  }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
    log.warn?.({ source }, '[config] not an object — skipping')
    return null
  }

  const node_id = typeof obj.node_id === 'string' ? obj.node_id.trim() : ''
  const token   = typeof obj.token === 'string' ? obj.token : ''
  if (!NODE_ID_RE.test(node_id)) {
    log.warn?.({ source }, '[config] missing/invalid node_id — skipping')
    return null
  }
  if (!token) {
    log.warn?.({ source, node_id }, '[config] missing token — skipping')
    return null
  }

  const adapter = typeof obj.adapter === 'string' && VALID_ADAPTERS.has(obj.adapter)
    ? obj.adapter
    : null
  const config = obj.config && typeof obj.config === 'object' && !Array.isArray(obj.config)
    ? obj.config
    : {}

  return { node_id, token, adapter, config }
}

/**
 * Read every *.json node config under `dir`. Missing dir → [] (a fresh install
 * has none). Files are read in name order; a duplicate node_id is skipped so two
 * files can't fight over one node. Never throws — the supervisor must still boot
 * whatever configs are valid.
 */
export function read_node_configs(dir) {
  let files
  try {
    files = fs.readdirSync(dir).filter(f => f.toLowerCase().endsWith('.json'))
  } catch (err) {
    if (err?.code !== 'ENOENT') log.warn?.({ dir, err: err.message }, '[config] printers.d not readable')
    return []
  }

  const out = []
  const seen = new Set()
  for (const f of files.sort()) {
    let raw
    try {
      raw = fs.readFileSync(path.join(dir, f), 'utf8')
    } catch (err) {
      log.warn?.({ file: f, err: err.message }, '[config] could not read file — skipping')
      continue
    }
    const cfg = parse_node_config(raw, f)
    if (!cfg) continue
    if (seen.has(cfg.node_id)) {
      log.warn?.({ node_id: cfg.node_id, file: f }, '[config] duplicate node_id across files — skipping')
      continue
    }
    seen.add(cfg.node_id)
    out.push(cfg)
  }
  return out
}

/** Where the store lives; overridable for tests / non-standard installs. */
export function default_config_dir() {
  return process.env.NEUSLICE_CONFIG_DIR ?? path.join(process.cwd(), 'config', 'printers.d')
}

// ── Write side (3c agent-pull, SMA-7c(d) + SMA-7) ─────────────────────────────

/**
 * Validate an entry destined for the store. Throws with a specific message on the
 * first problem so a bad relayed value is rejected LOUDLY, never silently written.
 * Returns the normalized, safe-to-serialize entry.
 */
export function validate_writable_config(entry) {
  if (!entry || typeof entry !== 'object') throw new Error('config is not an object')
  const node_id = typeof entry.node_id === 'string' ? entry.node_id.trim() : ''
  if (!NODE_ID_RE.test(node_id)) throw new Error('invalid node_id')
  if (!safe_config_value(entry.token) || entry.token === '') throw new Error('invalid or missing token')

  let adapter = null
  if (entry.adapter != null) {
    if (!VALID_ADAPTERS.has(entry.adapter)) throw new Error(`invalid adapter "${String(entry.adapter).slice(0, 32)}"`)
    adapter = entry.adapter
  }

  const config = {}
  const raw = entry.config && typeof entry.config === 'object' && !Array.isArray(entry.config) ? entry.config : {}
  for (const [k, v] of Object.entries(raw)) {
    if (!safe_config_value(k)) throw new Error('invalid config key (control char)')
    if (!safe_config_value(v)) throw new Error(`invalid config value for "${k}" (must be a control-char-free string)`)
    config[k] = v
  }

  return { node_id, token: entry.token, adapter, config }
}

/**
 * Lock a store file down to the owning account only (SMA-7). On POSIX that is a
 * plain chmod 0600. On Windows `mode` maps to the read-only ATTRIBUTE, not an ACL,
 * so we strip inheritance and grant only the running account via icacls; failure is
 * logged (SMA-7's Windows leg has a named-manual escape hatch), never fatal.
 */
export function restrict_permissions(file) {
  if (process.platform === 'win32') {
    try {
      execFileSync('icacls', [file, '/inheritance:r'], { stdio: 'ignore' })
      const domain = process.env.USERDOMAIN
      const user = process.env.USERNAME
      if (user) {
        const principal = domain ? `${domain}\\${user}` : user
        execFileSync('icacls', [file, '/grant:r', `${principal}:F`], { stdio: 'ignore' })
      }
    } catch (err) {
      log.warn?.({ file, err: err.message },
        '[config] could not apply a Windows ACL — verify store permissions manually (SMA-7)')
    }
  } else {
    try {
      fs.chmodSync(file, 0o600)
    } catch (err) {
      log.warn?.({ file, err: err.message }, '[config] chmod 600 failed')
    }
  }
}

/**
 * Write one node's config atomically at owner-only permissions. Validates first
 * (throws on a bad value — nothing is written), writes a temp file with mode 0600,
 * restricts it per-platform, then renames it over the target so a reader never sees
 * a half-written file. Returns the file path.
 */
export function write_node_config(dir, entry, { env = process.env } = {}) {
  void env
  const safe = validate_writable_config(entry)
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, `${safe.node_id}.json`)
  const tmp  = `${file}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(safe, null, 2) + '\n', { mode: 0o600 })
  restrict_permissions(tmp)
  fs.renameSync(tmp, file)
  restrict_permissions(file)
  return file
}

/**
 * Apply a relayed config to the store (3c agent-pull). This is where SMA-7c(d)'s
 * "declines a relay for a node_id it does not serve" lives:
 *
 *   - a relay whose node_id is neither already served nor flagged bootstrap is
 *     REFUSED (returns { written:false, reason:'not-served' }) so a same-owner key
 *     for another host's node never rests on this disk;
 *   - a bootstrap (brand-new node) or an update to a served node is written, after
 *     value validation, merged over any existing entry so a config-only relay keeps
 *     the node's existing token.
 *
 * ACCEPTED v1 BOUNDARY (Tommy, 2026-07-27, after the Phase-3 review board): a
 * `bootstrap` relay bypasses the not-served guard, so in a MULTI-HOST owner setup a
 * brand-new node's Moonraker key AND its agent token can be adopted by whichever
 * same-owner host heartbeats first — not necessarily the host that will serve it.
 * (Both are credentials; both land on the wrong host.) This is owner-scoped first delivery
 * (SMA-7c(c)) and does NOT fully meet SMA-7c(d)'s "never rests on the wrong host" for
 * the multi-host case. Multi-host is a §2 NON-GOAL for v1 and the feature ships behind
 * a default-off flag; single-host (the norm) is correct. The real fix — a host-target
 * discriminator carried on the relay so only the intended host adopts — is DEFERRED
 * until multi-host becomes a committed goal. Do not remove this note without revisiting
 * that decision.
 *
 * Pure w.r.t. decision-making; the only side effect is the file write.
 */
export function apply_config_relay(dir, relay, served_node_ids = new Set(), { env = process.env } = {}) {
  if (!relay || typeof relay !== 'object') return { written: false, reason: 'invalid-relay' }
  const node_id = typeof relay.node_id === 'string' ? relay.node_id.trim() : ''
  if (!NODE_ID_RE.test(node_id)) return { written: false, reason: 'invalid-node-id' }

  const serves = served_node_ids instanceof Set ? served_node_ids : new Set(served_node_ids ?? [])
  const bootstrap = relay.bootstrap === true
  if (!bootstrap && !serves.has(node_id)) {
    log.warn?.({ node_id }, '[config] relay for a node this host does not serve — declined (SMA-7c(d))')
    return { written: false, reason: 'not-served' }
  }

  const existing = read_node_configs(dir).find(c => c.node_id === node_id)
  const entry = {
    node_id,
    token:   relay.token ?? existing?.token,
    adapter: relay.adapter ?? existing?.adapter ?? null,
    config:  { ...(existing?.config ?? {}), ...(relay.config ?? {}) },
  }

  try {
    write_node_config(dir, entry, { env })
    log.info?.({ node_id, bootstrap }, '[config] applied relayed node config')
    return { written: true, reason: 'written' }
  } catch (err) {
    // A hostile/malformed value never lands — SMA-7c(d).
    log.warn?.({ node_id, err: err.message }, '[config] relay rejected before write')
    return { written: false, reason: `invalid-value` }
  }
}
