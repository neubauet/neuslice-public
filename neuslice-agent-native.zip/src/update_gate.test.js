/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * The all-idle update gate (spec §3.2 / SMA-N2). Two load-bearing guarantees:
 *  1. an idle Agent must NEVER restart the shared process while a sibling prints;
 *  2. the gate must NEVER wedge — doUpdate exits the process on success, so a
 *     doUpdate that RETURNS (Watchtower unreachable) is a failure the gate retries.
 *
 * Contract note: doUpdate resolving models the FAILURE path (real success exits the
 * process, which a unit test can't do), so `calls` counting up across attempts is
 * the retry working, not a bug.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { create_update_gate } from './update_gate.js'

function agent(node_id, { busy = false } = {}) {
  return { node_id, _busy: busy, is_busy() { return this._busy } }
}
const tick = () => new Promise(r => setImmediate(r))  // flush the fire-and-forget attempt

test('all idle → the update runs, with the image', async () => {
  const seen = []
  const gate = create_update_gate({ agents: [agent('a'), agent('b')], doUpdate: async (img) => { seen.push(img) }, pollMs: 10_000 })
  gate.request('repo/agent:v2')
  await tick()
  assert.deepEqual(seen, ['repo/agent:v2'])
  gate.stop()
})

test('a sibling mid-print blocks the update until it goes idle', async () => {
  let calls = 0
  const b = agent('b', { busy: true })
  const gate = create_update_gate({ agents: [agent('a'), b], doUpdate: async () => { calls++ }, pollMs: 10_000 })

  gate.request('repo/agent:v2')
  await tick()
  assert.equal(calls, 0, 'held while node b is printing')
  assert.equal(gate._pending(), 'repo/agent:v2', 'the update is still pending')

  b._busy = false           // b's print finishes
  await gate._attempt()     // next poll tick
  assert.equal(calls, 1, 'ran once b went idle')
  gate.stop()
})

test('REGRESSION: a transient Watchtower failure does NOT wedge — the poll retries with no new UPDATE_AVAILABLE', async () => {
  let calls = 0
  // The real doUpdate RESOLVES (returns) when Watchtower is unreachable instead of
  // exiting. The old gate nulled pending + left updating=true here, wedging forever
  // so the whole host fleet could never self-update again. This asserts it retries.
  const gate = create_update_gate({ agents: [agent('a')], doUpdate: async () => { calls++ }, pollMs: 10_000 })
  gate.request('img')
  await tick()
  assert.equal(calls, 1, 'first attempt ran')
  await gate._attempt()     // a later poll tick — NO new request()
  assert.equal(calls, 2, 'the gate retried on the next poll — not wedged')
  gate.stop()
})

test('a throwing doUpdate also retries rather than wedging', async () => {
  let calls = 0
  const gate = create_update_gate({ agents: [agent('a')], doUpdate: async () => { calls++; throw new Error('watchtower down') }, pollMs: 10_000 })
  gate.request('img')
  await tick()
  assert.equal(calls, 1)
  await gate._attempt()
  assert.equal(calls, 2, 'retried after a throw too')
  gate.stop()
})
