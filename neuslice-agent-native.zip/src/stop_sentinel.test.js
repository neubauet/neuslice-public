import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { sentinel_path, request_stop, clear_stop_sentinel, start_stop_watch } from './stop_sentinel.js'

/*
 * The native Windows service graceful-stop bridge (Procedure B2). The guarantee
 * under test is the one that costs a print when it breaks: a service stop must run
 * the SAME drain as a POSIX SIGTERM, and a stale sentinel must never stop a fresh
 * boot. Pure fs, so it runs on the Linux CI runner even though it only fires under
 * a Windows service.
 */

const tmpdir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'neuslice-stop-'))
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

test('request_stop writes the sentinel at the agreed sentinel_path', () => {
  const dir = tmpdir()
  const p = request_stop(dir)
  assert.equal(p, sentinel_path(dir), 'helper and agent must compute the same path')
  assert.ok(fs.existsSync(p))
})

test('clear_stop_sentinel removes it and is a no-op when already gone', () => {
  const dir = tmpdir()
  request_stop(dir)
  clear_stop_sentinel(dir)
  assert.ok(!fs.existsSync(sentinel_path(dir)))
  // second call must not throw
  clear_stop_sentinel(dir)
})

test('a sentinel present at boot is cleared and does NOT trigger a stop', async () => {
  const dir = tmpdir()
  request_stop(dir)                 // stale leftover from before this process
  let fired = false
  const w = start_stop_watch({ dir, pollMs: 10, onStop: () => { fired = true } })
  await sleep(60)
  w.stop()
  assert.equal(fired, false, 'a pre-existing sentinel must be treated as stale, not acted on')
  assert.ok(!fs.existsSync(sentinel_path(dir)), 'stale sentinel is cleared on watch start')
})

test('a sentinel that APPEARS after boot fires onStop once, then is removed', async () => {
  const dir = tmpdir()
  let calls = 0
  let seenSignal = null
  const w = start_stop_watch({
    dir, pollMs: 10,
    onStop: (sig) => { calls++; seenSignal = sig; return Promise.resolve() },
  })
  await sleep(25)
  request_stop(dir)                 // written AFTER boot → this is a real stop
  await sleep(80)
  w.stop()
  assert.equal(seenSignal, 'SERVICE_STOP', 'drains via the same signal path')
  assert.equal(calls, 1, 'fires exactly once')
  assert.ok(!fs.existsSync(sentinel_path(dir)), 'sentinel removed after firing so a restart does not re-trigger')
})

test('NEUSLICE_STOP_SENTINEL overrides the path for helper and agent alike', () => {
  const dir = tmpdir()
  const custom = path.join(dir, 'custom-stop.flag')
  process.env.NEUSLICE_STOP_SENTINEL = custom
  try {
    assert.equal(sentinel_path(dir), custom)
    const p = request_stop(dir)
    assert.equal(p, custom)
    assert.ok(fs.existsSync(custom))
  } finally {
    delete process.env.NEUSLICE_STOP_SENTINEL
  }
})
