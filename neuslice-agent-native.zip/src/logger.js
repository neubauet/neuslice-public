import pino from 'pino'

const log = pino(
  { name: 'neuslice-agent' },
  process.env.NODE_ENV !== 'production'
    ? pino.transport({ target: 'pino-pretty' })
    : undefined
)

export default log
