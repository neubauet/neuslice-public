/**
 * health.js — Local HTTP health + metrics endpoint for the NeuSlice agent.
 *
 * Listens on HEALTH_PORT (default 9101) and exposes:
 *
 *   GET /health        — liveness probe (always 200 if process is alive)
 *   GET /metrics       — structured JSON snapshot of agent + printer state
 *
 * The /metrics payload is read by the owner's local tooling (or a future
 * cloud scraper). Each Agent also pushes its own metrics to the backend on every
 * heartbeat so the admin network-health dashboard can visualise reliability.
 *
 * ── Per-Agent metrics (spec §3.2, Phase 3) ────────────────────────────────────
 * Metrics used to be TWO process-global singletons (`counters`, `live`) that the
 * single Agent mutated directly. Under the supervisor one process runs N Agents,
 * so a shared singleton is last-writer-wins — `/metrics` and every node's
 * heartbeat would report the same process-wide numbers. Instead each Agent now
 * OWNS a metrics bundle (create_metrics), registers it here by node_id, and the
 * health server aggregates across the registry. A single Agent is byte-for-byte
 * the old behaviour (one registered bundle → the same flat snapshot).
 */

import http from 'node:http'
import log  from './logger.js'

const PROCESS_START = Date.now()
const PORT = parseInt(process.env.HEALTH_PORT ?? '9101', 10)

/**
 * A fresh, isolated metrics bundle for one Agent. The Agent mutates its own
 * `.counters` / `.live`; nothing is shared across Agents.
 */
export function create_metrics() {
  return {
    counters: {
      jobs_completed:    0,
      jobs_failed:       0,
      jobs_declined:     0,
      reconnect_count:   0,
      last_heartbeat_at: null,
    },
    live: {
      printer_state:      'unknown',   // idle | printing | error | offline | unknown
      bambuddy_reachable: null,        // true | false | null (non-Bambu)
      filament_inventory: [],          // [{slot, type, color, remaining_g}]
      active_job_id:      null,
      adapter:            'unknown',
    },
  }
}

// node_id → metrics bundle. The Agent registers itself on construct and
// unregisters on shutdown, so the health server always reflects the live set.
const registry = new Map()

export function register_metrics(node_id, metrics) {
  if (node_id && metrics) registry.set(node_id, metrics)
}

export function unregister_metrics(node_id) {
  registry.delete(node_id)
}

/** Test-only: reset the registry between cases. */
export function _reset_metrics_registry() {
  registry.clear()
}

/** One node's flat metrics view (the historic /metrics shape, minus envelope). */
function node_view(node_id, m) {
  return {
    node_id,
    adapter:            m.live.adapter,
    printer_state:      m.live.printer_state,
    bambuddy_reachable: m.live.bambuddy_reachable,
    filament_inventory: m.live.filament_inventory,
    active_job_id:      m.live.active_job_id,
    jobs_completed:     m.counters.jobs_completed,
    jobs_failed:        m.counters.jobs_failed,
    jobs_declined:      m.counters.jobs_declined,
    reconnect_count:    m.counters.reconnect_count,
    last_heartbeat_at:  m.counters.last_heartbeat_at,
  }
}

/**
 * Build the /metrics response from the registry.
 *
 * Zero or one Agent keeps the historic FLAT shape so existing local tooling is
 * unaffected (the `node_id` field is additive). Two or more Agents (supervisor)
 * get a per-node breakdown plus a rolled-up aggregate, so no node's numbers hide
 * another's.
 */
export function snapshot() {
  const envelope = {
    ok:           true,
    uptime_s:     Math.floor((Date.now() - PROCESS_START) / 1000),
    collected_at: new Date().toISOString(),
  }
  const nodes = [...registry.entries()].map(([id, m]) => node_view(id, m))

  if (nodes.length <= 1) {
    // Back-compat: single (or no) Agent → the original flat snapshot.
    const one = nodes[0] ?? node_view(null, create_metrics())
    return { ...envelope, ...one }
  }

  const aggregate = nodes.reduce((a, n) => ({
    jobs_completed:  a.jobs_completed  + n.jobs_completed,
    jobs_failed:     a.jobs_failed     + n.jobs_failed,
    jobs_declined:   a.jobs_declined   + n.jobs_declined,
    reconnect_count: a.reconnect_count + n.reconnect_count,
  }), { jobs_completed: 0, jobs_failed: 0, jobs_declined: 0, reconnect_count: 0 })

  return { ...envelope, agents: nodes.length, aggregate, nodes }
}

export function start_health_server() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://localhost:${PORT}`)

    if (url.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: true, uptime_s: Math.floor((Date.now() - PROCESS_START) / 1000) }))
      return
    }

    if (url.pathname === '/metrics') {
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify(snapshot(), null, 2))
      return
    }

    res.writeHead(404)
    res.end()
  })

  server.listen(PORT, '0.0.0.0', () => {
    log.info({ port: PORT }, '[health] Health server listening')
  })

  server.on('error', (err) => {
    // Non-fatal — health endpoint is best-effort, agent still runs without it
    log.warn({ err: err.message, port: PORT }, '[health] Health server error')
  })

  return server
}
