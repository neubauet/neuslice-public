/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * neuslice-agent/src/spawn.js
 *
 * Auto-deploys a sibling NeuSlice agent container when the printer owner
 * registers a second (or third…) printer from the web UI.
 *
 * Flow:
 *   1. Backend sends SPAWN_AGENT over WebSocket to any running agent owned by
 *      the same owner (selected by broker.js)
 *   2. This module handles it:
 *      a. Calls Docker Engine API via the socket-proxy TCP endpoint
 *         (tcp://docker-socket-proxy:2375) — never via a raw Unix socket.
 *      b. Appends a new service block to docker-compose.yml in the project
 *         directory so the container survives docker compose down && up
 *   3. Sends SPAWN_RESULT back to the backend
 *
 * Requirements:
 *   - DOCKER_SOCKET must be set to tcp://docker-socket-proxy:2375
 *     (set automatically by docker-compose.yml via the socket proxy service)
 *   - Project directory must be bind-mounted so we can write docker-compose.yml
 *     (NEUSLICE_PROJECT_DIR env var, defaults to /neuslice-project)
 *
 * If either env var is missing we fail gracefully with a clear error message
 * and the frontend falls back to showing the manual docker run command.
 *
 * Security notes (SR-001 / SR-003 / SR-006):
 *   - Raw /var/run/docker.sock is NEVER mounted in the agent container.
 *     All Docker API calls go through tecnativa/docker-socket-proxy which
 *     only permits: POST /containers, POST /images/create, GET /images.
 *     The proxy network is internal: true — no external traffic can reach it.
 *   - IMPORTANT: the socket proxy does NOT constrain HostConfig — with
 *     CONTAINERS+POST enabled, /containers/create can still request
 *     privileged mode or host bind mounts. The real security boundary is
 *     validate_spawn_config(): backend-supplied node ids must be UUIDs,
 *     the image must belong to this agent's own image repo (NEUSLICE_IMAGE),
 *     and nothing unvalidated is ever interpolated into docker-compose.yml.
 *   - adapter_env keys are filtered against ADAPTER_ENV_ALLOWLIST before
 *     being injected into container env vars, preventing arbitrary env injection.
 *   - The .env file written to disk is mode 0o600 (owner read/write only).
 *   - adapter_env values are NEVER included in log output.
 *   - NEUSLICE_API_URL must be set explicitly — no hardcoded prod fallback.
 */

import http    from 'http'
import fs      from 'fs'
import path    from 'path'
import os      from 'os'
import log     from './logger.js'
import { parse_docker_socket } from './docker_socket.js'

const DOCKER_SOCKET  = process.env.DOCKER_SOCKET       ?? 'tcp://docker-socket-proxy:2375'
const PROJECT_DIR    = process.env.NEUSLICE_PROJECT_DIR ?? '/neuslice-project'
const COMPOSE_FILE   = path.join(PROJECT_DIR, 'docker-compose.yml')
const AGENT_IMAGE    = process.env.NEUSLICE_IMAGE       ?? 'medwiz159/neuslice:latest'

// NEUSLICE_API_URL must be explicitly configured — no hardcoded prod fallback.
// Failing fast here prevents a misconfigured agent from silently pointing
// spawned containers at a stale or wrong backend URL.
if (!process.env.NEUSLICE_API_URL) {
  throw new Error(
    'NEUSLICE_API_URL is not set. ' +
    'Configure it in your .env file before running the agent.'
  )
}
const NEUSLICE_API = process.env.NEUSLICE_API_URL

// ── Adapter env allowlist ─────────────────────────────────────────────────────
// Only these keys are forwarded into spawned container env vars.
// Any key NOT in the allowlist for the adapter type is silently dropped.
// This prevents an attacker (or a misbehaving backend) from injecting
// arbitrary env vars into the spawned container via adapter_env.  (SR-005)
const ADAPTER_ENV_ALLOWLIST = {
  bambu:     ['BAMBU_HOST', 'BAMBU_API_KEY', 'BAMBU_PRINTER_ID', 'BAMBU_USERNAME', 'BAMBU_PASSWORD'],
  klipper:   ['KLIPPER_HOST', 'KLIPPER_API_KEY', 'MOONRAKER_HOST', 'MOONRAKER_API_KEY'],
  octoprint: ['OCTOPRINT_HOST', 'OCTOPRINT_API_KEY'],
}

// ── Spawn payload validation (SR-006) ────────────────────────────────────────
// Everything in the SPAWN_AGENT payload is backend-controlled, i.e. untrusted
// from the host's point of view. Two of these values used to be interpolated
// raw into docker-compose.yml (YAML injection → arbitrary compose keys such as
// privileged/volumes on the owner's machine), and `image` used to accept any
// registry reference (arbitrary code on the host). Validate all of it.

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
// tag: standard Docker tag chars; digest: sha256 hex
const IMAGE_RE = /^[a-z0-9]+(?:[._\/-][a-z0-9]+)*(?::[\w][\w.-]{0,127})?(?:@sha256:[0-9a-f]{64})?$/

/** Repo part of an image ref (strip :tag and @digest). */
function image_repo(ref) {
  return ref.replace(/@sha256:[0-9a-f]{64}$/, '').replace(/:[\w][\w.-]{0,127}$/, '')
}

function validate_spawn_config({ new_node_id, agent_token, adapter, image }) {
  if (typeof new_node_id !== 'string' || !UUID_RE.test(new_node_id)) {
    throw new Error('SPAWN_REJECTED: new_node_id is not a valid UUID')
  }
  if (typeof agent_token !== 'string' || !agent_token || /\s/.test(agent_token)) {
    throw new Error('SPAWN_REJECTED: agent_token missing or malformed')
  }
  if (!Object.prototype.hasOwnProperty.call(ADAPTER_ENV_ALLOWLIST, adapter)) {
    throw new Error(`SPAWN_REJECTED: unknown adapter "${String(adapter).slice(0, 32)}"`)
  }
  if (image != null) {
    // The backend may only pin a tag/digest of the SAME image repo this agent
    // runs (NEUSLICE_IMAGE) — it may never point the host at a different image.
    if (typeof image !== 'string' || !IMAGE_RE.test(image) || image_repo(image) !== image_repo(AGENT_IMAGE)) {
      throw new Error('SPAWN_REJECTED: image not in allowlist')
    }
  }
}

/** Env values are written to .env files and passed to the Docker API — a value
 *  containing a newline would smuggle extra env vars past the key allowlist. */
function safe_env_value(v) {
  return typeof v === 'string' && !/[\r\n]/.test(v)
}

/**
 * Resolve the final adapter env for a spawned sibling container.
 *
 * Starts from the allowlisted values the backend forwarded in `adapter_env`
 * (untrusted → filtered by key + newline-checked). For Bambu it then backfills
 * the connection settings from the SPAWNING agent's own environment (`src`,
 * default process.env).
 *
 * Why the backfill exists: the "Add a Printer" UI intentionally sends no
 * adapter_env for Bambu ("the agent already has its own credentials"). But a
 * freshly spawned sibling inherits NONE of the running agent's Bambu config, so
 * with no host it fell back to http://localhost:8000, connect() failed, and the
 * container crash-looped (index.js retries → process.exit) — the node never came
 * online and the owner just watched "Deploying…" spin for 90s. The running agent
 * knows which Bambuddy it talks to, so it passes host/key/creds down. These come
 * from the owner's own .env, never the untrusted spawn payload.
 *
 * BAMBU_PRINTER_ID is deliberately NOT inherited — it identifies the running
 * agent's OWN printer. Left unset, the sibling auto-discovers the printer from
 * Bambuddy's /printers list (correct for the common single-printer Bambuddy; a
 * genuine second printer is handled by connect()'s existing selection logic).
 *
 * Throws SPAWN_REJECTED for a Bambu spawn with no resolvable host: creating the
 * container anyway would just crash-loop against localhost:8000. Rejecting turns
 * a silent 90s spinner into an actionable auto_deploy_error on the node.
 *
 * @returns {Record<string,string>} resolved env (allowlisted, newline-safe)
 */
export function resolve_adapter_env(adapter, adapter_env, src = process.env) {
  const allowed_keys = ADAPTER_ENV_ALLOWLIST[adapter] ?? []

  // 1. Take the allowlisted, newline-safe values the backend forwarded.
  const resolved = {}
  for (const [k, v] of Object.entries(adapter_env ?? {})) {
    if (allowed_keys.includes(k) && v != null && v !== '' && safe_env_value(v)) resolved[k] = v
  }

  // 2. Bambu: backfill connection settings from this agent's own env (trusted;
  //    not from the spawn payload). An explicit adapter_env value always wins.
  if (adapter === 'bambu') {
    const inherit = {
      BAMBU_HOST:     src.BAMBU_HOST ?? src.BAMBUDDY_BASE_URL, // installer writes BAMBUDDY_BASE_URL
      BAMBU_API_KEY:  src.BAMBU_API_KEY,
      BAMBU_USERNAME: src.BAMBU_USERNAME,
      BAMBU_PASSWORD: src.BAMBU_PASSWORD,
    }
    for (const [k, v] of Object.entries(inherit)) {
      if (resolved[k] == null && v != null && v !== '' && safe_env_value(v)) resolved[k] = v
    }

    if (!resolved.BAMBU_HOST) {
      throw new Error(
        'SPAWN_REJECTED: no Bambuddy host for the new Bambu agent. Set BAMBU_HOST '
        + '(or BAMBUDDY_BASE_URL) in the running agent\'s .env, or add the printer '
        + 'with the manual setup command instead of auto-deploy.'
      )
    }
  }

  return resolved
}

// ── Docker Engine API via socket proxy (TCP) ──────────────────────────────────
//
// DOCKER_SOCKET is always a tcp:// URL pointing at the socket-proxy sidecar.
// The proxy runs on an internal Docker network and only permits the specific
// API operations needed for spawning (POST /containers, POST /images/create).
// The raw /var/run/docker.sock is NEVER mounted in the agent container.
//
// Also supports unix:///path for local development without the proxy.


export function docker_request(method, path, body = null) {
  return new Promise((resolve, reject) => {
    let transport_opts
    try {
      transport_opts = parse_docker_socket(DOCKER_SOCKET)
    } catch (err) {
      return reject(err)
    }

    const payload = body ? JSON.stringify(body) : null
    const options = {
      ...transport_opts,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(payload ? { 'Content-Length': Buffer.byteLength(payload) } : {}),
      },
    }

    const req = http.request(options, (res) => {
      let data = ''
      res.on('data', chunk => data += chunk)
      res.on('end', () => {
        if (res.statusCode >= 400) {
          reject(new Error(`Docker API ${method} ${path} → ${res.statusCode}: ${data}`))
        } else {
          try { resolve({ status: res.statusCode, body: data ? JSON.parse(data) : null }) }
          catch { resolve({ status: res.statusCode, body: data }) }
        }
      })
    })
    req.on('error', reject)
    if (payload) req.write(payload)
    req.end()
  })
}

// ── build_container_spec ─────────────────────────────────────────────────────

async function get_host_os() {
  try {
    const info = await docker_request('GET', '/info')
    const os          = (info.body?.OperatingSystem ?? '').toLowerCase()
    const kernel      = (info.body?.KernelVersion    ?? '').toLowerCase()
    // Docker Desktop (Windows or Mac) runs inside a Linux VM — the OS reported
    // is 'Docker Desktop' and the kernel contains 'linuxkit' or 'microsoft'.
    // Native Linux hosts report their distro name and a standard kernel.
    const is_docker_desktop =
      os.includes('docker desktop') ||
      kernel.includes('linuxkit') ||
      kernel.includes('microsoft')
    return is_docker_desktop ? 'windows' : 'linux'
  } catch {
    return 'linux' // assume native linux if we can't tell
  }
}

async function build_container_spec(spawn_config) {
  const { new_node_id, agent_token, adapter, adapter_env, image } = spawn_config
  validate_spawn_config(spawn_config) // throws SPAWN_REJECTED on bad input (SR-006)
  const host_os = await get_host_os()
  const service_name = `neuslice-agent-${new_node_id.slice(0, 8)}`

  // Filter adapter_env against the allowlist for this adapter type. (SR-005)
  // Keys not in the allowlist are silently dropped — never injected into the
  // spawned container. This prevents env var injection if the backend or
  // WebSocket payload is tampered with.
  // IMPORTANT: Never log adapter_env values — they contain API keys/passwords.
  const allowed_keys = ADAPTER_ENV_ALLOWLIST[adapter] ?? []
  const unknown_keys = Object.keys(adapter_env ?? {}).filter(k => !allowed_keys.includes(k))
  if (unknown_keys.length > 0) {
    log.warn({ adapter, unknown_keys }, 'Spawn: dropping unknown adapter_env keys (not in allowlist)')
  }
  // Resolve the sibling's adapter env: allowlisted payload + (for Bambu) the
  // connection settings backfilled from this agent's own env. Throws
  // SPAWN_REJECTED for a Bambu spawn with no host rather than creating a
  // container that would crash-loop against localhost:8000. (Never log values.)
  const resolved_adapter_env = resolve_adapter_env(adapter, adapter_env)
  const adapter_env_entries = Object.entries(resolved_adapter_env).map(([k, v]) => `${k}=${v}`)

  const env = [
    `NEUSLICE_NODE_ID=${new_node_id}`,
    `NEUSLICE_TOKEN=${agent_token}`,
    `NEUSLICE_API_URL=${NEUSLICE_API}`,
    `PRINTER_ADAPTER=${adapter}`,
    `NODE_ENV=production`,
    `WATCHTOWER_HOST=watchtower`,
    `WATCHTOWER_PORT=8080`,
    `DOCKER_SOCKET=${DOCKER_SOCKET}`,
    `TZ=${process.env.TZ ?? 'America/New_York'}`,
    ...adapter_env_entries,
  ]

  return {
    service_name,
    image: image ?? AGENT_IMAGE,
    env,
    adapter,
    host_os,
    labels: {
      'com.centurylinklabs.watchtower.scope': 'neuslice',
      'com.centurylinklabs.watchtower.enable': 'true',
    },
  }
}

// ── docker_create_and_start ───────────────────────────────────────────────────

async function docker_create_and_start(spec) {
  const { service_name, image, env, labels } = spec

  // Pull latest image first (best-effort — don't fail spawn if pull fails)
  try {
    log.info({ image }, 'Spawn: pulling image')
    await docker_request('POST', `/images/create?fromImage=${encodeURIComponent(image)}`)
    log.info({ image }, 'Spawn: image pull complete')
  } catch (err) {
    log.warn({ err: err.message }, 'Spawn: image pull failed — will use cached image')
  }

  // Create container
  log.info({ service_name }, 'Spawn: creating container')
  const create_res = await docker_request('POST', '/containers/create?name=' + service_name, {
    Image:        image,
    Env:          env,
    Labels:       labels,
    HostConfig: {
      RestartPolicy:   { Name: 'unless-stopped' },
      // Klipper adapters need LAN access to reach Moonraker (e.g. 192.168.x.x).
      // On Linux, host network mode gives the container full LAN access.
      // On Windows Docker Desktop, host mode is unsupported — fall back to bridge
      // which may not have LAN routing, but is the best available option.
      NetworkMode:     spec.adapter === 'klipper'
        ? (spec.host_os === 'linux' ? 'host' : 'bridge')
        : 'neuslice_neuslice_net',
      LogConfig: {
        Type: 'json-file',
        Config: { 'max-size': '10m', 'max-file': '3' },
      },
    },
  })

  const container_id = create_res.body?.Id
  if (!container_id) throw new Error('Docker create returned no container ID')

  // Start it
  await docker_request('POST', `/containers/${container_id}/start`)
  log.info({ service_name, container_id }, 'Spawn: container started')

  return { service_name, container_id }
}

// ── write_compose_block ───────────────────────────────────────────────────────
// Appends a new service block to docker-compose.yml so the spawned container
// survives docker compose down && up without manual editing.

function write_compose_block(spec, new_node_id, agent_token) {
  if (!fs.existsSync(PROJECT_DIR)) {
    log.warn({ PROJECT_DIR }, 'Spawn: project dir not mounted — skipping compose update')
    return
  }

  if (!fs.existsSync(COMPOSE_FILE)) {
    log.warn({ COMPOSE_FILE }, 'Spawn: docker-compose.yml not found — skipping compose update')
    return
  }

  // Build a separate .env file for the new printer instead of inlining secrets
  // in docker-compose.yml. This keeps compose clean and lets the owner edit it.
  const env_filename = `.env.${spec.service_name}`
  const env_path     = path.join(PROJECT_DIR, env_filename)

  // Build env file content from the spec's env array
  const env_lines = spec.env.map(e => e).join('\n')

  // Write with mode 0o600 (owner read/write only) so other processes on the
  // host cannot read adapter API keys and passwords from the env file. (SR-003)
  fs.writeFileSync(env_path, env_lines + '\n', { encoding: 'utf8', mode: 0o600 })
  log.info({ env_path }, 'Spawn: wrote env file (mode 0600)')

  // Build compose service block (indented 2 spaces as YAML).
  // SECURITY (SR-006): every interpolated value below is validated first —
  // service_name derives from a UUID-checked node id and spec.image passed the
  // repo allowlist + charset check in validate_spawn_config(), so no value can
  // inject additional YAML keys into the compose file.
  //
  // Networking must MATCH the live container created in docker_create_and_start:
  // klipper on native Linux runs with host networking (LAN access to Moonraker);
  // klipper on Docker Desktop falls back to bridge; everything else joins the
  // project network by name (resolves watchtower/docker-socket-proxy after a
  // compose down && up — the old hardcoded `bridge` could not).
  const network_yaml = spec.adapter === 'klipper'
    ? (spec.host_os === 'linux' ? 'network_mode: host' : 'network_mode: bridge')
    : 'networks:\n      - neuslice_net'
  const service_block = `
  # ── Auto-deployed by NeuSlice on ${new Date().toISOString().slice(0, 10)} ──
  ${spec.service_name}:
    image: ${spec.image}
    container_name: ${spec.service_name}
    restart: unless-stopped
    depends_on:
      watchtower:
        condition: service_started
      docker-socket-proxy:
        condition: service_started
    env_file:
      - ${env_filename}
    environment:
      NODE_ENV: production
      WATCHTOWER_HOST: watchtower
      WATCHTOWER_PORT: "8080"
      WATCHTOWER_HTTP_API_TOKEN: \${WATCHTOWER_HTTP_API_TOKEN:-}
      DOCKER_SOCKET: tcp://docker-socket-proxy:2375
    labels:
      com.centurylinklabs.watchtower.scope: neuslice
      com.centurylinklabs.watchtower.enable: "true"
    ${network_yaml}
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
`

  // Insert before the volumes: block (or append before end of file)
  let compose = fs.readFileSync(COMPOSE_FILE, 'utf8')

  const volumes_idx = compose.indexOf('\n# ── Volumes')
  if (volumes_idx !== -1) {
    compose = compose.slice(0, volumes_idx) + service_block + compose.slice(volumes_idx)
  } else {
    compose += service_block
  }

  fs.writeFileSync(COMPOSE_FILE, compose, 'utf8')
  log.info({ service_name: spec.service_name }, 'Spawn: docker-compose.yml updated')
}

// ── handle_spawn_agent ────────────────────────────────────────────────────────
/**
 * Called by agent.js when a SPAWN_AGENT message arrives from the backend.
 * Handles the full lifecycle and sends SPAWN_RESULT back via the send() fn.
 *
 * @param {object}   payload  - SPAWN_AGENT payload from backend
 * @param {function} send_fn  - function(type, payload) to send WS messages back
 */
export async function handle_spawn_agent(payload, send_fn) {
  const { spawn_id, new_node_id, adapter, adapter_env, image } = payload
  // Note: agent_token is destructured separately — never logged
  const { agent_token } = payload

  // Log spawn metadata only — adapter_env is never logged (contains secrets)
  log.info({ spawn_id, new_node_id, adapter }, 'SPAWN_AGENT received')

  try {
    const spec = await build_container_spec({ new_node_id, agent_token, adapter, adapter_env, image })

    // 1. Create and start the Docker container
    const { container_id } = await docker_create_and_start(spec)

    // 2. Write compose block for persistence (best-effort — don't fail spawn)
    try {
      write_compose_block(spec, new_node_id, agent_token)
    } catch (err) {
      log.warn({ err: err.message }, 'Spawn: compose update failed — container running but compose not updated')
    }

    // 3. Report success
    send_fn('SPAWN_RESULT', { spawn_id, success: true, container_id })
    log.info({ spawn_id, new_node_id, container_id }, 'SPAWN_AGENT complete')

  } catch (err) {
    log.error({ spawn_id, new_node_id, err: err.message }, 'SPAWN_AGENT failed')
    send_fn('SPAWN_RESULT', { spawn_id, success: false, error: err.message })
  }
}
