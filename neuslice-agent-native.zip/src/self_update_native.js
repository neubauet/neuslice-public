import log from './logger.js'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'
import { FEED_URL, PINNED_PUBLISHER, is_forward_version, validate_release_asset } from './windows_release.js'
export { is_forward_version, publisher_matches } from './windows_release.js'

const execFileP = promisify(execFile)
const scripts = fileURLToPath(new URL('./windows/', import.meta.url))
const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
const psLiteral = value => "'" + String(value).replaceAll("'", "''") + "'"

// Synchronous reservation: no job callback can interleave idle check and pause.
export function reserve_idle_agents(agents) {
  if (!agents.length || agents.some(a => a.is_busy() || a.pending_job || a.bambuddy_migration_running || a.update_reserved || !a.resume_check_complete)) return null
  for (const agent of agents) agent.update_reserved = true
  return () => { for (const agent of agents) agent.update_reserved = false }
}

export function make_native_do_update({ updater, reserveIdle, refreshIdle, logger = log } = {}) {
  return async function doUpdate(image) {
    void image // notifications trigger a check, never choose a URL
    let helper, release, committed = false
    try {
      const info = await updater.checkForUpdate()
      if (!info) return 'no-update'
      const current = await updater.currentVersion()
      if (!is_forward_version(info.version, current)) throw new Error('Refusing invalid/non-forward version')
      await updater.download(info)
      if (!await updater.verifyPublisher(info)) throw new Error('Package authentication failed')
      await refreshIdle?.()
      helper = await updater.prepareApply(info)
      // Work can arrive during download/verification. Check again before commit.
      release = reserveIdle()
      if (!release) { await helper.cancel(); return }
      await helper.commit()
      committed = true
      logger.info({ version: info.version }, '[native-update] verified update committed to service manager')
      // SCM stop invokes the existing sentinel drain, then the detached helper
      // applies and restarts. Do not exit before SCM marks the service stopping.
      await helper.waitForStop()
    } catch (err) {
      if (err.safeToResume) committed = false
      logger.error({ err: err.message }, '[native-update] update failed; will retry')
      if (helper) await helper.cancel().catch(e => logger.error({ err: e.message }, '[native-update] cancellation failed'))
    } finally {
      // Once SCM owns the stop, a timeout is not proof it is safe to accept work.
      // Keep the reservation until shutdown unless the helper confirms recovery.
      if (!committed) release?.()
    }
  }
}

export async function verify_package_publisher(packagePath, catalogPath, publisher = PINNED_PUBLISHER) {
  const { stdout } = await execFileP(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', path.join(scripts, 'verify-package.ps1'), '-PackagePath', packagePath,
    '-CatalogPath', catalogPath, '-Publisher', publisher], { timeout: 60_000, windowsHide: true })
  return stdout.trim() === 'Verified'
}

async function download_catalog(fileName, destination) {
  const response = await fetch(new URL(fileName + '.cat', FEED_URL), {
    redirect: 'error', signal: AbortSignal.timeout(30_000),
  })
  if (!response.ok) throw new Error('Catalog download failed (' + response.status + ')')
  const chunks = []
  let size = 0
  for await (const chunk of response.body) {
    size += chunk.length
    if (size > 1024 * 1024) throw new Error('Release catalog exceeds size limit')
    chunks.push(chunk)
  }
  fs.writeFileSync(destination, Buffer.concat(chunks))
}

async function prepare_service_apply(root, info, packagePath, catalogPath) {
  const workRoot = path.join(root, 'update-work')
  fs.mkdirSync(workRoot, { recursive: true })
  const work = fs.mkdtempSync(path.join(workRoot, 'apply-'))
  for (const name of ['apply-update.ps1', 'verify-package.ps1']) fs.copyFileSync(path.join(scripts, name), path.join(work, name))
  const requestPath = path.join(work, 'request.json')
  fs.writeFileSync(requestPath, JSON.stringify({ root, package: packagePath, catalog: catalogPath,
    publisher: PINNED_PUBLISHER, version: info.version, service: 'neuslice-agent' }))
  const command = '& ' + psLiteral(path.join(work, 'apply-update.ps1')) + ' -RequestPath ' + psLiteral(requestPath)
  const encoded = Buffer.from(command, 'utf16le').toString('base64')
  // WMI creates the helper outside WinSW's process tree so service stop cannot
  // kill its own updater. The encoded command contains only local paths.
  const commandLine = '"' + powershell + '" -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand ' + encoded
  const launch = "$r=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=" + psLiteral(commandLine) + "};if($r.ReturnValue -ne 0){throw 'Could not launch update helper'}"
  await execFileP(powershell, ['-NoProfile', '-NonInteractive', '-Command', launch], { timeout: 15_000, windowsHide: true })
  const cancel = async () => { fs.writeFileSync(path.join(work, 'cancel'), 'cancel') }
  try {
    const deadline = Date.now() + 75_000
    while (!fs.existsSync(path.join(work, 'ready'))) {
      if (fs.existsSync(path.join(work, 'result.log'))) throw new Error(fs.readFileSync(path.join(work, 'result.log'), 'utf8'))
      if (Date.now() > deadline) throw new Error('Update helper readiness timed out')
      await delay(100)
    }
  } catch (err) { await cancel(); throw err }
  return {
    cancel,
    async commit() { fs.writeFileSync(path.join(work, 'commit'), 'commit') },
    async waitForStop() {
      for (let i = 0; i < 600; i++) {
        if (fs.existsSync(path.join(work, 'result.log'))) {
          const err = new Error(fs.readFileSync(path.join(work, 'result.log'), 'utf8'))
          err.safeToResume = fs.existsSync(path.join(work, 'resume-safe'))
          throw err
        }
        await delay(100)
      }
      throw new Error('Service did not stop within 60 seconds')
    },
  }
}

export function create_velopack_updater() {
  // Legacy installs/checkouts are not Velopack installs. Derive paths from the
  // executable, never LocalSystem's LOCALAPPDATA.
  if (process.platform !== 'win32') return null
  const current = path.dirname(process.execPath), root = path.dirname(current)
  if (path.basename(current).toLowerCase() !== 'current' || !fs.existsSync(path.join(root, 'Update.exe'))
      || !fs.existsSync(path.join(root, 'service', 'neuslice-agent.exe'))) return null
  const locator = { RootAppDir: root, UpdateExePath: path.join(root, 'Update.exe'),
    PackagesDir: path.join(root, 'packages'), ManifestPath: path.join(current, 'sq.version'),
    CurrentBinaryDir: current, IsPortable: false }
  let mgr
  const manager = async () => {
    if (!mgr) {
      const { UpdateManager, HttpSource } = await import('velopack')
      mgr = new UpdateManager(new HttpSource(FEED_URL, { Headers: [], TimeoutMilliseconds: 120_000 }),
        { AllowVersionDowngrade: false, MaximumDeltasBeforeFallback: -1, ExplicitChannel: 'win' }, locator)
    }
    return mgr
  }
  const asset = info => validate_release_asset(info._raw.TargetFullRelease)
  const packagePath = info => path.join(locator.PackagesDir, asset(info).FileName)
  const catalogPath = info => packagePath(info) + '.cat'
  return {
    async currentVersion() { return (await manager()).getCurrentVersion() },
    async checkForUpdate() {
      const info = await (await manager()).checkForUpdatesAsync()
      if (!info || info.IsDowngrade) return null
      validate_release_asset(info.TargetFullRelease)
      return { version: info.TargetFullRelease.Version, _raw: { ...info, DeltasToTarget: [] } }
    },
    async download(info) {
      asset(info)
      await (await manager()).downloadUpdateAsync(info._raw)
      await download_catalog(asset(info).FileName, catalogPath(info))
    },
    async verifyPublisher(info) { return verify_package_publisher(packagePath(info), catalogPath(info)) },
    async prepareApply(info) { return prepare_service_apply(root, info, packagePath(info), catalogPath(info)) },
  }
}
