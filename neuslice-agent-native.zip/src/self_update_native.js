/*
 * self_update_native.js — the native (Windows / Velopack) self-update seam
 * (spec §3.5 / SMA-N6). Linux keeps Watchtower (self_update.js); this is the Windows
 * `doUpdate` the supervisor's all-idle gate (update_gate.js) calls.
 *
 * SMA-N6 (amended 2026-07-30 — Velopack/Authenticode). Apply an update only if:
 *   - it comes from the CONSTANT compiled-in feed, NEVER from UPDATE_AVAILABLE.image
 *     (the `image` arg is accepted for the gate's signature and deliberately ignored);
 *   - it moves FORWARD — never below the installed version (defense-in-depth on top of
 *     Velopack's own forward-only selection);
 *   - its staged artifact is Authenticode-signed by NeuSlice's PINNED publisher
 *     (Velopack/OS enforce the signature; we additionally pin the publisher identity).
 * The all-idle gate guarantees this runs only when every Agent is idle, so — and only
 * once every check passes — we drain and hand off to Velopack, which applies + relaunches.
 *
 * The POLICY (make_native_do_update) is separated from the concrete Velopack binding so
 * the SMA-N6 rejection legs are unit-testable with a fake updater — a fake proves the
 * decision ROUTING, not the OS crypto. The Authenticode publisher check itself is
 * `publisher_matches` (a pure, unit-tested comparator) wrapped by `verify_package_publisher`
 * (extracts the staged package's exe and shells to Get-AuthenticodeSignature). It can be
 * validated end-to-end with a SELF-SIGNED cert (packaging/windows/sign-selftest.ps1 +
 * Procedure C) — no paid cert needed. create_velopack_updater() returns null until the
 * FEED_URL + PINNED_PUBLISHER constants are set (the paid-cert-followup is then just those
 * two values + the CI signing params — no code change).
 */

import log from './logger.js'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const execFileP = promisify(execFile)

/**
 * Forward-only version compare: true iff `candidate` is strictly newer than `current`.
 * Simple numeric dot-part compare (our releases are numeric SemVer); on a non-numeric
 * part it falls back to a string compare so it never throws.
 */
export function is_forward_version(candidate, current) {
  const parse = (v) => String(v ?? '').split('.').map((p) => parseInt(p, 10))
  const a = parse(candidate)
  const b = parse(current)
  const n = Math.max(a.length, b.length)
  for (let i = 0; i < n; i++) {
    const x = a[i] ?? 0
    const y = b[i] ?? 0
    if (Number.isNaN(x) || Number.isNaN(y)) return String(candidate) > String(current)
    if (x !== y) return x > y
  }
  return false // equal ⇒ not forward
}

/**
 * Build the native `doUpdate(image)` for the all-idle gate.
 *
 * @param {object}   o
 * @param {object}   o.updater   the concrete adapter (see create_velopack_updater's
 *   contract): checkForUpdate(), currentVersion(), download(info), verifyPublisher(info),
 *   armApplyOnExit(info).
 * @param {function} [o.drain]   async (signal) => drain every Agent (shutdown_all).
 * @param {function} [o.exit]    () => terminate the process (Velopack's Update.exe,
 *   armed by armApplyOnExit, then applies + relaunches). Injectable for tests.
 * @param {object}   [o.logger]
 * @returns {function(string):Promise<void>} doUpdate — resolves (gate retries) on any
 *   refusal/failure; on success it exits and never returns.
 */
export function make_native_do_update({ updater, drain, exit = () => process.exit(0), logger = log } = {}) {
  return async function doUpdate(image) {
    // `image` (from UPDATE_AVAILABLE) is informational only and is NEVER a download
    // source — the feed is the constant one baked into the updater (SMA-N6).
    void image

    let info
    try {
      info = await updater.checkForUpdate()
    } catch (err) {
      logger.warn?.({ err: err?.message }, '[native-update] update check failed — will retry')
      return
    }
    if (!info || !info.version) {
      logger.info?.('[native-update] no update available on the feed')
      return
    }

    const current = await updater.currentVersion?.()
    if (current && !is_forward_version(info.version, current)) {
      logger.warn?.({ candidate: info.version, current },
        '[native-update] refusing a non-forward version (SMA-N6 no-downgrade)')
      return
    }

    // Velopack hash-checks the package against the feed during download; a mismatch
    // throws here and we refuse (never apply a tampered package).
    try {
      await updater.download(info)
    } catch (err) {
      logger.warn?.({ err: err?.message }, '[native-update] download/hash-verify failed — will retry')
      return
    }

    let publisher_ok = false
    try {
      publisher_ok = await updater.verifyPublisher(info)
    } catch (err) {
      logger.error?.({ err: err?.message }, '[native-update] publisher check errored — refusing update')
      return
    }
    if (!publisher_ok) {
      logger.error?.('[native-update] staged artifact publisher ≠ pinned NeuSlice cert — refusing (SMA-N6)')
      return
    }

    // Arm Velopack to apply-on-exit BEFORE draining, so a failure to arm never leaves
    // the host drained-but-not-restarting. Only after it is armed do we drain + exit.
    try {
      await updater.armApplyOnExit(info)
    } catch (err) {
      logger.warn?.({ err: err?.message }, '[native-update] could not arm apply-on-exit — will retry')
      return
    }

    logger.info?.({ version: info.version }, '[native-update] signed update staged — draining, then Velopack applies + relaunches')
    if (drain) await drain('SELF_UPDATE')
    await exit(0) // Update.exe (armed above) applies + relaunches after we exit
  }
}

// ── Authenticode publisher pin (SMA-N6) ───────────────────────────────────────

/**
 * Pure comparator: does a Get-AuthenticodeSignature result satisfy the pin? Fails
 * CLOSED — the signature must be **Valid** (chain-trusted + intact) AND the signer must
 * match the pin, either by **Thumbprint** (the robust key — hex, case/space-insensitive)
 * or by **Subject** (exact, or the pinned value as a `CN=` component, a convenience
 * fallback). An untrusted/tampered signature never matches even if the subject text does.
 *
 * Exported so every accept/reject leg is unit-tested without any real signing.
 *
 * @param {{status:string, subject?:string, thumbprint?:string}} sig
 * @param {string} pinned  PINNED_PUBLISHER — prefer the cert THUMBPRINT.
 */
export function publisher_matches(sig, pinned) {
  if (!sig || !pinned) return false
  if (String(sig.status) !== 'Valid') return false // fail closed on any non-trusted status
  const norm = (s) => String(s ?? '').replace(/\s+/g, '').toUpperCase()
  const p = norm(pinned)
  if (!p) return false
  if (sig.thumbprint && norm(sig.thumbprint) === p) return true // thumbprint (robust)
  const subj = norm(sig.subject)
  if (subj && (subj === p || subj.includes(norm('CN=' + pinned)))) return true // subject fallback
  return false
}

/** Read the Authenticode signature of a PE via PowerShell. Returns {status, subject, thumbprint}. */
async function get_authenticode_signature(peFilePath) {
  if (peFilePath.includes("'")) throw new Error('unexpected quote in PE path')
  const ps =
    `$ErrorActionPreference='Stop';$s=Get-AuthenticodeSignature -LiteralPath '${peFilePath}';` +
    `[pscustomobject]@{status=[string]$s.Status;subject=[string]$s.SignerCertificate.Subject;` +
    `thumbprint=[string]$s.SignerCertificate.Thumbprint}|ConvertTo-Json -Compress`
  const { stdout } = await execFileP('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { timeout: 20_000 })
  const p = JSON.parse(stdout.trim())
  return { status: p.status ?? '', subject: p.subject ?? '', thumbprint: p.thumbprint ?? '' }
}

/**
 * Extract the app exe from a staged Velopack package (.nupkg is a zip) and verify its
 * Authenticode publisher against the pin. Fails closed on any missing/odd input.
 */
async function verify_package_publisher(nupkgPath, mainExe, pinned) {
  if (!fs.existsSync(nupkgPath)) { log.error?.({ nupkgPath }, '[native-update] staged package not found — refusing'); return false }
  const AdmZip = (await import('adm-zip')).default
  const entry = new AdmZip(nupkgPath).getEntries()
    .find((e) => !e.isDirectory && path.basename(e.entryName).toLowerCase() === mainExe.toLowerCase())
  if (!entry) { log.error?.({ mainExe }, '[native-update] app exe not found inside the package — refusing'); return false }

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'neuslice-verify-'))
  const pe = path.join(dir, mainExe)
  try {
    fs.writeFileSync(pe, entry.getData())
    const sig = await get_authenticode_signature(pe)
    const ok = publisher_matches(sig, pinned)
    if (!ok) log.error?.({ status: sig.status, subject: sig.subject }, '[native-update] staged exe publisher ≠ pin')
    return ok
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }) } catch { /* ignore */ }
  }
}

// ── Concrete Velopack adapter (verified against velopack@1.2.110 types) ────────
//
// The update source (SMA-N6): a CONSTANT compiled-in HTTPS feed and the pinned
// code-signing publisher. Empty here ⇒ create_velopack_updater() returns null and native
// auto-update is inert (the service still runs). Fill both to activate it: the paid-cert
// step is JUST these two values + the CI `--signParams` — verifyPublisher is already
// implemented and self-signed-testable (Procedure C / sign-selftest.ps1). Prefer the cert
// THUMBPRINT for PINNED_PUBLISHER.
const FEED_URL = '' // the constant HTTPS release feed (SMA-N6)
const PINNED_PUBLISHER = '' // NeuSlice code-signing cert thumbprint (or subject)
const MAIN_EXE = 'neuslice-agent.exe' // pack.ps1 --mainExe; the PE inside the .nupkg we pin-check

/**
 * The concrete adapter over the `velopack` npm binding (Windows). `velopack` is an
 * optionalDependency, lazily imported so the native addon never loads on Linux/CI and
 * a missing binding never crashes the agent. Returns null when no feed is configured.
 *
 * Field casing note: velopack's JS types use PascalCase on the asset/info objects
 * (info.TargetFullRelease.Version, info.IsDowngrade), while getCurrentVersion() and
 * waitExitThenApplyUpdate() are SYNCHRONOUS.
 */
export function create_velopack_updater() {
  if (!FEED_URL) return null // no feed configured ⇒ inert

  let mgr = null
  const manager = async () => {
    if (!mgr) {
      const velo = await import('velopack')
      // A bare URL string auto-detects to HttpSource. AllowVersionDowngrade:false is
      // Velopack's default forward-only behavior (SMA-N6 no-downgrade), stated explicitly.
      mgr = new velo.UpdateManager(FEED_URL, { AllowVersionDowngrade: false })
    }
    return mgr
  }

  return {
    async currentVersion() {
      return (await manager()).getCurrentVersion()
    },
    async checkForUpdate() {
      const m = await manager()
      const info = await m.checkForUpdatesAsync()
      if (!info) return null
      // Velopack itself flags a downgrade/lateral move; refuse it (belt with the seam's
      // is_forward_version brace) — SMA-N6 forward-only.
      if (info.IsDowngrade) {
        log.warn?.('[native-update] feed offered a downgrade/lateral move — ignoring (SMA-N6)')
        return null
      }
      const version = info?.TargetFullRelease?.Version ?? null
      return version ? { version, _raw: info } : null
    },
    async download(info) {
      // Velopack verifies the package SHA against the feed during download.
      await (await manager()).downloadUpdateAsync(info._raw)
    },
    async verifyPublisher(info) {
      // SMA-N6: the staged artifact's Authenticode publisher must equal the pinned
      // NeuSlice cert. Fail CLOSED without a pin, so an unsigned build never applies.
      if (!PINNED_PUBLISHER) {
        log.warn?.('[native-update] unsigned build (no pinned publisher) — refusing to auto-apply (SMA-N6)')
        return false
      }
      // Locate the staged package: %LocalAppData%\<appId>\packages\<TargetFullRelease.FileName>.
      const m = await manager()
      const appId = m.getAppId?.()
      const fileName = info?._raw?.TargetFullRelease?.FileName
      const localAppData = process.env.LOCALAPPDATA
      if (!appId || !fileName || !localAppData) {
        log.error?.({ appId, fileName, hasLocalAppData: !!localAppData },
          '[native-update] cannot locate the staged package — refusing')
        return false
      }
      const nupkgPath = path.join(localAppData, appId, 'packages', fileName)
      return verify_package_publisher(nupkgPath, MAIN_EXE, PINNED_PUBLISHER)
    },
    async armApplyOnExit(info) {
      // waitExitThenApplyUpdate is SYNC: it arms Update.exe to wait for our exit; then
      // (back in the seam) we drain + exit and Update.exe applies + relaunches.
      const m = await manager()
      m.waitExitThenApplyUpdate(info._raw, /* silent */ true, /* restart */ true)
    },
  }
}
