import { test } from 'node:test'
import assert from 'node:assert/strict'
import { is_forward_version, make_native_do_update, create_velopack_updater, publisher_matches } from './self_update_native.js'

/*
 * SMA-N6 (Velopack/Authenticode) rejection legs for the native self-updater POLICY.
 * These use a fake updater, so they prove the decision ROUTING — never apply on a
 * downgrade / tampered package / wrong publisher, and never treat UPDATE_AVAILABLE.image
 * as a source — NOT the OS Authenticode crypto, which is proven on the packaged app
 * (PR-3). A silent logger keeps the suite output clean.
 */

const quietLog = { info() {}, warn() {}, error() {} }

/** A recording fake of the concrete adapter contract. */
function makeUpdater(over = {}) {
  const calls = { check: 0, current: 0, download: [], verify: [], arm: [] }
  return {
    calls,
    async checkForUpdate() { calls.check++; if (over.checkThrows) throw new Error('feed unreachable'); return over.info ?? null },
    async currentVersion() { calls.current++; return over.current ?? '1.0.0' },
    async download(info) { calls.download.push(info); if (over.downloadThrows) throw new Error('hash mismatch') },
    async verifyPublisher(info) { calls.verify.push(info); if (over.verifyThrows) throw new Error('signtool error'); return over.publisherOk ?? true },
    async armApplyOnExit(info) { calls.arm.push(info); if (over.armThrows) throw new Error('cannot arm') },
  }
}

function harness(over = {}) {
  const events = []
  const updater = makeUpdater(over)
  const doUpdate = make_native_do_update({
    updater,
    drain: async (sig) => events.push(`drain:${sig}`),
    exit: async () => events.push('exit'),
    logger: quietLog,
  })
  return { doUpdate, updater, events }
}

// ── is_forward_version ────────────────────────────────────────────────────────

test('is_forward_version: newer is forward, equal/older are not', () => {
  assert.equal(is_forward_version('1.1.0', '1.0.9'), true)
  assert.equal(is_forward_version('2.0.0', '1.9.9'), true)
  assert.equal(is_forward_version('1.0.10', '1.0.9'), true)
  assert.equal(is_forward_version('1.0.0', '1.0.0'), false, 'equal is not forward')
  assert.equal(is_forward_version('1.0.0', '1.1.0'), false, 'a downgrade is not forward')
  assert.equal(is_forward_version('1.2.3', '1.2.3.1'), false, 'a shorter equal-prefix is not newer')
})

// ── happy path ────────────────────────────────────────────────────────────────

test('applies a newer signed update: arms apply-on-exit, THEN drains, THEN exits', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '1.1.0' }, current: '1.0.0', publisherOk: true })
  await doUpdate('registry/img:whatever')
  assert.deepEqual(events, ['drain:SELF_UPDATE', 'exit'], 'arm precedes drain precedes exit')
  assert.equal(updater.calls.arm.length, 1, 'armed exactly once')
  assert.equal(updater.calls.download.length, 1)
  assert.equal(updater.calls.verify.length, 1)
})

// ── SMA-N6 rejection legs ───────────────────────────────────────────────────────

test('no update on the feed → nothing downloaded, drained, or exited', async () => {
  const { doUpdate, updater, events } = harness({ info: null })
  await doUpdate('x')
  assert.deepEqual(events, [])
  assert.equal(updater.calls.download.length, 0)
  assert.equal(updater.calls.arm.length, 0)
})

test('a non-forward version (downgrade) is refused before download', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '0.9.0' }, current: '1.0.0' })
  await doUpdate('x')
  assert.deepEqual(events, [], 'never drains/exits on a downgrade')
  assert.equal(updater.calls.download.length, 0, 'a downgrade is refused before download')
  assert.equal(updater.calls.arm.length, 0)
})

test('a download/hash failure is refused — no arm, no drain, no exit', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '1.1.0' }, current: '1.0.0', downloadThrows: true })
  await doUpdate('x')
  assert.deepEqual(events, [])
  assert.equal(updater.calls.verify.length, 0, 'never reaches publisher check')
  assert.equal(updater.calls.arm.length, 0)
})

test('a publisher mismatch is refused AND does not drain (never drain if we will not restart)', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '1.1.0' }, current: '1.0.0', publisherOk: false })
  await doUpdate('x')
  assert.deepEqual(events, [], 'a wrong-publisher artifact must not drain or exit')
  assert.equal(updater.calls.arm.length, 0, 'never armed on a publisher mismatch')
})

test('a publisher-check error is refused (fail closed), no drain/exit', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '1.1.0' }, current: '1.0.0', verifyThrows: true })
  await doUpdate('x')
  assert.deepEqual(events, [])
  assert.equal(updater.calls.arm.length, 0)
})

test('a check failure is swallowed so the gate retries (no throw)', async () => {
  const { doUpdate, events } = harness({ checkThrows: true })
  await doUpdate('x') // must resolve, not throw — the gate treats a return as "retry"
  assert.deepEqual(events, [])
})

test('failing to arm apply-on-exit does NOT drain (no drained-but-not-restarting host)', async () => {
  const { doUpdate, updater, events } = harness({ info: { version: '1.1.0' }, current: '1.0.0', armThrows: true })
  await doUpdate('x')
  assert.deepEqual(events, [], 'if we cannot arm the restart, we must not drain')
  assert.equal(updater.calls.arm.length, 1, 'arm was attempted')
})

test('UPDATE_AVAILABLE.image is never used as a source (behavior identical for any image)', async () => {
  const a = harness({ info: { version: '1.1.0' }, current: '1.0.0' })
  await a.doUpdate('evil.example/malware:latest')
  const b = harness({ info: { version: '1.1.0' }, current: '1.0.0' })
  await b.doUpdate(undefined)
  // Same outcome regardless of the image arg, and checkForUpdate takes no image.
  assert.deepEqual(a.events, b.events)
  assert.deepEqual(a.events, ['drain:SELF_UPDATE', 'exit'])
})

// ── publisher_matches: the SMA-N6 Authenticode pin comparator (pure; no signing) ──
// A fake proves the DECISION, not the OS crypto — the real Get-AuthenticodeSignature +
// end-to-end apply are proven with a self-signed cert (Procedure C / sign-selftest.ps1).

test('publisher_matches: Valid + matching thumbprint (case/space-insensitive) → true', () => {
  assert.equal(publisher_matches({ status: 'Valid', thumbprint: 'AB CD ef 12', subject: 'CN=X' }, 'abcdef12'), true)
})

test('publisher_matches: Valid + pinned CN present in the subject → true', () => {
  assert.equal(publisher_matches({ status: 'Valid', subject: 'CN=NeuSlice, O=NeuSlice LLC', thumbprint: 'ZZ' }, 'NeuSlice'), true)
})

test('publisher_matches: Valid + exact full subject → true', () => {
  assert.equal(publisher_matches({ status: 'Valid', subject: 'CN=NeuSlice, O=NeuSlice LLC', thumbprint: 'ZZ' }, 'CN=NeuSlice, O=NeuSlice LLC'), true)
})

test('publisher_matches: a NON-Valid status fails closed even if the subject/thumbprint match', () => {
  for (const status of ['NotSigned', 'HashMismatch', 'NotTrusted', 'UnknownError', 'Incompatible']) {
    assert.equal(publisher_matches({ status, subject: 'CN=NeuSlice', thumbprint: 'ABCD' }, 'ABCD'), false, status)
  }
})

test('publisher_matches: wrong thumbprint AND wrong subject → false', () => {
  assert.equal(publisher_matches({ status: 'Valid', thumbprint: 'ABCD', subject: 'CN=Someone Else' }, 'DCBA'), false)
})

test('publisher_matches: empty pin, or missing sig → false (fail closed)', () => {
  assert.equal(publisher_matches({ status: 'Valid', thumbprint: 'ABCD' }, ''), false)
  assert.equal(publisher_matches(null, 'ABCD'), false)
  assert.equal(publisher_matches({ status: 'Valid' }, 'ABCD'), false)
})

// ── concrete adapter is inert (and never loads the native binding) until a feed is set ──

test('create_velopack_updater returns null with no feed configured, without importing velopack', () => {
  // FEED_URL ships empty (cert-followup fills it), so this must short-circuit to null
  // BEFORE any dynamic import of the optional native binding — safe on Linux/CI.
  assert.equal(create_velopack_updater(), null)
})
