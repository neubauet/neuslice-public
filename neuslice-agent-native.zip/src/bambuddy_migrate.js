/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * bambuddy_migrate.js — one-click "migrate the data, then upgrade Bambuddy".
 *
 * WHY THIS EXISTS
 * Bambuddy's DATA_DIR is /app/data, but our compose mounted the named volume at
 * /data until 2026-09-04. On those nodes the volume is empty and the database,
 * archives and secrets live in the container's writable layer — which Docker
 * discards the moment the container is recreated. Upgrading the image recreates
 * the container. So on an un-migrated node "pull a newer Bambuddy" and "destroy
 * the print history" are the same action, and they have to be done together,
 * in the right order, or not at all.
 *
 * THE ORDER IS THE SAFETY
 * The old container is the ONLY copy of that data until the volume is seeded and
 * verified. So it is never removed — it is renamed and kept as a stopped
 * rollback artifact. Nothing destructive happens before the copy is proven:
 *
 *   preflight -> pull -> stop -> export -> seed -> VERIFY -> rename -> create
 *   -> start -> rewrite compose -> health check
 *
 * If verification fails, the old container is restarted under its own name and
 * the node is left exactly as it was found.
 *
 * WHAT THE DOCKER SOCKET PROXY ALLOWS (probed 2026-09-04 against the real proxy
 * with the production env — CONTAINERS=1, POST=1, IMAGES=1, everything else 0):
 * inspect, archive GET/PUT, create, start, stop, wait, logs, rename and delete
 * are all permitted; the /volumes API is 403 and is never used. `EXEC=0`, so
 * there is no shell into a running container — every file operation here goes
 * through the archive endpoints or a helper container's own command.
 */
import http from 'http'
import { parse_docker_socket } from './docker_socket.js'
import { detect_bambuddy, CORRECT_DATA_MOUNT, LEGACY_DATA_MOUNT } from './bambuddy_status.js'
import log from './logger.js'

const DOCKER_SOCKET = process.env.DOCKER_SOCKET ?? 'tcp://docker-socket-proxy:2375'

// The version this migration targets. Pinned, not `latest`: an unpinned tag
// turns a button the owner pressed into "install whatever shipped this morning".
export const DEFAULT_TARGET_IMAGE = 'maziggy/bambuddy:1.2.5.5'

// Where the archive is staged inside the helper before it is copied onto the
// volume. Must already exist in the helper image — the archive PUT extracts
// into an existing directory and will not create the path itself.
const STAGE_DIR = '/tmp'

/* ── tar ────────────────────────────────────────────────────────────────────
 * Just enough tar to list what is in an archive. Used to prove the bytes that
 * left the old container are the bytes that landed on the volume, rather than
 * trusting an exit code — the whole class of bug this feature exists to avoid.
 * Reading names is all that is needed, so this is a header walk, not a parser.
 */
export function list_tar_entries(buf) {
  const names = []
  if (!Buffer.isBuffer(buf)) return names
  for (let off = 0; off + 512 <= buf.length;) {
    const header = buf.subarray(off, off + 512)
    // Two consecutive zero blocks terminate a tar archive.
    if (header.every(b => b === 0)) break
    const raw = header.subarray(0, 100)
    const end = raw.indexOf(0)
    const name = raw.subarray(0, end === -1 ? 100 : end).toString('utf8')
    // Size is octal, space/NUL padded. A malformed field must not spin the loop.
    const size = parseInt(header.subarray(124, 136).toString('utf8').replace(/[\0 ]/g, ''), 8)
    if (!Number.isFinite(size) || size < 0) break
    if (name) names.push(name)
    off += 512 + Math.ceil(size / 512) * 512
  }
  return names
}

/** Strip the archive's leading directory component: `data/x` -> `x`. */
export function strip_leading_dir(names) {
  return names
    .map(n => n.replace(/^[^/]+\/+/, ''))
    .filter(n => n && n !== './')
    .map(n => n.replace(/\/+$/, ''))
}

/* ── docker transport ───────────────────────────────────────────────────── */

function docker_io(method, path, { body = null, content_type = 'application/json', binary = false } = {}) {
  return new Promise((resolve, reject) => {
    let transport
    try { transport = parse_docker_socket(DOCKER_SOCKET) } catch (err) { return reject(err) }
    const headers = {}
    if (body != null) {
      headers['Content-Type'] = content_type
      headers['Content-Length'] = Buffer.byteLength(body)
    }
    const req = http.request({ ...transport, path, method, headers }, res => {
      const chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => {
        const raw = Buffer.concat(chunks)
        if (res.statusCode >= 400) {
          return reject(new Error(`Docker ${method} ${path} → ${res.statusCode}: ${raw.toString('utf8').slice(0, 300)}`))
        }
        if (binary) return resolve({ status: res.statusCode, buffer: raw })
        const text = raw.toString('utf8')
        try { resolve({ status: res.statusCode, body: text ? JSON.parse(text) : null }) }
        catch { resolve({ status: res.statusCode, body: text }) }
      })
    })
    req.on('error', reject)
    if (body != null) req.write(body)
    req.end()
  })
}

/** The real Docker IO surface. Injected in tests so nothing here needs Docker. */
export function create_docker_io() {
  return {
    request: (method, path, body = null) =>
      docker_io(method, path, { body: body == null ? null : JSON.stringify(body) }),
    // The archive endpoints are raw tar, NOT JSON. The Content-Type below is
    // load-bearing: without `application/x-tar` the PUT returns 200 and
    // extracts nothing at all (verified against a live daemon 2026-09-04).
    archive_get: async (container, path) =>
      (await docker_io('GET', `/containers/${encodeURIComponent(container)}/archive?path=${encodeURIComponent(path)}`, { binary: true })).buffer,
    archive_put: (container, path, tar) =>
      docker_io('PUT', `/containers/${encodeURIComponent(container)}/archive?path=${encodeURIComponent(path)}`,
        { body: tar, content_type: 'application/x-tar' }),
  }
}

/* ── container config ───────────────────────────────────────────────────── */

/**
 * Build the create-config for the replacement container from the old one.
 *
 * Carries forward everything the owner or compose set — env, ports, restart
 * policy, labels, networks — and changes exactly three things: the image, the
 * data mount, and the healthcheck path. Cmd and Entrypoint are deliberately NOT
 * copied: they belong to the image, and pinning the old image's command onto a
 * new one is how an upgrade silently keeps running the old startup path.
 *
 * @param {object} old       docker inspect body of the existing container
 * @param {object} opts
 * @param {string} opts.image     target image reference
 * @param {string} opts.volume    named volume holding Bambuddy's data
 */
export function build_new_container_config(old, { image, volume }) {
  const cfg = old?.Config ?? {}
  const host = old?.HostConfig ?? {}

  // Keep every bind except whichever one was the data mount — that is replaced
  // by the same volume at the correct destination.
  const keep_binds = (host.Binds ?? []).filter(b => {
    const dest = String(b).split(':')[1]
    return dest !== LEGACY_DATA_MOUNT && dest !== CORRECT_DATA_MOUNT
  })

  const endpoints = old?.NetworkSettings?.Networks ?? {}
  const EndpointsConfig = {}
  for (const [net, ep] of Object.entries(endpoints)) {
    // Aliases only. IP/MAC are the daemon's to assign; replaying them can
    // collide with an address it has since handed to something else.
    const aliases = (ep?.Aliases ?? []).filter(a => typeof a === 'string')
    EndpointsConfig[net] = aliases.length ? { Aliases: aliases } : {}
  }

  return {
    Image: image,
    Env: cfg.Env ?? [],
    Labels: cfg.Labels ?? {},
    ExposedPorts: cfg.ExposedPorts ?? {},
    // /health, not /api/v1/health — the latter is a 404 on every Bambuddy build
    // ever released, so the old check could only ever report unhealthy.
    Healthcheck: {
      Test: ['CMD', 'curl', '-sf', 'http://localhost:8000/health'],
      Interval: 30_000_000_000,
      Timeout: 10_000_000_000,
      Retries: 5,
      StartPeriod: 20_000_000_000,
    },
    // 1.2.5 made uvicorn PID 1 so it finally receives SIGTERM; give it the same
    // 30s the compose file does, or teardown is clipped with no WAL checkpoint.
    StopTimeout: 30,
    HostConfig: {
      Binds: [...keep_binds, `${volume}:${CORRECT_DATA_MOUNT}`],
      PortBindings: host.PortBindings ?? {},
      RestartPolicy: host.RestartPolicy ?? { Name: 'unless-stopped' },
      NetworkMode: host.NetworkMode ?? 'default',
      LogConfig: host.LogConfig ?? undefined,
    },
    NetworkingConfig: Object.keys(EndpointsConfig).length ? { EndpointsConfig } : undefined,
  }
}

/**
 * Rewrite the bambuddy service in the owner's docker-compose.yml.
 *
 * Without this the migration is undone by the owner's next `docker compose
 * up -d`: compose would recreate the container from a file that still says
 * `/data`, remounting the (now correctly populated) volume where Bambuddy does
 * not look, and the node would come up as if its history were gone.
 *
 * Text-level edits on purpose — the file carries comments the owner reads, and
 * round-tripping it through a YAML dumper would strip them.
 *
 * @returns {{changed: boolean, text: string}}
 */
export function rewrite_compose(text, { image }) {
  if (typeof text !== 'string' || !text.includes('maziggy/bambuddy')) {
    return { changed: false, text: typeof text === 'string' ? text : '' }
  }
  let out = text
  out = out.replace(/(\n\s*image:\s*)maziggy\/bambuddy:[^\s#]+/, `$1${image}`)
  out = out.replace(/(\n\s*-\s*)bambuddy_data:\/data(\s)/, `$1bambuddy_data:${CORRECT_DATA_MOUNT}$2`)
  out = out.replace(/http:\/\/localhost:8000\/api\/v1\/health/g, 'http://localhost:8000/health')
  return { changed: out !== text, text: out }
}

/* ── orchestration ──────────────────────────────────────────────────────── */

const sleep = ms => new Promise(r => setTimeout(r, ms))

/**
 * Migrate this node's Bambuddy data onto its volume and upgrade the image.
 *
 * Never throws: it returns {ok, steps, error}. The caller reports this to the
 * owner, and a half-finished migration must produce a readable trail rather
 * than an exception in a WebSocket handler.
 */
export async function migrate_bambuddy({
  io = null,
  base_url = process.env.BAMBUDDY_BASE_URL ?? null,
  container_name = 'bambuddy',
  target_image = DEFAULT_TARGET_IMAGE,
  compose_path = null,
  fs_impl = null,
  is_busy = () => false,
  fetch_impl = null,
  wait_for_health_ms = 90_000,
} = {}) {
  const docker = io ?? create_docker_io()
  const steps = []
  const step = (name, ok, detail) => { steps.push({ step: name, ok, detail }); log.info({ step: name, ok, detail }, 'Bambuddy migration') }
  const fail = (name, detail) => { steps.push({ step: name, ok: false, detail }); log.warn({ step: name, detail }, 'Bambuddy migration failed'); return { ok: false, steps, error: detail } }

  let renamed_to = null
  let stopped = false

  try {
    // ── preflight ───────────────────────────────────────────────────────────
    if (is_busy()) return fail('preflight', 'A print is running on this node. Try again when it finishes.')

    const status = await detect_bambuddy({
      docker_request: docker.request, base_url, container_name,
      ...(fetch_impl ? { fetch_impl } : {}),
    })
    if (!status.container_present) return fail('preflight', `No "${container_name}" container on this node.`)
    if (!status.url_is_local) {
      return fail('preflight', 'This node talks to a Bambuddy on another machine, so it cannot upgrade it from here.')
    }
    if (!status.data_volume) {
      return fail('preflight', `Bambuddy's data is not on a named volume (mount: ${status.data_mount ?? 'none'}). Migrate it by hand — see docs/upgrading-bambuddy.md.`)
    }
    const volume = status.data_volume
    const needs_data_move = status.legacy_data_mount
    step('preflight', true, `Bambuddy ${status.version ?? 'unknown'} on ${status.data_mount}; volume ${volume}; data move ${needs_data_move ? 'required' : 'not needed'}`)

    // ── pull ────────────────────────────────────────────────────────────────
    const [pull_repo, pull_tag = 'latest'] = split_image(target_image)
    await docker.request('POST', `/images/create?fromImage=${encodeURIComponent(pull_repo)}&tag=${encodeURIComponent(pull_tag)}`)
    step('pull', true, `Pulled ${target_image}`)

    const old = (await docker.request('GET', `/containers/${encodeURIComponent(container_name)}/json`)).body

    // ── stop ────────────────────────────────────────────────────────────────
    // Copying a live SQLite database can capture a torn write. The -wal/-shm
    // files travel with it, so it recovers cleanly either way.
    await docker.request('POST', `/containers/${encodeURIComponent(container_name)}/stop?t=30`).catch(() => {})
    stopped = true
    step('stop', true, 'Bambuddy stopped')

    // ── export + seed + verify ──────────────────────────────────────────────
    if (needs_data_move) {
      const tar = await docker.archive_get(container_name, CORRECT_DATA_MOUNT)
      const source_entries = strip_leading_dir(list_tar_entries(tar))
      if (source_entries.length === 0) {
        return await abort(fail('export', 'Bambuddy\'s data directory read back empty — refusing to continue.'))
      }
      step('export', true, `Read ${source_entries.length} entries (${tar.length} bytes) out of the container`)

      // The helper runs the copy as its own command: with EXEC=0 there is no
      // shell into a container, and an archive PUT onto a not-yet-started
      // container writes to its filesystem rather than the volume. The target
      // image is reused as the helper so nothing extra has to be pulled.
      const helper = `neuslice-bb-migrate-${Date.now()}`
      await docker.request('POST', `/containers/create?name=${helper}`, {
        Image: target_image,
        Entrypoint: ['/bin/sh', '-c'],
        Cmd: [`cp -a ${STAGE_DIR}/data/. /dest/`],
        HostConfig: { Binds: [`${volume}:/dest`], AutoRemove: false },
      })
      try {
        await docker.archive_put(helper, STAGE_DIR, tar)
        await docker.request('POST', `/containers/${helper}/start`)
        await docker.request('POST', `/containers/${helper}/wait`)
        const helper_state = (await docker.request('GET', `/containers/${helper}/json`)).body
        const code = helper_state?.State?.ExitCode
        if (code !== 0) {
          const logs = await docker.request('GET', `/containers/${helper}/logs?stdout=1&stderr=1`).catch(() => null)
          return await abort(fail('seed', `Copy onto the volume exited ${code}. ${String(logs?.body ?? '').slice(0, 200)}`))
        }

        // Prove it, rather than trusting the exit code.
        const seeded = strip_leading_dir(list_tar_entries(await docker.archive_get(helper, '/dest')))
        const missing = source_entries.filter(n => !seeded.includes(n))
        if (missing.length) {
          return await abort(fail('verify', `${missing.length} of ${source_entries.length} entries did not reach the volume (e.g. ${missing.slice(0, 3).join(', ')}).`))
        }
        step('verify', true, `All ${source_entries.length} entries present on volume ${volume}`)
      } finally {
        await docker.request('DELETE', `/containers/${helper}?force=1`).catch(() => {})
      }
    }

    // ── swap ────────────────────────────────────────────────────────────────
    // Rename rather than delete: until this point the old container held the
    // only copy of the data, and it stays on disk afterwards as a rollback.
    renamed_to = `${container_name}-premigration-${stamp()}`
    await docker.request('POST', `/containers/${encodeURIComponent(container_name)}/rename?name=${renamed_to}`)
    step('rename', true, `Old container kept as ${renamed_to}`)

    const spec = build_new_container_config(old, { image: target_image, volume })
    await docker.request('POST', `/containers/create?name=${encodeURIComponent(container_name)}`, spec)
    await docker.request('POST', `/containers/${encodeURIComponent(container_name)}/start`)
    step('start', true, `Started ${target_image}`)

    // ── compose ─────────────────────────────────────────────────────────────
    if (compose_path && fs_impl) {
      try {
        const text = await fs_impl.readFile(compose_path, 'utf8')
        const { changed, text: next } = rewrite_compose(text, { image: target_image })
        if (changed) {
          await fs_impl.writeFile(compose_path, next, 'utf8')
          step('compose', true, 'docker-compose.yml updated so the next `up -d` keeps this layout')
        } else {
          step('compose', true, 'docker-compose.yml already matched')
        }
      } catch (err) {
        // Not fatal: Bambuddy is already running correctly. But say so loudly —
        // an un-rewritten compose silently reverts this on the next `up -d`.
        step('compose', false, `Could not update docker-compose.yml (${err.message}). Update the bambuddy service by hand or the next "docker compose up -d" will undo this.`)
      }
    }

    // ── health ──────────────────────────────────────────────────────────────
    const health = await wait_for_health(base_url, wait_for_health_ms, fetch_impl)
    if (!health.ok) {
      step('health', false, `Bambuddy did not answer within ${Math.round(wait_for_health_ms / 1000)}s. Your data is intact on volume ${volume} and the previous container is kept as ${renamed_to}.`)
      return { ok: false, steps, error: 'Upgraded, but Bambuddy did not come back healthy.', rollback_container: renamed_to }
    }
    step('health', true, `Bambuddy ${health.version ?? '(version unknown)'} is up`)

    // The kept container is only a rollback for data that lived in its writable
    // layer. When no data move was needed it holds nothing unique, so removing
    // it stops a stopped container piling up on every routine upgrade. Only
    // after health passed — before that it is still the way back.
    if (!needs_data_move && renamed_to) {
      await docker.request('DELETE', `/containers/${renamed_to}?force=1`).catch(() => {})
      renamed_to = null
    }

    return { ok: true, steps, version: health.version, rollback_container: renamed_to }
  } catch (err) {
    const detail = err?.message ?? String(err)
    return await abort({ ok: false, steps: [...steps, { step: 'error', ok: false, detail }], error: detail })
  }

  // Put the node back the way it was found: un-rename if we got that far, and
  // restart the original container so the owner's printer keeps working.
  async function abort(result) {
    try {
      if (renamed_to) {
        await docker.request('POST', `/containers/${renamed_to}/rename?name=${encodeURIComponent(container_name)}`).catch(() => {})
      }
      if (stopped) {
        await docker.request('POST', `/containers/${encodeURIComponent(container_name)}/start`).catch(() => {})
        result.steps.push({ step: 'rollback', ok: true, detail: 'Original Bambuddy restarted — nothing was lost.' })
      }
    } catch { /* best effort: the failure already reported is the useful one */ }
    return result
  }
}

function split_image(ref) {
  const at = ref.lastIndexOf(':')
  const slash = ref.lastIndexOf('/')
  return at > slash ? [ref.slice(0, at), ref.slice(at + 1)] : [ref, 'latest']
}

function stamp() {
  return new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-')
}

async function wait_for_health(base_url, budget_ms, fetch_impl) {
  if (!base_url) return { ok: true, version: null }
  const f = fetch_impl ?? (await import('node-fetch')).default
  const root = base_url.replace(/\/+$/, '')
  const deadline = Date.now() + budget_ms
  while (Date.now() < deadline) {
    try {
      const res = await f(`${root}/api/v1/system/info`, { timeout: 5000 })
      if (res.ok) {
        const body = await res.json()
        return { ok: true, version: body?.app?.version ?? null }
      }
    } catch { /* still starting */ }
    await sleep(3000)
  }
  return { ok: false, version: null }
}
