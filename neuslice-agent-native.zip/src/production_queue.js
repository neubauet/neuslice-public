import fs from 'node:fs/promises'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { api_base } from './api_base.js'

const digest=bytes=>createHash('sha256').update(bytes).digest('hex')
const MAX_BYTES=200*1024*1024
// Durable write-ahead journal: once "starting" is recorded, no reconnect,
// duplicate command, or process restart may call the adapter for that attempt.
export class ProductionQueueClient {
  constructor({node_id,token,api_url,adapter,handle,directory,is_available,on_error=()=>{},fetch_impl=fetch,clock=Date.now}) {
    Object.assign(this,{node_id,token,adapter,handle,is_available,on_error,fetch_impl,clock})
    this.root=api_base(api_url)+'/production-agent'
    this.directory=path.join(directory,'production',digest(node_id).slice(0,40))
    this.journalPath=path.join(this.directory,'journal.json')
    this.loaded=false;this.running=false;this.stopped=false;this.reserved=false;this.journal=null;this.initializing=true
  }
  is_busy(){return this.initializing || this.reserved || Boolean(this.journal && !['done','not_started'].includes(this.journal.phase))}
  start(){void this.tick();this.timer=setInterval(()=>{void this.tick()},15000);this.timer.unref?.()}
  stop(){this.stopped=true;clearInterval(this.timer)}
  async save(value) {
    await fs.mkdir(this.directory,{recursive:true,mode:0o700})
    const temporary=this.journalPath+'.tmp',file=await fs.open(temporary,'w',0o600)
    try{await file.writeFile(JSON.stringify(value));await file.sync()}finally{await file.close()}
    await fs.rename(temporary,this.journalPath)
    // Windows does not expose directory fsync. On Linux the agent's persistent
    // volume needs the rename itself flushed before the physical side effect.
    if(process.platform!=='win32'){const dir=await fs.open(this.directory,'r');try{await dir.sync()}finally{await dir.close()}}
    this.journal=value
  }
  async request(suffix,data) {
    const response=await this.fetch_impl(this.root+suffix,{headers:{Authorization:'Bearer '+this.token,'Content-Type':'application/json'},
      ...(data?{method:'POST',body:JSON.stringify(data)}:{}),signal:AbortSignal.timeout(30000)})
    if(!response.ok)throw new Error('Production queue request failed ('+response.status+')')
    return response.json()
  }
  async event(state) {
    const j=this.journal
    await this.request('/'+j.queue_id+'/events',{run_id:j.run_id,epoch:j.epoch,claim_id:j.claim_id,state,external_id:j.external_id??null})
  }
  async download(queue,run) {
    const response=await this.fetch_impl(this.root+'/'+queue.id+'/artifacts/'+run.id,{headers:{Authorization:'Bearer '+this.token},signal:AbortSignal.timeout(120000)})
    if(!response.ok || !response.body)throw new Error('Production artifact download failed')
    const chunks=[];let size=0
    for await(const chunk of response.body){size+=chunk.length;if(size>MAX_BYTES)throw new Error('Production artifact is too large');chunks.push(chunk)}
    const bytes=Buffer.concat(chunks)
    if(!size || digest(bytes)!==run.artifact_sha256)throw new Error('Production artifact checksum mismatch')
    // Artifact format is supplied from the validated server record; extensions
    // are fixed locally and no server-provided path is opened on this computer.
    const archive=bytes[0]===0x50 && bytes[1]===0x4b
    const filename=path.join(this.directory,'plate'+(archive?'.gcode.3mf':'.gcode'))
    await fs.mkdir(this.directory,{recursive:true,mode:0o700});await fs.writeFile(filename,bytes,{mode:0o600})
    return filename
  }
  async tick() {
    if(this.running || this.stopped)return
    this.running=true
    try {
      if(!this.loaded){
        try{
          this.journal=JSON.parse(await fs.readFile(this.journalPath,'utf8'))
          const j=this.journal
          if(j.node_id!==this.node_id || !Number.isSafeInteger(j.epoch) || !/^[A-Za-z0-9_-]{1,100}$/.test(j.queue_id) ||
            !/^[A-Za-z0-9_-]{1,100}$/.test(j.run_id) || !['prepared','starting','accepted','unknown','not_started','done'].includes(j.phase))throw new Error('Production journal is invalid; reconcile before restarting')
        }catch(error){if(error.code!=='ENOENT')throw error}
        this.loaded=true
      }
      const state=await this.request('/current')
      this.initializing=false
      if(!state.enabled)return
      if(this.journal && state.released && this.journal.queue_id===state.released.id && this.journal.epoch<=state.released.epoch && this.journal.phase!=='done')await this.save({...this.journal,phase:'done'})
      const queue=state.queue,run=queue?.run
      this.reserved=Boolean(queue)
      if(this.journal && queue && this.journal.queue_id===queue.id && this.journal.epoch<=queue.settled_epoch && this.journal.phase!=='done') {
        await this.save({...this.journal,phase:'done'})
        for(const name of ['plate.gcode','plate.gcode.3mf'])try{await fs.unlink(path.join(this.directory,name))}catch(error){if(error.code!=='ENOENT')throw error}
      }
      if(!run)return
      if(!/^[A-Za-z0-9_-]{1,100}$/.test(queue.id) || !/^[A-Za-z0-9_-]{1,100}$/.test(run.id) || !Number.isSafeInteger(run.epoch))throw new Error('Invalid production command')
      const same=this.journal?.queue_id===queue.id && this.journal.run_id===run.id && this.journal.epoch===run.epoch
      if(same){
        if(['awaiting_output_check','completed'].includes(run.state)){
          await this.save({...this.journal,phase:'done'})
          for(const name of ['plate.gcode','plate.gcode.3mf'])try{await fs.unlink(path.join(this.directory,name))}catch(error){if(error.code!=='ENOENT')throw error}
          return
        }
        if(run.claim_id!==this.journal.claim_id){
          // A prepared journal has not entered the adapter. A different winner
          // owns this attempt; this process must never take over its start.
          return
        }
        if(this.journal.phase==='prepared' || this.journal.phase==='not_started'){
          await this.event('not_started');await this.save({...this.journal,phase:'not_started'});return
        }
        if(this.journal.phase==='done')return
        if(this.journal.phase==='starting' || this.journal.phase==='unknown'){
          await this.event('unknown');await this.save({...this.journal,phase:'unknown'});return
        }
        const status=await this.adapter.getStatus(this.handle)
        // Printer idleness does not prove output or identify a completed job.
        // The provider records completion after checking the physical printer.
        await this.event(status.state==='printing'?'printing':status.state==='idle'?'accepted':'unknown')
        return
      }
      if(this.journal && !['done','not_started','prepared'].includes(this.journal.phase))throw new Error('An earlier production attempt needs reconciliation')
      if(this.journal?.queue_id===queue.id && this.journal.epoch>=run.epoch)return
      if(queue.paused || run.state!=='dispatching' || run.claim_id || !this.is_available() || this.stopped)return
      const filename=await this.download(queue,run)
      const status=await this.adapter.getStatus(this.handle)
      if(status.state!=='idle' || !this.is_available() || this.stopped)return
      const journal={node_id:this.node_id,queue_id:queue.id,run_id:run.id,epoch:run.epoch,claim_id:randomUUID(),phase:'prepared',external_id:null}
      await this.save(journal)
      const permit=await this.request('/'+queue.id+'/claim',{run_id:run.id,epoch:run.epoch,claim_id:journal.claim_id})
      if(!Number.isFinite(permit.permit_until) || this.clock()>=permit.permit_until || !this.is_available() || this.stopped){await this.event('not_started');await this.save({...journal,phase:'not_started'});return}
      await this.save({...journal,phase:'starting'})
      if(this.stopped || this.clock()>=permit.permit_until){await this.event('not_started');await this.save({...journal,phase:'not_started'});return}
      try {
        await this.adapter.printFile(this.handle,filename)
        await this.save({...journal,phase:'accepted',external_id:this.handle?._lastQueueId!=null?String(this.handle._lastQueueId):null})
        await this.event('accepted')
      }catch(error){
        await this.save({...this.journal,phase:'unknown'});throw error
      }
    }catch(error){this.on_error(error)}
    finally{this.running=false}
  }
}
