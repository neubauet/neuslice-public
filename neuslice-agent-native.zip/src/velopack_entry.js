// Only the packaging launcher calls this. Installation/update hooks must not boot
// adapters, connect to the backend, or apply staged updates outside the idle gate.
import { VelopackApp } from 'velopack'
VelopackApp.build().setArgs(process.argv.slice(2)).setAutoApplyOnStartup(false).run()
