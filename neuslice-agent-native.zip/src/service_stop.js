/*
 * service_stop.js — the WinSW <stopexecutable> helper (spec §3.5 / Procedure B2).
 *
 * WinSW runs this on `Stop-Service` instead of hard-killing the agent. It writes the
 * stop sentinel the running agent watches (stop_sentinel.js); the agent then drains
 * every Agent (shutdown_all) and exits on its own, and WinSW waits for that exit
 * within <stoptimeout>. This process just writes the sentinel and returns.
 *
 * It must resolve the SAME config dir as the running service — both inherit
 * NEUSLICE_CONFIG_DIR (pinned in neuslice-agent.xml) and share the working dir, so
 * request_stop()'s default matches the agent's.
 */

import { request_stop } from './stop_sentinel.js'

try {
  const file = request_stop()
  console.log(`[service-stop] wrote stop sentinel: ${file}`)
  process.exit(0)
} catch (err) {
  console.error(`[service-stop] failed to write stop sentinel: ${err.message}`)
  // Non-zero so WinSW logs the failed graceful stop; it will still fall back to its
  // own stop timeout + terminate.
  process.exit(1)
}
