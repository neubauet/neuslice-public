/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { api_base } from './api_base.js'

/**
 * The REST base.
 * Run: node --test src/api_base.test.js
 *
 * NEUSLICE_API_URL is the backend ORIGIN — the WebSocket lives at <origin>/ws,
 * so it cannot carry the /api/v1 prefix that every REST route needs. Installers
 * write the bare origin, so `${api_url}/nodes/x` 404s.
 *
 * Four call sites did that, and every one of them reads a failed fetch as "no
 * data" rather than an error, so all four failed silently in production. These
 * tests pin the join so the next call site cannot get it wrong quietly.
 */

const ORIGIN = 'https://printshare-backend-234aeo2mva-uc.a.run.app'

test('API-1: a bare origin gains the /api/v1 prefix', () => {
  assert.equal(api_base(ORIGIN), `${ORIGIN}/api/v1`)
})

test('API-2: it is idempotent — a value already ending in /api/v1 is unchanged', () => {
  // Some installs may have been hand-corrected. Double-prefixing would be a
  // fresh 404, which is exactly the failure we are removing.
  assert.equal(api_base(`${ORIGIN}/api/v1`), `${ORIGIN}/api/v1`)
  assert.equal(api_base(api_base(ORIGIN)), `${ORIGIN}/api/v1`)
})

test('API-3: trailing slashes do not produce a double slash', () => {
  for (const input of [`${ORIGIN}/`, `${ORIGIN}//`, `${ORIGIN}/api/v1/`]) {
    assert.equal(api_base(input), `${ORIGIN}/api/v1`, input)
  }
})

test('API-4: whitespace from a hand-edited .env is tolerated', () => {
  assert.equal(api_base(`  ${ORIGIN}  `), `${ORIGIN}/api/v1`)
})

test('API-5: a localhost origin with a port survives intact', () => {
  assert.equal(api_base('http://localhost:8080'), 'http://localhost:8080/api/v1')
})

test('API-6: /api/v1 is only stripped at the end, not from a host that contains it', () => {
  // Guard against a greedy replace mangling a path-prefixed deployment.
  assert.equal(api_base('https://h/api/v1/extra'), 'https://h/api/v1/extra/api/v1')
})

test('API-7: empty or missing input still yields a usable relative base', () => {
  // Never returns "undefined/nodes/..." — that would produce a request to a
  // literal "undefined" host and a confusing DNS error instead of a clear 404.
  assert.equal(api_base(undefined), '/api/v1')
  assert.equal(api_base(''), '/api/v1')
})

/*
 * API-8 is a structural guard, not a unit test.
 *
 * #146 fixed four REST call sites and missed a fifth — `node_opts.js`, the one
 * that carries cfs_inventory. The enumeration grepped for `fetch(\`${api_url}`
 * and that file calls `fetchImpl(`, the injectable added for testability. So the
 * search pattern could not see the very call site that mattered, and the miss
 * cost a full deploy cycle to discover on a customer's printer.
 *
 * Every one of these failures is silent by construction: each caller treats a
 * failed fetch as "no data". So the guard is a source scan — the next call site
 * built the same way fails here rather than in production.
 */
import { readFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

test('API-8: no agent source builds a REST path straight off api_url', () => {
  const src = dirname(fileURLToPath(import.meta.url))
  const offenders = []

  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const p = join(dir, entry.name)
      if (entry.isDirectory()) { if (entry.name !== 'node_modules') walk(p); continue }
      if (!entry.name.endsWith('.js') || entry.name.endsWith('.test.js')) continue
      readFileSync(p, 'utf8').split('\n').forEach((line, i) => {
        const t = line.trim()
        if (t.startsWith('*') || t.startsWith('//') || t.startsWith('/*')) return  // prose, not code
        // Any interpolation of an api_url-ish value immediately followed by a
        // REST path, without api_base() wrapping it. Matches whatever the call
        // is named — fetch, fetchImpl, or the next one someone invents.
        if (/\$\{\s*(this\.)?(NEUSLICE_)?api_url\s*\}\/(?!ws)/i.test(line)) {
          offenders.push(`${entry.name}:${i + 1}  ${line.trim().slice(0, 90)}`)
        }
      })
    }
  }
  walk(src)

  assert.deepEqual(offenders, [],
    'REST paths must be built with api_base(api_url) — the WebSocket is the only thing that lives at the bare origin')
})
