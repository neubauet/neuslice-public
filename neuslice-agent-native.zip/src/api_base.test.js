/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { api_base } from './api_base.js'

/**
 * The REST base.
 * Run: node --test src/api_base.test.js
 *
 * NEUSLICE_API_URL is the backend ORIGIN — the WebSocket lives at <origin>/ws,
 * so it cannot carry the /api/v1 prefix that every REST route needs. Installers
 * write the bare origin, so `${api_url}/nodes/x` 404s.
 *
 * Four call sites did that, and every one of them reads a failed fetch as "no
 * data" rather than an error, so all four failed silently in production. These
 * tests pin the join so the next call site cannot get it wrong quietly.
 */

const ORIGIN = 'https://printshare-backend-234aeo2mva-uc.a.run.app'

test('API-1: a bare origin gains the /api/v1 prefix', () => {
  assert.equal(api_base(ORIGIN), `${ORIGIN}/api/v1`)
})

test('API-2: it is idempotent — a value already ending in /api/v1 is unchanged', () => {
  // Some installs may have been hand-corrected. Double-prefixing would be a
  // fresh 404, which is exactly the failure we are removing.
  assert.equal(api_base(`${ORIGIN}/api/v1`), `${ORIGIN}/api/v1`)
  assert.equal(api_base(api_base(ORIGIN)), `${ORIGIN}/api/v1`)
})

test('API-3: trailing slashes do not produce a double slash', () => {
  for (const input of [`${ORIGIN}/`, `${ORIGIN}//`, `${ORIGIN}/api/v1/`]) {
    assert.equal(api_base(input), `${ORIGIN}/api/v1`, input)
  }
})

test('API-4: whitespace from a hand-edited .env is tolerated', () => {
  assert.equal(api_base(`  ${ORIGIN}  `), `${ORIGIN}/api/v1`)
})

test('API-5: a localhost origin with a port survives intact', () => {
  assert.equal(api_base('http://localhost:8080'), 'http://localhost:8080/api/v1')
})

test('API-6: /api/v1 is only stripped at the end, not from a host that contains it', () => {
  // Guard against a greedy replace mangling a path-prefixed deployment.
  assert.equal(api_base('https://h/api/v1/extra'), 'https://h/api/v1/extra/api/v1')
})

test('API-7: empty or missing input still yields a usable relative base', () => {
  // Never returns "undefined/nodes/..." — that would produce a request to a
  // literal "undefined" host and a confusing DNS error instead of a clear 404.
  assert.equal(api_base(undefined), '/api/v1')
  assert.equal(api_base(''), '/api/v1')
})
