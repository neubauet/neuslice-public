/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * docker_socket.js — how to reach the Docker API, and nothing else.
 *
 * Its own module because both the sibling-container spawner and the Bambuddy
 * migration need it, and importing spawn.js for it drags in the API-base config
 * that throws at load time when NEUSLICE_API_URL is unset. A transport detail
 * should not decide whether an unrelated module can be imported or tested.
 *
 * DOCKER_SOCKET is normally tcp://docker-socket-proxy:2375 — the raw
 * /var/run/docker.sock is never mounted into the agent container. The unix://
 * form exists for local development without the proxy.
 */
import fs from 'fs'

export function parse_docker_socket(socket_str) {
  if (socket_str.startsWith('tcp://')) {
    const url = new URL(socket_str)
    return { hostname: url.hostname, port: parseInt(url.port || '2375', 10) }
  }
  // Unix socket path — strip any unix:// prefix
  const socket_path = socket_str.replace(/^unix:\/\//, '')
  if (!fs.existsSync(socket_path)) {
    throw new Error(
      `DOCKER_SOCKET_MISSING: ${socket_path} not found. ` +
      `Set DOCKER_SOCKET=tcp://docker-socket-proxy:2375 to use the socket proxy.`
    )
  }
  return { socketPath: socket_path }
}
