/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import WebSocket from 'ws'
import { download_gcode } from './download.js'
import { CameraManager } from './camera.js'
import { handle_spawn_agent } from './spawn.js'
import { create_metrics, register_metrics, unregister_metrics } from './health.js'
import { apply_config_relay, default_config_dir } from './config_store.js'
import { request_watchtower_update } from './self_update.js'
import { fetch_node_opts } from './node_opts.js'
import { api_base } from './api_base.js'
import log from './logger.js'

const HEARTBEAT_INTERVAL_MS   = 30_000
const STATUS_POLL_INTERVAL_MS  = 15_000
const INVENTORY_POLL_INTERVAL_MS = 5 * 60 * 1000  // 5 minutes
const RECONNECT_DELAYS = [1000, 2000, 4000, 8000, 16000, 30000]

export class Agent {
  constructor({ token, node_id, api_url, adapter, handle, on_update_available = null }) {
    this.token   = token
    this.node_id = node_id
    this.api_url = api_url
    this.ws_url  = api_url.replace(/^https/, 'wss').replace(/^http(?!s)/, 'ws') + `/ws?node_id=${node_id}`
    this.adapter = adapter
    this.handle  = handle
    this.ws      = null
    // Supervisor-owned update gate (spec §3.2 / SMA-N2). When set, this Agent does
    // NOT decide the process's fate on its own active_job — an UPDATE_AVAILABLE is
    // delegated up so the process only restarts when EVERY sibling Agent is idle.
    // null (single-agent default) keeps the original self-contained behavior.
    this.on_update_available = on_update_available
    // This Agent's OWN metrics (spec §3.2) — not the process global, so N Agents
    // in one supervisor process don't clobber each other's numbers. Registered
    // by node_id for the health server; unregistered on shutdown.
    this.metrics = create_metrics()
    this.metrics.live.adapter = adapter.name ?? 'unknown'
    register_metrics(node_id, this.metrics)
    this.active_job       = null   // { job_id, gcode_path, poll_timer, has_been_printing, camera }
    this.pending_job      = null   // { job_id, gcode_path } — downloaded, awaiting owner decision
    this.owner_accepted_pending = null  // job_id whose OWNER_ACCEPTED arrived before download finished
    this.heartbeat_timer  = null
    this.inventory_timer  = null
    this.reconnect_attempt = 0
  }

  start() {
    this._connect()
    // Kick off inventory sync immediately, then every 5 minutes
    this._sync_inventory()
    this.inventory_timer = setInterval(() => this._sync_inventory(), INVENTORY_POLL_INTERVAL_MS)
  }

  _connect() {
    log.info({ url: this.ws_url }, 'Connecting to NeuSlice backend...')
    const ws = new WebSocket(this.ws_url, {
      headers: { Authorization: `Bearer ${this.token}` }
    })
    this.ws = ws

    ws.on('open', () => {
      log.info('Connected')
      this.reconnect_attempt = 0
      this._report_binding()
      this._report_roster()
      this._start_heartbeat()
      this._resume_active_job_if_needed()
    })

    ws.on('message', (raw) => this._on_message(raw))

    ws.on('close', (code) => {
      log.warn({ code }, 'Disconnected — will reconnect')
      this._stop_heartbeat()
      this._schedule_reconnect()
    })

    ws.on('error', (err) => {
      log.warn({ err: err.message }, 'WebSocket error')
    })
  }

  _schedule_reconnect() {
    const delay = RECONNECT_DELAYS[Math.min(this.reconnect_attempt, RECONNECT_DELAYS.length - 1)]
    this.reconnect_attempt++
    this.metrics.counters.reconnect_count++
    log.info({ delay_ms: delay, attempt: this.reconnect_attempt }, 'Reconnecting...')
    setTimeout(() => this._connect(), delay)
  }

  _start_heartbeat() {
    this._send_heartbeat()
    this.heartbeat_timer = setInterval(() => this._send_heartbeat(), HEARTBEAT_INTERVAL_MS)
  }

  _stop_heartbeat() { clearInterval(this.heartbeat_timer) }

  /**
   * Is this Agent mid-print? Read by the supervisor's update gate (SMA-N2) so an
   * UPDATE_AVAILABLE never restarts the process while any sibling is printing.
   */
  is_busy() { return Boolean(this.active_job) }

  /*
   * Report which physical printer this node is driving (spec §3.1).
   *
   * Sent once per (re)connect, before the first heartbeat, so the backend can
   * persist the binding and stop this node ever resolving positionally again.
   *
   * Two things this deliberately does NOT do:
   *  - it sends no node_id. The backend writes to the SOCKET-AUTHENTICATED node,
   *    never a payload-supplied one (IDOR guard, SMA-2). Sending one would only
   *    invite a handler that trusts it.
   *  - it does not decide whether the serial is backfill-eligible. It reports
   *    roster_count/ambiguous and lets the backend apply the §6 rule. The agent
   *    is the only party that can SEE the roster, so it must supply the signal —
   *    but it is not the party that gets to act on it.
   */
  _report_binding() {
    const binding = this.handle?.binding
    if (!binding) return   // non-Bambu adapter, or a handle predating binding support

    const { serial, printerId, matchedBy, ambiguous, rosterCount } = binding
    if (!serial && printerId == null) return

    this._send('NODE_PRINTER_BINDING', {
      adapter:           this.adapter?.name ?? null,
      bambu_serial:      serial ?? null,
      bambu_printer_id:  printerId != null ? String(printerId) : null,
      matched_by:        matchedBy ?? null,
      roster_count:      rosterCount ?? 0,
      ambiguous:         ambiguous ?? false,
    })
    // Log the shape, never the serial itself — it is a stable device identifier
    // and §7 names it a log sink.
    log.info({ matched_by: matchedBy, roster_count: rosterCount, has_serial: Boolean(serial) },
      'Reported printer binding')
  }

  /*
   * Report the full Bambuddy roster this agent can see (spec §3.3, P2).
   *
   * Sent on each (re)connect alongside the binding. The agent is the only party
   * that can enumerate the Bambuddy, so it pushes the list; the backend holds it
   * transiently and diffs it against the owner's nodes for the detected-printers
   * UI. The agent neither stores nor acts on it — and always sends, regardless of
   * the backend's DETECT_PRINTERS_ENABLED flag, so the dry-run diff has data.
   *
   * Bambu-only: a Klipper handle has no roster (no enumerator), so this no-ops.
   * The serials/names were already fetched to talk to Bambuddy; forwarding them
   * over the authenticated socket adds no exposure. Logs the size, never contents.
   */
  _report_roster() {
    const roster = this.handle?.roster
    if (!Array.isArray(roster) || roster.length === 0) return

    this._send('NODE_PRINTER_ROSTER', { printers: roster })
    log.info({ roster_size: roster.length }, 'Reported printer roster')
  }

  // Called on every (re)connect. If we have no local record of an active or
  // pending job — most notably right after this process was restarted mid-print
  // (e.g. Watchtower's own poll cycle SIGTERM'd the previous container) — ask the
  // backend what it thinks is currently assigned to this node. The physical print
  // keeps running on the printer independent of this container, so if the printer
  // confirms it's still working that job, resume polling instead of orphaning it.
  async _resume_active_job_if_needed() {
    if (this.active_job || this.pending_job) return

    try {
      const res = await fetch(`${api_base(this.api_url)}/jobs/current`, {
        headers: { Authorization: `Bearer ${this.token}` },
        signal: AbortSignal.timeout(8000),
      })
      if (!res.ok) return
      const { job } = await res.json()
      if (!job) return

      const status = await this.adapter.getStatus(this.handle)
      if (status.state === 'printing') {
        log.info({ job_id: job.id }, 'Resuming poll for job still active on printer after restart')
        const poll_timer = setInterval(() => this._poll_job_status(job.id), STATUS_POLL_INTERVAL_MS)
        this.active_job = { job_id: job.id, gcode_path: null, poll_timer, has_been_printing: true, camera: null }
      } else if (status.state === 'idle') {
        log.info({ job_id: job.id }, 'Backend job was active but printer is idle — print finished while agent was down, reporting completed')
        this.metrics.counters.jobs_completed++
        this._send('JOB_STATUS_UPDATE', { job_id: job.id, status: 'completed', progress_pct: 100 })
      } else if (status.state === 'error') {
        log.warn({ job_id: job.id }, 'Backend job was active but printer reports error — reporting failed')
        this.metrics.counters.jobs_failed++
        this._send('JOB_STATUS_UPDATE', { job_id: job.id, status: 'failed', error: status.error_message ?? 'printer_error' })
      }
      // Any other state (e.g. still booting/homing): leave it — the next
      // heartbeat/poll cycle or reconnect will re-check.
    } catch (err) {
      log.warn({ err: err.message }, 'Resume-active-job check failed')
    }
  }

  // Graceful shutdown on SIGTERM/SIGINT. A Watchtower-triggered restart can't
  // realistically wait out a multi-hour print, so this does not attempt to
  // "finish" anything — it just stops timers and closes the socket promptly so
  // the process exits cleanly within Docker's stop grace period. Continuity is
  // handled on the other side: the next process resumes the job via
  // _resume_active_job_if_needed() once it reconnects. We deliberately do NOT
  // report the job failed/cancelled here — the print is very likely still
  // running on the printer.
  async shutdown(signal) {
    log.info({ signal, active_job: this.active_job?.job_id ?? null }, 'Shutdown signal received — closing cleanly')
    this._stop_heartbeat()
    clearInterval(this.inventory_timer)
    if (this.active_job?.poll_timer) clearInterval(this.active_job.poll_timer)
    if (this.active_job?.camera) {
      try { this.active_job.camera.stop() } catch {}
    }
    if (this.ws) {
      try { this.ws.close() } catch {}
    }
    // Drop this Agent's metrics from the health registry so a stopped node stops
    // appearing in /metrics (matters under the supervisor; harmless single-agent).
    unregister_metrics(this.node_id)
  }

  /**
   * Pull this node's settings and hand them to the adapter.
   *
   * Runs on the inventory cadence so a dashboard toggle takes effect within one
   * sync instead of at the next container restart. Before this, `cfs_inventory`
   * was read once at boot — the toggle looked like a switch and behaved like a
   * boot parameter, and the OFF direction (a printer misbehaving, no shell
   * access to it) needed the owner to restart their own machine.
   *
   * Failure is soft and deliberate: keep the settings we already have. A blip
   * reaching the API must never silently revert a node to defaults mid-print.
   */
  async _refresh_node_opts() {
    if (typeof this.adapter.applyNodeOpts !== 'function') return
    try {
      const opts = await fetch_node_opts(this.api_url, this.node_id, this.token)
      this.adapter.applyNodeOpts(this.handle, opts)
    } catch (err) {
      log.warn({ err: err.message }, 'Node opts refresh failed — keeping current settings')
    }
  }

  async _sync_inventory() {
    // Refresh first: settings decide what getStatus reports, so picking them up
    // after the poll would publish one sync's worth of stale inventory.
    await this._refresh_node_opts()
    try {
      const status = await this.adapter.getStatus(this.handle)
      const inv = status.filament_inventory ?? []
      // Update live metrics for health endpoint
      this.metrics.live.filament_inventory = inv
      this._send('NODE_INVENTORY_UPDATE', {
        filament_inventory: inv,
        updated_at: new Date().toISOString(),
      })
      log.info({ slots: inv.length }, 'Inventory synced')
    } catch (err) {
      log.warn({ err: err.message }, 'Inventory sync failed')
    }
  }

  async _send_heartbeat() {
    let printer_status = { state: 'idle', progress_pct: 0 }
    try {
      printer_status = await this.adapter.getStatus(this.handle)
    } catch {
      this.metrics.live.printer_state = 'offline'
    }
    // Update live metrics for health endpoint
    this.metrics.live.printer_state    = printer_status.state ?? 'unknown'
    this.metrics.live.active_job_id    = this.active_job?.job_id ?? null
    // Expose filament inventory from last inventory sync
    // (already set in _sync_inventory — no need to re-fetch here)
    this.metrics.counters.last_heartbeat_at = new Date().toISOString()

    this._send('HEARTBEAT', {
      available:     !this.active_job && !this.pending_job && printer_status.state === 'idle',
      filaments:     [],
      active_job_id: this.active_job?.job_id ?? null,
      // Include health metrics in heartbeat so backend can track them
      health: {
        printer_state:    this.metrics.live.printer_state,
        jobs_completed:   this.metrics.counters.jobs_completed,
        jobs_failed:      this.metrics.counters.jobs_failed,
        jobs_declined:    this.metrics.counters.jobs_declined,
        reconnect_count:  this.metrics.counters.reconnect_count,
        uptime_s:         Math.floor((Date.now() - (globalThis._agent_start ?? Date.now())) / 1000),
      },
    })
  }

  async _on_message(raw) {
    let msg
    try { msg = JSON.parse(raw.toString()) } catch { return }
    const { type, payload } = msg
    log.debug({ type }, 'Message from server')

    switch (type) {
      case 'JOB_ASSIGNED':     await this._handle_job_assigned(payload);  break
      case 'JOB_CANCELLED':    await this._handle_job_cancelled(payload); break
      case 'OWNER_ACCEPTED':   await this._handle_owner_accepted(payload); break
      case 'OWNER_DECLINED':   await this._handle_owner_declined(payload); break
      case 'UPDATE_AVAILABLE': await this._handle_update_available(payload); break
      case 'RESTART_REQUESTED': await this._handle_restart_requested(payload); break
      case 'PING':             this._send('PONG', {});                    break

      case 'SPAWN_AGENT':
        // Backend is asking this agent to spawn a sibling container for a
        // newly-registered printer. Handled async — result sent via SPAWN_RESULT.
        handle_spawn_agent(payload, (type, p) => this._send(type, p))
        break

      case 'CONFIG_RELAY':
        // A relayed node config (3c agent-pull, SMA-7c). We write our OWN store,
        // then ACK so the backend hard-deletes the record.
        this._handle_config_relay(payload)
        break

      default: log.warn({ type }, 'Unknown message type')
    }
  }

  /*
   * Apply a relayed node config to our local store (3c agent-pull, SMA-7c).
   *
   * Delivery is owner-scoped (this relay rode our socket because we share the
   * owner), so the write decision lives in apply_config_relay:
   *  - a BOOTSTRAP relay (brand-new node) is adopted — owner-scoped first delivery;
   *  - a relay for a node THIS host already serves is applied (e.g. a key rotation);
   *  - anything else is declined so another host's key never rests on our disk (d).
   * Every relayed VALUE is validated (control-char reject) before it touches disk —
   * value-validation lives only at the agent now.
   *
   * On a successful write we ACK, which makes the backend hard-delete the record so
   * the key stops resting (a). On a decline/invalid we deliberately do NOT ack — the
   * record can reach the right host or be purged by TTL. The relay contents (a
   * Moonraker key, a node token) are never logged.
   */
  _handle_config_relay(payload) {
    const { relay_id, node_id, adapter, config, token, bootstrap } = payload ?? {}
    const result = apply_config_relay(
      default_config_dir(),
      { node_id, adapter, config, token, bootstrap },
      new Set([this.node_id]),
    )
    if (result.written) {
      this._send('CONFIG_RELAY_ACK', { relay_id, node_id })
      log.info({ node_id, bootstrap: Boolean(bootstrap) },
        'Applied relayed node config — a supervisor restart will pick it up')
    } else {
      log.warn({ node_id, reason: result.reason }, 'Config relay not applied — not acking')
    }
  }

  async _handle_job_assigned(payload) {
    const { job_id, gcode_url, filament_color, filament_slot, filament_slots } = payload
    log.info({ job_id, filament_color, filament_slot, filament_slots }, 'Job assigned')

    // If we already have an active job, always decline.
    if (this.active_job) {
      log.warn({ job_id }, 'Already have an active job — declining')
      this.metrics.counters.jobs_declined++
      this._send('JOB_DECLINED', { job_id, reason: 'printer_busy' })
      return
    }

    // If we already have a pending_job for THIS same job (download in progress or
    // complete), ignore the duplicate JOB_ASSIGNED from the broker sweep rather
    // than declining — declining would deadlock the FSM (accepted→matching is invalid).
    if (this.pending_job?.job_id === job_id) {
      log.info({ job_id }, 'Duplicate JOB_ASSIGNED for job already pending — ignoring')
      return
    }

    // If we have a pending_job for a DIFFERENT job, decline the new one.
    if (this.pending_job) {
      log.warn({ job_id, pending: this.pending_job.job_id }, 'Already have a pending job — declining new one')
      this.metrics.counters.jobs_declined++
      this._send('JOB_DECLINED', { job_id, reason: 'printer_busy' })
      return
    }

    // Set pending sentinel immediately to block duplicate JOB_ASSIGNED races
    this.pending_job = { job_id, gcode_path: null, filament_color: filament_color ?? null, filament_slot: filament_slot ?? null, filament_slots: filament_slots ?? null }

    try {
      log.info({ job_id }, 'Downloading gcode...')
      const gcode_path = await download_gcode(gcode_url, job_id)
      log.info({ job_id, gcode_path }, 'Gcode downloaded — waiting for owner decision')
      this.pending_job = { job_id, gcode_path, filament_color: filament_color ?? null, filament_slot: filament_slot ?? null, filament_slots: filament_slots ?? null }

      // If OWNER_ACCEPTED arrived during the download (gcode_path was null then),
      // it was deferred.  Process it now that we have the file.
      if (this.owner_accepted_pending === job_id) {
        log.info({ job_id }, 'Processing deferred OWNER_ACCEPTED (arrived during download)')
        this.owner_accepted_pending = null
        await this._handle_owner_accepted({ job_id })
      }
    } catch (err) {
      log.error({ err: err.message, job_id }, 'Failed to download gcode')
      this._send('JOB_DECLINED', { job_id, reason: 'download_failed' })
      this.pending_job = null
      // Clear any pending OWNER_ACCEPTED for this job since download failed
      if (this.owner_accepted_pending === job_id) this.owner_accepted_pending = null
    }
  }

  async _handle_owner_accepted(payload) {
    const { job_id } = payload
    log.info({ job_id }, 'Owner accepted — starting print')

    // Idempotency guard: if this job is already active and printing, a second
    // OWNER_ACCEPTED (from the broker sweep or a reconnect re-dispatch) must not
    // attempt a second printFile() call. Bambuddy will 409 and the error handler
    // would cancel the job. Log and return — the print is already in progress.
    if (this.active_job?.job_id === job_id) {
      log.info({ job_id }, 'OWNER_ACCEPTED: job already active and printing — ignoring duplicate')
      return
    }

    // Promote pending job to active, or handle if already active (e.g. auto-accept from server)
    const pending = this.pending_job
    if (pending?.job_id === job_id) {
      // Race condition guard: OWNER_ACCEPTED can arrive from the server before the
      // download_gcode() promise resolves (gcode_path is still null at that point).
      // If we proceed with a null path, adapter.printFile() will throw and the job
      // transitions to 'failed'.  Instead, defer: stash the job_id and let
      // _handle_job_assigned() call us again once the download completes.
      if (pending.gcode_path === null) {
        log.info({ job_id }, 'OWNER_ACCEPTED arrived before download finished — deferring until gcode ready')
        this.owner_accepted_pending = job_id
        return
      }
      this.pending_job = null
      this.active_job = {
        job_id,
        gcode_path:     pending.gcode_path,
        filament_color: pending.filament_color ?? null,
        filament_slot:  pending.filament_slot  ?? null,
        filament_slots: pending.filament_slots ?? null,
        poll_timer:     null,
        has_been_printing: false,
        camera: null,
      }
    } else if (!this.active_job || this.active_job.job_id !== job_id) {
      log.warn({ job_id }, 'OWNER_ACCEPTED for unknown job — ignoring')
      return
    }

    const { gcode_path, filament_color, filament_slot, filament_slots } = this.active_job
    log.info({ job_id, filament_color, filament_slot, filament_slots }, 'Dispatching print to adapter')

    try {
      await this.adapter.printFile(this.handle, gcode_path, { filament_color, filament_slot, filament_slots })
      log.info({ job_id }, 'Print started')

      // Start camera snapshots — Bambu only (Klipper/OctoPrint use Bambuddy which won't be present)
      let camera = null
      if (this.adapter.name === 'bambu') {
        camera = new CameraManager({
          handle:      this.handle,
          job_id,
          api_url:     this.api_url,
          agent_token: this.token,
        })
        camera.start().catch(err =>
          log.warn({ err: err.message, job_id }, 'Camera failed to start')
        )
      }

      const poll_timer = setInterval(() => this._poll_job_status(job_id), STATUS_POLL_INTERVAL_MS)
      this.active_job = { job_id, gcode_path, poll_timer, has_been_printing: false, camera }
    } catch (err) {
      log.error({ err: err.message, job_id }, 'Failed to start job after owner accept')
      this.metrics.counters.jobs_failed++
      this._send('JOB_STATUS_UPDATE', { job_id, status: 'failed', error: err.message })
      this._cleanup_job()
    }
  }

  async _handle_owner_declined(payload) {
    const { job_id } = payload
    log.info({ job_id }, 'Owner declined — cleaning up downloaded file')
    if (this.pending_job?.job_id === job_id) {
      const { gcode_path } = this.pending_job
      this.pending_job = null
      if (this.owner_accepted_pending === job_id) this.owner_accepted_pending = null
      if (gcode_path) import('node:fs').then(fs => fs.unlink(gcode_path, () => {}))
    }
  }

  async _poll_job_status(job_id) {
    if (!this.active_job || this.active_job.job_id !== job_id) return

    try {
      const status = await this.adapter.getStatus(this.handle)

      if (status.state === 'printing') {
        // Sanity check: if we get 100% on the very first poll before has_been_printing
        // is set, it's stale data from the previous job — skip this update.
        const is_stale_start = !this.active_job.has_been_printing && status.progress_pct >= 100
        if (is_stale_start) {
          log.info({ job_id, progress_pct: status.progress_pct }, 'Skipping stale 100% progress at job start — waiting for real data')
          return
        }
        log.info({ job_id, progress_pct: status.progress_pct, layer_num: status.layer_num }, 'Status poll: printing')
        this.active_job.has_been_printing = true
        this._send('JOB_STATUS_UPDATE', {
          job_id,
          status:           'printing',
          progress_pct:     status.progress_pct,
          layer_num:        status.layer_num,
          total_layers:     status.total_layers,
          remaining_time_s: status.remaining_time_s,
          temperatures:     status.temperatures,
        })
      } else if (status.state === 'idle') {
        if (!this.active_job.has_been_printing) {
          log.debug({ job_id }, 'Printer idle but has not started printing yet — waiting...')
          return
        }
        log.info({ job_id }, 'Print completed')
        this.metrics.counters.jobs_completed++
        this._send('JOB_STATUS_UPDATE', { job_id, status: 'completed', progress_pct: 100 })
        this._cleanup_job()
      } else if (status.state === 'cancelled') {
        // Moonraker shows 'cancelled' after we issued the cancel — already handled
        // by _handle_job_cancelled, so just clean up quietly without failing the job.
        log.info({ job_id }, 'Printer confirmed cancellation')
        this._cleanup_job()
      } else if (status.state === 'error') {
        const err_msg = status.error_message ?? 'printer_error'
        log.error({ job_id, klipper_error: err_msg }, 'Printer reported error')
        this.metrics.counters.jobs_failed++
        this._send('JOB_STATUS_UPDATE', { job_id, status: 'failed', error: err_msg })
        this._cleanup_job()
      }
    } catch (err) {
      log.warn({ err: err.message, job_id }, 'Status poll failed')
    }
  }

  async _handle_job_cancelled(payload) {
    const { job_id } = payload
    log.info({ job_id }, 'Job cancelled by server')
    // Could be cancelled while still pending (owner hadn't decided yet)
    if (this.pending_job?.job_id === job_id) {
      const { gcode_path } = this.pending_job
      this.pending_job = null
      if (gcode_path) import('node:fs').then(fs => fs.unlink(gcode_path, () => {}))
      return
    }
    if (this.active_job?.job_id === job_id) {
      try { await this.adapter.cancelJob(this.handle) }
      catch (err) { log.error({ err: err.message, job_id }, 'Failed to cancel job on printer') }
      this._cleanup_job()
    }
  }

  async _handle_update_available(payload) {
    const { image } = payload

    // Under the supervisor, the exit/defer decision is not ours to make on our own
    // active_job — an idle Agent must not restart the shared process while a
    // sibling is mid-print. Delegate to the supervisor's all-idle gate (SMA-N2).
    if (this.on_update_available) {
      log.info({ image }, 'UPDATE_AVAILABLE received — deferring to supervisor update gate')
      return this.on_update_available(image)
    }

    log.info({ image }, 'UPDATE_AVAILABLE received — triggering Watchtower self-update')

    // Refuse to self-update mid-print to avoid leaving a job orphaned.
    if (this.active_job) {
      log.warn({ job_id: this.active_job.job_id }, 'Update deferred — print in progress; will update after job completes')
      // Store the pending image tag so _cleanup_job() can trigger it after completion.
      this._pending_update_image = image
      return
    }

    await this._do_watchtower_update(image)
  }

  /*
   * Operator-requested restart (no new image involved).
   *
   * Watchtower cannot do this: its /v1/update is an image CHECK, so with an
   * unchanged digest it recreates nothing. That gap is what stranded a node
   * whose settings were changed after its last restart — the setting was read
   * once at boot and no restart was ever coming.
   *
   * We exit cleanly instead and let Docker's `restart: unless-stopped` bring us
   * back. Same mid-print discipline as a self-update: a restart that orphans a
   * running job is worse than a slow one, so defer rather than interrupt.
   * Unlike an update there is no pending-image to apply afterwards — the
   * operator can simply ask again once the job finishes.
   */
  async _handle_restart_requested(payload) {
    const reason = payload?.reason ?? null

    if (this.active_job) {
      log.warn({ job_id: this.active_job.job_id, reason },
        'Restart requested but a print is in progress — refusing')
      this._send('RESTART_RESULT', { accepted: false, reason: 'print_in_progress', job_id: this.active_job.job_id })
      return
    }

    // Under the supervisor one process serves several nodes, so this Agent does
    // not get to end it on its own account — a sibling may be printing.
    if (this.on_update_available) {
      log.warn({ reason }, 'Restart requested but this agent is supervised — refusing')
      this._send('RESTART_RESULT', { accepted: false, reason: 'supervised' })
      return
    }

    log.info({ reason }, 'Restart requested by operator — draining and exiting')
    this._send('RESTART_RESULT', { accepted: true })

    // Let the ACK flush before the socket goes away, then drain exactly as a
    // SIGTERM would rather than dropping the process where it stands.
    setTimeout(async () => {
      try { await this.shutdown('RESTART_REQUESTED') } catch (err) {
        log.warn({ err: err.message }, 'Error during restart drain')
      }
      process.exit(0)
    }, 500)
  }

  async _do_watchtower_update(image) {
    // The Watchtower HTTP handshake lives in self_update.js so the supervisor's
    // all-idle update gate can drive the same restart path (SMA-N2). If Watchtower
    // accepted, give it a moment to pull the image, then exit cleanly — Docker's
    // restart policy brings us back up on the new image and the job resumes.
    const accepted = await request_watchtower_update(image)
    if (accepted) {
      setTimeout(() => {
        log.info('Exiting for self-update restart')
        process.exit(0)
      }, 3_000)
    }
  }

  _cleanup_job() {
    if (!this.active_job) return
    const job = this.active_job
    this.active_job = null  // null first to prevent double-cleanup races
    this.owner_accepted_pending = null
    if (job.poll_timer) clearInterval(job.poll_timer)
    if (job.camera)     job.camera.stop()
    if (job.gcode_path) import('node:fs').then(fs => fs.unlink(job.gcode_path, () => {}))

    // If an update arrived while we were printing, apply it now.
    if (this._pending_update_image) {
      const img = this._pending_update_image
      this._pending_update_image = null
      log.info({ image: img }, 'Print complete — applying deferred update now')
      this._do_watchtower_update(img).catch(err =>
        log.warn({ err: err.message }, 'Deferred Watchtower update failed')
      )
    }
  }

  _send(type, payload) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload, ts: Date.now() }))
    }
  }
}
