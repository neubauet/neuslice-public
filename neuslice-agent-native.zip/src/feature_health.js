/**
 * feature_health.js — per-feature health tracking for the agent.
 *
 * Agent "features" (camera, and future ones like filament sync) can degrade
 * independently of the print itself: the camera bug (#189) failed silently — it
 * caught its own error, disabled itself, and the print kept working, so the only
 * signal was a `warn` in the node's local container logs that never left the
 * owner's LAN. This module lets the agent report each feature's status
 * affirmatively (in the heartbeat, for steady-state) and emit a discrete event
 * on a degrade/recover transition (for alerting → backend → GCP → the SRE
 * monitor). Pure and side-effect-free so the transition logic is unit-testable.
 */

const DEGRADED = new Set(['disabled', 'failed', 'degraded'])

/** Is this status a degradation worth alerting on (vs streaming/idle/ok)? */
export function isDegraded(status) {
  return DEGRADED.has(status)
}

export function createFeatureHealth() {
  return {}
}

/**
 * Record a feature's current status. Mutates `state` and returns:
 *   - changed:    the status or reason differs from what was stored
 *   - shouldEmit: emit a discrete NODE_FEATURE_EVENT — true only when the feature
 *                 just BECAME degraded or just RECOVERED from a degraded state.
 *                 Plain idle↔streaming churn and unchanged states don't emit; the
 *                 heartbeat's `features` block carries steady state for the UI.
 *   - degraded:   whether the new status is a degradation.
 *
 * @param {object} state   feature-health map from createFeatureHealth()
 * @param {string} feature e.g. 'camera'
 * @param {string} status  e.g. 'streaming' | 'disabled' | 'idle'
 * @param {string|null} reason short machine reason, e.g. 'stream_token_failed'
 */
export function updateFeatureHealth(state, feature, status, reason = null) {
  const prev = state[feature]
  const prevStatus = prev?.status ?? null
  const prevReason = prev?.reason ?? null
  const changed = prevStatus !== status || prevReason !== (reason ?? null)
  state[feature] = { status, reason: reason ?? null, at: new Date().toISOString() }

  const becameDegraded = isDegraded(status) && !isDegraded(prevStatus)
  const recovered      = !isDegraded(status) && isDegraded(prevStatus)
  return { changed, shouldEmit: becameDegraded || recovered, degraded: isDegraded(status) }
}

/** Drop a feature from tracking (e.g. print ended) — no event, no alert. */
export function clearFeatureHealth(state, feature) {
  delete state[feature]
}
