/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * The supervisor's per-node config store (spec §3.4, printers.d/).
 *
 * The parse is defensive because 3c's agent-pull writes into this store from a
 * relayed browser value: a malformed or hostile entry must be skipped, never
 * crash the boot or bind a node to junk.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { parse_node_config, read_node_configs } from './config_store.js'

// ── parse_node_config ─────────────────────────────────────────────────────────

test('a valid entry normalizes', () => {
  const raw = JSON.stringify({ node_id: 'a1b2c3', token: 'tok', adapter: 'klipper', config: { host: 'http://1.2.3.4' } })
  assert.deepEqual(parse_node_config(raw), {
    node_id: 'a1b2c3', token: 'tok', adapter: 'klipper', config: { host: 'http://1.2.3.4' },
  })
})

test('adapter/config are optional (Bambu shares one Bambuddy)', () => {
  assert.deepEqual(parse_node_config(JSON.stringify({ node_id: 'n', token: 't' })),
    { node_id: 'n', token: 't', adapter: null, config: {} })
})

test('missing node_id or token → null', () => {
  assert.equal(parse_node_config(JSON.stringify({ token: 't' })), null)
  assert.equal(parse_node_config(JSON.stringify({ node_id: 'n' })), null)
})

test('an invalid node_id charset is rejected (it reaches a WS binding query)', () => {
  assert.equal(parse_node_config(JSON.stringify({ node_id: 'bad id!', token: 't' })), null)
  assert.equal(parse_node_config(JSON.stringify({ node_id: 'a'.repeat(65), token: 't' })), null)
})

test('an unknown adapter is dropped to null, never honored', () => {
  assert.equal(parse_node_config(JSON.stringify({ node_id: 'n', token: 't', adapter: 'evil' })).adapter, null)
})

test('bad JSON / non-object → null, never throws', () => {
  assert.equal(parse_node_config('{not json'), null)
  assert.equal(parse_node_config('[]'), null)
  assert.equal(parse_node_config('42'), null)
})

// ── read_node_configs ─────────────────────────────────────────────────────────

test('reads *.json, skips malformed + duplicate node_ids, ignores non-json', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nscfg-'))
  try {
    fs.writeFileSync(path.join(dir, '01.json'), JSON.stringify({ node_id: 'n1', token: 't1', adapter: 'bambu' }))
    fs.writeFileSync(path.join(dir, '02.json'), JSON.stringify({ node_id: 'n2', token: 't2', adapter: 'klipper', config: { host: 'h' } }))
    fs.writeFileSync(path.join(dir, '03.json'), '{ broken')                                       // skipped
    fs.writeFileSync(path.join(dir, '04.json'), JSON.stringify({ node_id: 'n1', token: 'dup' }))  // dup → skipped
    fs.writeFileSync(path.join(dir, 'notes.txt'), 'ignored')                                      // non-json ignored

    const cfgs = read_node_configs(dir)
    assert.deepEqual(cfgs.map(c => c.node_id), ['n1', 'n2'])
    assert.equal(cfgs[1].adapter, 'klipper')
    assert.deepEqual(cfgs[1].config, { host: 'h' })
  } finally {
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('a missing printers.d directory yields [] (fresh install), never throws', () => {
  assert.deepEqual(read_node_configs(path.join(os.tmpdir(), 'nscfg-does-not-exist-xyz')), [])
})
