import 'dotenv/config'
import { load_adapter, load_node_adapter } from './adapters/index.js'
import { start_health_server } from './health.js'
import { Agent } from './agent.js'
import { read_node_configs, default_config_dir } from './config_store.js'
import { start_supervisor, shutdown_all, reconcile_configs, log_config_drift } from './supervisor.js'
import { create_update_gate } from './update_gate.js'
import { request_watchtower_update } from './self_update.js'
import { make_native_do_update, create_velopack_updater } from './self_update_native.js'
import { start_stop_watch } from './stop_sentinel.js'
import log from './logger.js'

const NEUSLICE_API_URL = process.env.NEUSLICE_API_URL ?? 'https://printshare-backend-234aeo2mva-uc.a.run.app'

// Feature-flag semantics match the backend's flag(): unset/blank → default;
// false/0/no/off → false; anything else → true.
function flag(value, def = false) {
  if (value == null || String(value).trim() === '') return def
  return !['false', '0', 'no', 'off'].includes(String(value).trim().toLowerCase())
}
const SUPERVISOR_ENABLED = flag(process.env.SUPERVISOR_ENABLED, false)

// Native runtime (Windows service via WinSW): the Service Control Manager stop
// can't send a POSIX signal, and WinSW hard-kills by default — which would abort an
// in-flight print. So the WinSW stop-helper (service_stop.js) writes a stop sentinel
// this process watches and translates into the same graceful drain the SIGTERM path
// uses (Procedure B2 / SMA-N2). Unset ⇒ unchanged container behavior; no poll loop.
const NATIVE_RUNTIME = String(process.env.AGENT_RUNTIME ?? '').trim().toLowerCase() === 'native'

// ── Single-agent boot (default; unchanged behavior) ───────────────────────────

async function boot_single_agent() {
  const NEUSLICE_TOKEN   = process.env.NEUSLICE_TOKEN
  const NEUSLICE_NODE_ID = process.env.NEUSLICE_NODE_ID

  if (!NEUSLICE_TOKEN) {
    console.error('ERROR: NEUSLICE_TOKEN is required. Set it in your environment or .env file.')
    console.error('  Get your token at https://neuslice.com → Register Printer')
    process.exit(1)
  }

  if (!NEUSLICE_NODE_ID) {
    console.error('ERROR: NEUSLICE_NODE_ID is required. Set it in your environment or .env file.')
    console.error('  Get your node ID at https://neuslice.com → Register Printer')
    process.exit(1)
  }

  // Fetch node config from the API to get owner-configured settings
  // (e.g. default_filament_types for Klipper printers without save_variables).
  // Non-fatal — we proceed with empty opts if the fetch fails.
  let node_opts = {}
  try {
    const node_res = await fetch(`${NEUSLICE_API_URL}/nodes/${NEUSLICE_NODE_ID}`, {
      headers: { Authorization: `Bearer ${NEUSLICE_TOKEN}` },
      signal: AbortSignal.timeout(8000),
    })
    if (node_res.ok) {
      const node_data = await node_res.json()
      if (Array.isArray(node_data.default_filament_types) && node_data.default_filament_types.length > 0) {
        node_opts.defaultFilamentTypes = node_data.default_filament_types
      }
    }
  } catch (err) {
    console.warn(`WARN: Could not fetch node config (${err.message}) — proceeding without defaults`)
  }

  // Load the printer adapter — retry with backoff so transient Moonraker/Bambuddy
  // unavailability (e.g. printer booting up) doesn't crash-loop the container.
  let adapter, handle
  {
    const MAX_ATTEMPTS = 10
    const BASE_DELAY_MS = 5_000
    let last_err
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        ;({ adapter, handle } = await load_adapter(node_opts))
        last_err = null
        break
      } catch (err) {
        last_err = err
        const delay = Math.min(BASE_DELAY_MS * attempt, 60_000)
        console.error(`ERROR: Failed to connect to printer adapter (attempt ${attempt}/${MAX_ATTEMPTS}): ${err.message} — retrying in ${delay / 1000}s`)
        if (attempt < MAX_ATTEMPTS) await new Promise(r => setTimeout(r, delay))
      }
    }
    if (last_err) {
      console.error(`ERROR: Printer adapter connection failed after ${MAX_ATTEMPTS} attempts — giving up`)
      process.exit(1)
    }
  }

  log.info(
    { node_id: NEUSLICE_NODE_ID, api_url: NEUSLICE_API_URL, adapter: adapter.name },
    'NeuSlice agent starting'
  )

  const agent = new Agent({
    token:   NEUSLICE_TOKEN,
    node_id: NEUSLICE_NODE_ID,
    api_url: NEUSLICE_API_URL,
    adapter,
    handle,
  })

  // Record process start time for uptime calculation in health metrics
  globalThis._agent_start = Date.now()

  // Start local health/metrics HTTP server (port 9101)
  start_health_server()

  // Graceful shutdown — Watchtower's own poll cycle sends SIGTERM directly to this
  // container (independent of the UPDATE_AVAILABLE defer-if-printing path, which
  // only covers backend-initiated updates). Without a handler here, Node's default
  // SIGTERM behavior kills the process immediately mid-print with zero cleanup.
  let shutting_down = false
  async function handle_shutdown_signal(signal) {
    if (shutting_down) return
    shutting_down = true
    try {
      await agent.shutdown(signal)
    } catch (err) {
      log.warn({ err: err.message }, 'Error during shutdown')
    } finally {
      process.exit(0)
    }
  }
  process.on('SIGTERM', () => handle_shutdown_signal('SIGTERM'))
  process.on('SIGINT', () => handle_shutdown_signal('SIGINT'))
  // Some Windows wrappers deliver Ctrl+Break on stop → Node raises SIGBREAK.
  process.on('SIGBREAK', () => handle_shutdown_signal('SIGBREAK'))

  // Native runtime (WinSW): the service stop can't deliver a POSIX signal, so the
  // stop-helper writes a sentinel this process watches → the same graceful drain (B2).
  if (NATIVE_RUNTIME) {
    start_stop_watch({ onStop: handle_shutdown_signal })
    log.info('Native runtime — watching for the service stop sentinel')
  }

  agent.start()
}

// ── Supervisor boot (SUPERVISOR_ENABLED) — one process, one Agent per node ─────

/** Per-node opts fetch (default_filament_types), authenticated with the node's own token. */
async function fetch_node_opts(node_id, token) {
  const opts = {}
  const res = await fetch(`${NEUSLICE_API_URL}/nodes/${node_id}`, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(8000),
  })
  if (res.ok) {
    const data = await res.json()
    if (Array.isArray(data.default_filament_types) && data.default_filament_types.length > 0) {
      opts.defaultFilamentTypes = data.default_filament_types
    }
  }
  return opts
}

/**
 * Fetch the owner's full node list via the agent-scoped listing (GET /nodes?agent=true,
 * require_agent). Any of the configs' tokens works — the endpoint keys off the
 * token's own owner_uid — so we try them in turn until one is accepted (a deleted
 * node's token would 401). Returns the node array, or null if none succeeds (the
 * endpoint may not be deployed yet, or the backend is unreachable).
 */
async function fetch_owner_nodes(configs) {
  for (const cfg of configs) {
    try {
      const res = await fetch(`${NEUSLICE_API_URL}/nodes?agent=true`, {
        headers: { Authorization: `Bearer ${cfg.token}` },
        signal: AbortSignal.timeout(8000),
      })
      if (res.ok) {
        const data = await res.json()
        if (Array.isArray(data?.nodes)) return data.nodes
      }
    } catch { /* try the next token */ }
  }
  return null
}

/**
 * Config↔backend drift reconcile on boot (spec §3.4 / SMA-6 / R-6). Non-fatal.
 *
 * Preferred: the agent-scoped listing gives the owner's FULL node set, so drift is
 * reported in BOTH directions (config→backend and backend→config) via the shared
 * log_config_drift. Fallback (endpoint not deployed / no token accepted): probe each
 * config's node_id with the unauthenticated GET /nodes/:id — this still catches the
 * config→backend direction (a config entry pointing at a node that doesn't exist).
 */
async function reconcile_on_boot(configs) {
  const owner_nodes = await fetch_owner_nodes(configs)
  if (owner_nodes) {
    log_config_drift(configs, owner_nodes)
    return
  }

  const present = []
  for (const cfg of configs) {
    try {
      const res = await fetch(`${NEUSLICE_API_URL}/nodes/${cfg.node_id}`, { signal: AbortSignal.timeout(8000) })
      // Treat anything but a definitive 404 as "present" so a transient 5xx/network
      // blip never flags a real node as an orphan.
      if (res.status !== 404) present.push({ node_id: cfg.node_id })
    } catch (err) {
      log.warn({ node_id: cfg.node_id, err: err.message }, '[supervisor] drift check skipped (backend unreachable) — not flagged')
      present.push({ node_id: cfg.node_id })
    }
  }
  const { matched, config_only } = reconcile_configs(configs, present)
  if (config_only.length) {
    log.warn({ node_ids: config_only },
      '[supervisor] config entries with no backend node (deleted/typo) — those Agents will fail to authenticate')
  } else {
    log.info({ nodes: matched.length }, '[supervisor] config ↔ backend reconciled (config→backend); no orphans')
  }
  log.info('[supervisor] backend→config drift check skipped (agent listing endpoint unavailable)')
}

async function boot_supervisor() {
  const dir = default_config_dir()
  const configs = read_node_configs(dir)
  log.info({ dir, count: configs.length }, 'Supervisor mode enabled — one Agent per node')

  if (configs.length === 0) {
    console.error('ERROR: SUPERVISOR_ENABLED is set but no node configs were found.')
    console.error(`  Expected one JSON file per node ({ node_id, token, adapter?, config? }) under: ${dir}`)
    process.exit(1)
  }

  // Reconcile local store against the backend before we start dialing sockets.
  await reconcile_on_boot(configs)

  // gate is assigned after start_supervisor returns; the closure below only reads
  // it when an UPDATE_AVAILABLE actually arrives (well after boot), so the ?. guard
  // is belt-and-suspenders against an update racing boot.
  let gate
  const agents = await start_supervisor({
    configs,
    api_url:       NEUSLICE_API_URL,
    connect:       (cfg, opts) => load_node_adapter(cfg, opts),
    fetchNodeOpts: (cfg)       => fetch_node_opts(cfg.node_id, cfg.token),
    buildAgent:    ({ token, node_id, api_url, adapter, handle }) =>
      new Agent({ token, node_id, api_url, adapter, handle,
        on_update_available: (image) => gate?.request(image) }),
  })
  // Note: per-node connect is single-attempt at boot (SMA-4b isolation). A printer
  // still booting is isolated + logged rather than retried, to avoid one slow node
  // blocking its siblings' boot; it recovers on the next supervisor restart. Per-node
  // connect-retry / parallel boot is a follow-up refinement.

  if (agents.length === 0) {
    console.error('ERROR: no nodes started — see the per-node connect failures logged above')
    process.exit(1)
  }

  // Supervisor owns the update gate (SMA-N2): an UPDATE_AVAILABLE on any socket
  // restarts the process only once EVERY Agent is idle, so an idle node never
  // exits the process mid-print on a sibling. The gate is the SAME; only the
  // doUpdate differs by runtime — Velopack on native Windows, Watchtower otherwise.
  const drain = (signal) => shutdown_all(agents, signal, { timeoutMs: 10_000 })

  let native_do_update = null
  if (NATIVE_RUNTIME) {
    // AGENT_AUTO_UPDATE is an operator kill-switch (default on); create_velopack_updater
    // returns null anyway until the feed is configured (cert-followup).
    const updater = flag(process.env.AGENT_AUTO_UPDATE, true) ? create_velopack_updater() : null
    if (updater) {
      native_do_update = make_native_do_update({ updater, drain })
      log.info('Native runtime — self-update via Velopack (SMA-N6)')
    } else {
      // No feed configured (unsigned/dev) or AGENT_AUTO_UPDATE=off: there is no
      // Watchtower on Windows, so self-update is a quiet no-op (avoids the
      // Watchtower-unreachable retry spam the fallback below would produce).
      native_do_update = async () => { /* no-op */ }
      log.info('Native runtime — self-update disabled/unconfigured; running without auto-update')
    }
  }

  gate = create_update_gate({
    agents,
    doUpdate: native_do_update ?? (async (image) => {
      // Container/Linux: Watchtower. image is the pull target for Watchtower's config.
      const accepted = await request_watchtower_update(image)
      if (!accepted) return
      log.info('All agents idle — draining for self-update restart')
      await drain('SELF_UPDATE')
      process.exit(0)
    }),
  })

  globalThis._agent_start = Date.now()
  start_health_server()  // single server; aggregates every Agent via the metrics registry

  // Shutdown fan-out (SMA-N2): drain every Agent with a per-agent timeout.
  let shutting_down = false
  async function handle_shutdown_signal(signal) {
    if (shutting_down) return
    shutting_down = true
    try {
      await shutdown_all(agents, signal, { timeoutMs: 10_000 })
    } catch (err) {
      log.warn({ err: err.message }, 'Error during supervisor shutdown')
    } finally {
      process.exit(0)
    }
  }
  process.on('SIGTERM', () => handle_shutdown_signal('SIGTERM'))
  process.on('SIGINT', () => handle_shutdown_signal('SIGINT'))
  process.on('SIGBREAK', () => handle_shutdown_signal('SIGBREAK'))

  // Native runtime (WinSW): the service stop can't deliver a POSIX signal, so the
  // stop-helper writes a sentinel the supervisor watches → the same graceful drain
  // of EVERY Agent (shutdown_all), Procedure B2 / SMA-N2.
  if (NATIVE_RUNTIME) {
    start_stop_watch({ onStop: handle_shutdown_signal })
    log.info('Native runtime — watching for the service stop sentinel')
  }

  // Runtime failure isolation (SMA-4b / R-3). One process now hosts every one of a
  // host's printers, so a stray rejection in ONE Agent's async path (a message
  // handler, a poll, a socket callback) must not take the process down and with it
  // all the other printers. start_supervisor's try/catch only covers BOOT; this is
  // the runtime net. We log and keep running rather than exit — the opposite of
  // Node's default, and deliberately scoped to supervisor mode (the single-agent
  // path keeps Node's default so a solo agent still crash-restarts as before).
  process.on('unhandledRejection', (reason) => {
    log.error({ err: reason?.message ?? String(reason) },
      '[supervisor] unhandled rejection — isolated, process kept alive (SMA-4b)')
  })

  log.info({ started: agents.length, configured: configs.length }, 'Supervisor running')
}

// ── Entry ─────────────────────────────────────────────────────────────────────

// Native runtime: VelopackApp must run FIRST — it handles the install/update/uninstall
// hooks and may briefly restart the process. Guarded + lazy (velopack is an optional,
// Windows-only dependency). setAutoApplyOnStartup(false) keeps the all-idle update gate
// the SOLE authority on WHEN an update is applied (SMA-N2) — never a surprise apply on
// startup while a sibling Agent is mid-print.
if (NATIVE_RUNTIME) {
  try {
    const { VelopackApp } = await import('velopack')
    VelopackApp.build().setAutoApplyOnStartup(false).run()
  } catch (err) {
    log.warn({ err: err.message }, 'VelopackApp init skipped (velopack binding unavailable)')
  }
}

if (SUPERVISOR_ENABLED) {
  await boot_supervisor()
} else {
  await boot_single_agent()
}
