/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * Operator-requested agent restart.
 * Run: node --test src/agent.restart.test.js
 *
 * Why this exists at all: several agent settings are read once at boot, and
 * Watchtower's /v1/update is an image CHECK — with an unchanged digest it
 * recreates nothing. So a node whose settings changed after its last boot had
 * no restart coming, and the only remedy was asking the owner to run docker
 * commands. This path exits cleanly and lets `restart: unless-stopped` return.
 *
 * The guarantee under test is the refusal, not the restart. Exiting is trivial;
 * exiting while a customer's print is running is a ruined job and a refund, and
 * a refusal that reports success is worse than either because the operator then
 * waits for a bounce that never comes.
 *
 * `_handle_restart_requested` is exercised against a minimal stand-in rather
 * than a live Agent: a real one opens a WebSocket and registers metrics at
 * construction, and the logic under test touches neither.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

// spawn.js throws at import when this is unset, and static imports hoist above
// any assignment — hence the dynamic import.
process.env.NEUSLICE_API_URL ??= 'http://test.invalid'
const { Agent } = await import('./agent.js')

/** A stand-in carrying only the fields the handler reads or writes. */
function restartable({ active_job = null, supervised = false } = {}) {
  const sent = []
  return {
    active_job,
    on_update_available: supervised ? () => {} : null,
    _send: (type, payload) => sent.push({ type, payload }),
    shutdown: async function () { this._drained = true },
    _drained: false,
    sent,
    _handle_restart_requested: Agent.prototype._handle_restart_requested,
  }
}

test('RST-1: an idle agent accepts and reports acceptance', async () => {
  const a = restartable()
  await a._handle_restart_requested({ reason: 'admin dashboard' })
  assert.deepEqual(a.sent, [{ type: 'RESTART_RESULT', payload: { accepted: true } }])
})

test('RST-2: a printing agent refuses, and says why', async () => {
  // The job matters more than the restart. Refusing loudly lets the operator
  // decide to wait rather than wonder.
  const a = restartable({ active_job: { job_id: 'job-77' } })
  await a._handle_restart_requested({})
  assert.equal(a.sent.length, 1)
  assert.equal(a.sent[0].payload.accepted, false)
  assert.equal(a.sent[0].payload.reason, 'print_in_progress')
  assert.equal(a.sent[0].payload.job_id, 'job-77', 'name the job so it is actionable')
})

test('RST-3: a printing agent does not drain', async () => {
  const a = restartable({ active_job: { job_id: 'job-77' } })
  await a._handle_restart_requested({})
  assert.equal(a._drained, false, 'a refused restart must not tear anything down')
})

test('RST-4: a supervised agent refuses — the process is not its to end', async () => {
  // Under the supervisor one process serves several nodes. An idle Agent
  // exiting would take a printing sibling down with it.
  const a = restartable({ supervised: true })
  await a._handle_restart_requested({})
  assert.equal(a.sent[0].payload.accepted, false)
  assert.equal(a.sent[0].payload.reason, 'supervised')
  assert.equal(a._drained, false)
})

test('RST-5: the mid-print check wins over the supervised check', async () => {
  // Both true: report the print, since that is the reason the operator can act
  // on — "supervised" would send them looking at the wrong thing.
  const a = restartable({ active_job: { job_id: 'job-9' }, supervised: true })
  await a._handle_restart_requested({})
  assert.equal(a.sent[0].payload.reason, 'print_in_progress')
})

test('RST-6: the ACK is sent before anything is torn down', async () => {
  // Draining closes the WebSocket, so an ACK queued after it would never
  // arrive and the dashboard would show a timeout for a successful restart.
  const a = restartable()
  await a._handle_restart_requested({})
  assert.equal(a.sent.length, 1, 'acknowledged')
  assert.equal(a._drained, false, 'drain is deferred past the ACK, not inline')
})

test('RST-7: a missing payload is tolerated', async () => {
  const a = restartable()
  await a._handle_restart_requested(undefined)
  assert.equal(a.sent[0].payload.accepted, true)
})
