param(
    [Parameter(Mandatory = $true)][string]$PackagePath,
    [Parameter(Mandatory = $true)][string]$CatalogPath,
    [Parameter(Mandatory = $true)][string]$Publisher
)
$ErrorActionPreference = 'Stop'
# Catalog hashes cover the entire nupkg, including JavaScript and dependencies.
# Feed hashes alone do not authenticate a release if the feed is compromised.
$signature = Get-AuthenticodeSignature -LiteralPath $CatalogPath
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -cne $Publisher) {
    throw 'Release catalog is not signed by the trusted NeuSlice publisher.'
}
$result = Test-FileCatalog -Path $PackagePath -CatalogFilePath $CatalogPath
if ([string]$result -ne 'Valid') { throw 'Release package does not match its signed catalog.' }
Write-Output 'Verified'
