param(
    [Parameter(Mandatory = $true)][string]$RequestPath
)
$ErrorActionPreference = 'Stop'
$request = Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
$work = Split-Path -Parent $RequestPath
$logPath = Join-Path $work 'result.log'
$committed = $false
$applyInProgress = $false
try {
    $root = [IO.Path]::GetFullPath($request.root)
    $package = [IO.Path]::GetFullPath($request.package)
    if ((Split-Path -Parent $package) -ne (Join-Path $root 'packages')) { throw 'Package outside install root' }
    if ($request.service -ne 'neuslice-agent') { throw 'Unexpected service identity' }
    $svc = Get-Service -Name $request.service -ErrorAction Stop
    $installed = Get-CimInstance Win32_Service -Filter "Name='neuslice-agent'"
    if ($installed.PathName.Trim('"') -ne (Join-Path $root 'service\neuslice-agent.exe')) {
        throw 'Service does not belong to this Velopack installation'
    }
    & (Join-Path $work 'verify-package.ps1') -PackagePath $package -CatalogPath $request.catalog -Publisher $request.publisher | Out-Null
    [IO.File]::WriteAllText((Join-Path $work 'ready'), 'ready')
    $deadline = [DateTime]::UtcNow.AddSeconds(30)
    while (-not (Test-Path -LiteralPath (Join-Path $work 'commit'))) {
        if (Test-Path -LiteralPath (Join-Path $work 'cancel')) { return }
        if ([DateTime]::UtcNow -gt $deadline) { throw 'Agent did not commit update; service unchanged' }
        Start-Sleep -Milliseconds 100
    }
    # SCM must know the service is stopping BEFORE Node exits, otherwise recovery
    # restarts the old process while Velopack replaces its files.
    $committed = $true
    Stop-Service -Name $request.service -ErrorAction Stop
    $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(45))
    $applyArgs = @('--silent', '--rootDir', ('"' + $root + '"'), '--packageDir', ('"' + (Join-Path $root 'packages') + '"'),
        '--log', ('"' + (Join-Path $work 'velopack.log') + '"'), 'apply', '--norestart', '--package', ('"' + $package + '"'))
    # Update.exe is a GUI executable: '& Update.exe' can return before it exits
    # and leaves LASTEXITCODE unset. Explicitly wait before touching the service.
    $applyProcess = Start-Process -FilePath (Join-Path $root 'Update.exe') -ArgumentList $applyArgs -PassThru -WindowStyle Hidden
    $applyInProgress = $true
    if (-not $applyProcess.WaitForExit(120000)) { throw 'Velopack apply timed out; service remains stopped while updater is active' }
    $applyInProgress = $false
    if ($applyProcess.ExitCode -ne 0) { throw "Velopack apply failed (exit $($applyProcess.ExitCode))" }
    [xml]$manifest = Get-Content -LiteralPath (Join-Path $root 'current\sq.version') -Raw
    if ([string]$manifest.package.metadata.version -ne $request.version) { throw 'Installed version does not match release' }
    Start-Service -Name $request.service -ErrorAction Stop
    $svc.WaitForStatus('Running', [TimeSpan]::FromSeconds(45))
    [IO.File]::WriteAllText($logPath, "Applied $($request.version); service running")
} catch {
    $failure = "Update failed: $($_.Exception.Message)"
    if ($committed -and -not $applyInProgress) {
        try { Start-Service -Name $request.service -ErrorAction Stop }
        catch { $failure += "; service recovery failed: $($_.Exception.Message)" }
    }
    if ((Get-Service -Name $request.service -ErrorAction SilentlyContinue).Status -eq 'Running') {
        [IO.File]::WriteAllText((Join-Path $work 'resume-safe'), 'Service running; helper finished')
    }
    [IO.File]::WriteAllText($logPath, $failure)
    exit 1
}
