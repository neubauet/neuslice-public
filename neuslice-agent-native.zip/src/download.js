/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */
import fetch from 'node-fetch'
import https from 'node:https'
import dns from 'node:dns'
import net from 'node:net'
import { createWriteStream } from 'node:fs'
import { pipeline } from 'node:stream/promises'

// Both url and job_id arrive from the backend over the WebSocket, i.e. they
// are untrusted from this host's point of view. Constrain them:
//  - job_id builds a filesystem path → must be a UUID (a value like
//    "../../etc/cron.d/x" would otherwise escape /tmp: arbitrary write).
//  - url is fetched from inside this container (which may run with host
//    networking) → require https to a plausible remote host, never a bare-IP
//    LAN/loopback address (SSRF into the owner's home network).
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const IP_HOST_RE = /^(\d{1,3}\.){3}\d{1,3}$|^\[/ // IPv4 literal or [IPv6] literal

function assert_safe_download(url, job_id) {
  if (typeof job_id !== 'string' || !UUID_RE.test(job_id)) {
    throw new Error('DOWNLOAD_REJECTED: job_id is not a valid UUID')
  }
  let parsed
  try { parsed = new URL(url) } catch { throw new Error('DOWNLOAD_REJECTED: invalid gcode_url') }
  if (parsed.protocol !== 'https:') {
    throw new Error(`DOWNLOAD_REJECTED: gcode_url must be https (got ${parsed.protocol})`)
  }
  const host = parsed.hostname.toLowerCase()
  if (IP_HOST_RE.test(host) || host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) {
    throw new Error('DOWNLOAD_REJECTED: gcode_url must not target a local/IP-literal host')
  }
}

// True if `ip` is a loopback / private / link-local / CGNAT / unspecified
// address — i.e. anything on the owner's own machine or LAN, or the cloud
// metadata endpoint (169.254.169.254). Used to validate the ACTUAL resolved
// address at connect time, not just the hostname string.
function is_private_address(ip) {
  const v = ip.replace(/^::ffff:/i, '') // unwrap IPv4-mapped IPv6
  if (net.isIPv4(v)) {
    const [a, b] = v.split('.').map(Number)
    return a === 0 || a === 10 || a === 127 ||
           (a === 169 && b === 254) ||               // link-local + cloud metadata
           (a === 172 && b >= 16 && b <= 31) ||
           (a === 192 && b === 168) ||
           (a === 100 && b >= 64 && b <= 127)         // CGNAT (100.64.0.0/10)
  }
  const low = v.toLowerCase()
  return low === '::1' || low === '::' ||
         low.startsWith('fc') || low.startsWith('fd') || // unique-local
         low.startsWith('fe80')                          // link-local
}

// Custom DNS lookup for the https agent. Runs at connection time and rejects
// the request if the hostname resolves to a private/loopback/metadata address.
// Because the agent uses exactly the address this returns, validating here also
// closes the DNS-rebinding gap (a public hostname whose A record points at an
// internal IP) — the checked IP is the connected IP.
function guarded_lookup(hostname, options, callback) {
  dns.lookup(hostname, options, (err, address, family) => {
    if (err) return callback(err)
    const list = Array.isArray(address) ? address : [{ address, family }]
    for (const a of list) {
      if (is_private_address(a.address)) {
        return callback(new Error(
          `DOWNLOAD_REJECTED: ${hostname} resolved to non-public address ${a.address}`))
      }
    }
    callback(null, address, family)
  })
}

/**
 * Downloads a gcode file from a URL (signed GCS URL or plain HTTPS) to a local tmp path.
 * @param {string} url - The URL to download from
 * @param {string} job_id - The job ID used to name the local file
 * @returns {Promise<string>} The local file path
 */
export async function download_gcode(url, job_id) {
  assert_safe_download(url, job_id)
  const local_path = `/tmp/neuslice-${job_id}.3mf`

  // redirect: 'manual' — never auto-follow. node-fetch's default follows up to
  // 20 redirects with NO re-validation, so a compliant-looking https URL could
  // 302 the request onto http://192.168.x.x or 169.254.169.254 and defeat the
  // checks above. Signed GCS URLs return 200 directly, so any 3xx here is
  // unexpected and rejected outright.
  // The custom agent re-validates the resolved IP at connect time (anti-rebinding).
  const agent = new https.Agent({ lookup: guarded_lookup })
  const res = await fetch(url, { redirect: 'manual', agent })
  if (res.status >= 300 && res.status < 400) {
    throw new Error(`DOWNLOAD_REJECTED: unexpected redirect (HTTP ${res.status}) — refusing to follow`)
  }
  if (!res.ok) throw new Error(`Failed to download gcode: HTTP ${res.status}`)
  await pipeline(res.body, createWriteStream(local_path))
  return local_path
}
