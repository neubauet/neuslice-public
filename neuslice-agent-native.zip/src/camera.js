/**
 * camera.js — Bambuddy snapshot uploader
 *
 * During an active print, grabs a JPEG snapshot from Bambuddy every
 * SNAPSHOT_INTERVAL_MS and uploads it to the NeuSlice backend
 * (which stores it in GCS at jobs/{job_id}/snapshot.jpg).
 *
 * The backend exposes GET /api/v1/jobs/:id/snapshot which returns a
 * short-lived signed GCS URL for the frontend to display.
 */

import fetch from 'node-fetch'
import log from './logger.js'
import { api_base } from './api_base.js'
// Reuse the print adapter's Bambuddy auth so the camera speaks the SAME auth as
// the rest of the agent. The camera used to carry its own login helper that only
// knew username/password Bearer auth and THREW on anything else — so on a no-auth
// Bambuddy (fresh/default install: /auth/login → 400 "Authentication is not
// enabled") or an API-key-only Bambuddy (no username/password), the camera failed
// to get a token and silently disabled itself, while the print itself worked.
// getBearerToken returns null in exactly those cases; writeAuthHeaders/apiHeaders
// then fall back to X-API-Key (or nothing), matching adapters/bambu.js.
import { getBearerToken, writeAuthHeaders, apiHeaders } from './adapters/bambu.js'

const SNAPSHOT_INTERVAL_MS = 5_000    // every 5 seconds
const TOKEN_REFRESH_MS     = 55 * 60 * 1000  // refresh 5 min before 60-min expiry

/**
 * Get a Bambuddy camera stream token (required for snapshot/stream endpoints).
 *
 * Auth mirrors the print path: a Bearer token when Bambuddy runs with
 * username/password auth, otherwise the X-API-Key header (or no auth header at
 * all, for a no-auth Bambuddy). Sending Bearer-only here was the camera bug.
 */
export async function getStreamToken(host, bearerToken, apiKey) {
  const res = await fetch(`${host}/api/v1/printers/camera/stream-token`, {
    method:  'POST',
    headers: writeAuthHeaders(bearerToken, apiKey),
  })
  if (!res.ok) throw new Error(`Failed to get stream token: ${res.status}`)
  const data = await res.json()
  // Bambuddy returns either { token } or the token string directly
  return data.token ?? data
}

export class CameraManager {
  constructor({ handle, job_id, api_url, agent_token, on_status = null }) {
    this.handle      = handle
    this.job_id      = job_id
    this.api_url     = api_url
    this.agent_token = agent_token
    // Optional (status, reason) callback so the agent can report camera health
    // upward — turns the old silent "snapshots disabled" warn into a visible
    // feature-health signal. See feature_health.js / agent.js.
    this.on_status   = on_status

    this._stream_token     = null
    this._snapshot_timer   = null
    this._token_refresh_timer = null
    this._active           = false
  }

  async start() {
    this._active = true
    log.info({ job_id: this.job_id }, 'Camera: starting snapshot uploads')

    try {
      await this._refreshTokens()
      this.on_status?.('streaming')
    } catch (err) {
      log.warn({ err: err.message, job_id: this.job_id }, 'Camera: failed to get stream token — snapshots disabled')
      this.on_status?.('disabled', 'stream_token_failed')
      return
    }

    // Schedule token refresh
    this._token_refresh_timer = setInterval(() => {
      this._refreshTokens().catch(err =>
        log.warn({ err: err.message }, 'Camera: token refresh failed')
      )
    }, TOKEN_REFRESH_MS)

    // Upload first snapshot immediately, then on interval
    await this._uploadSnapshot()
    this._snapshot_timer = setInterval(() => {
      if (!this._active) return
      this._uploadSnapshot().catch(err =>
        log.warn({ err: err.message, job_id: this.job_id }, 'Camera: snapshot upload failed')
      )
    }, SNAPSHOT_INTERVAL_MS)
  }

  stop() {
    this._active = false
    if (this._snapshot_timer)      clearInterval(this._snapshot_timer)
    if (this._token_refresh_timer) clearInterval(this._token_refresh_timer)
    this._snapshot_timer      = null
    this._token_refresh_timer = null
    log.info({ job_id: this.job_id }, 'Camera: stopped')
  }

  async _refreshTokens() {
    const bearer = await getBearerToken(
      this.handle.host,
      this.handle.username,
      this.handle.password,
    )
    this._stream_token = await getStreamToken(this.handle.host, bearer, this.handle.apiKey)
    log.debug({ job_id: this.job_id }, 'Camera: tokens refreshed')
  }

  async _uploadSnapshot() {
    if (!this._stream_token || !this._active) return

    // Fetch snapshot JPEG from Bambuddy. The stream token in the query is the
    // primary auth; also send X-API-Key so an API-key Bambuddy that gates the
    // snapshot endpoint is satisfied (no-op when no key / no-auth).
    const snapRes = await fetch(
      `${this.handle.host}/api/v1/printers/${this.handle.printerId}/camera/snapshot?token=${this._stream_token}`,
      { headers: apiHeaders(this.handle.apiKey) }
    )
    if (!snapRes.ok) {
      // Stream token may have expired — try refreshing once
      if (snapRes.status === 401 || snapRes.status === 403) {
        await this._refreshTokens()
        return  // will retry on next interval
      }
      throw new Error(`Snapshot fetch failed: ${snapRes.status}`)
    }

    const jpeg = await snapRes.buffer()

    // Upload to NeuSlice backend snapshot endpoint
    const uploadRes = await fetch(
      `${api_base(this.api_url)}/jobs/${this.job_id}/snapshot`,
      {
        method:  'POST',
        headers: {
          'Authorization': `Bearer ${this.agent_token}`,
          'Content-Type':  'image/jpeg',
        },
        body: jpeg,
      }
    )
    if (!uploadRes.ok) {
      const text = await uploadRes.text()
      throw new Error(`Snapshot upload to backend failed: ${uploadRes.status} — ${text}`)
    }

    log.debug({ job_id: this.job_id, size: jpeg.length }, 'Camera: snapshot uploaded')
  }
}
