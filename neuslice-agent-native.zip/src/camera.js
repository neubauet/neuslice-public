/**
 * camera.js — Bambuddy snapshot uploader
 *
 * During an active print, grabs a JPEG snapshot from Bambuddy every
 * SNAPSHOT_INTERVAL_MS and uploads it to the NeuSlice backend
 * (which stores it in GCS at jobs/{job_id}/snapshot.jpg).
 *
 * The backend exposes GET /api/v1/jobs/:id/snapshot which returns a
 * short-lived signed GCS URL for the frontend to display.
 */

import fetch from 'node-fetch'
import log from './logger.js'

const SNAPSHOT_INTERVAL_MS = 5_000    // every 5 seconds
const TOKEN_REFRESH_MS     = 55 * 60 * 1000  // refresh 5 min before 60-min expiry

/**
 * Get a Bambuddy Bearer token via username/password login.
 */
async function getBearerToken(host, username, password) {
  const res = await fetch(`${host}/api/v1/auth/login`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ username, password }),
  })
  if (!res.ok) throw new Error(`Bambuddy login failed: ${res.status}`)
  const data = await res.json()
  if (!data.access_token) throw new Error('Bambuddy login returned no access_token')
  return data.access_token
}

/**
 * Get a Bambuddy camera stream token (required for snapshot/stream endpoints).
 */
async function getStreamToken(host, bearerToken) {
  const res = await fetch(`${host}/api/v1/printers/camera/stream-token`, {
    method:  'POST',
    headers: { 'Authorization': `Bearer ${bearerToken}` },
  })
  if (!res.ok) throw new Error(`Failed to get stream token: ${res.status}`)
  const data = await res.json()
  // Bambuddy returns either { token } or the token string directly
  return data.token ?? data
}

export class CameraManager {
  constructor({ handle, job_id, api_url, agent_token }) {
    this.handle      = handle
    this.job_id      = job_id
    this.api_url     = api_url
    this.agent_token = agent_token

    this._stream_token     = null
    this._snapshot_timer   = null
    this._token_refresh_timer = null
    this._active           = false
  }

  async start() {
    this._active = true
    log.info({ job_id: this.job_id }, 'Camera: starting snapshot uploads')

    try {
      await this._refreshTokens()
    } catch (err) {
      log.warn({ err: err.message, job_id: this.job_id }, 'Camera: failed to get stream token — snapshots disabled')
      return
    }

    // Schedule token refresh
    this._token_refresh_timer = setInterval(() => {
      this._refreshTokens().catch(err =>
        log.warn({ err: err.message }, 'Camera: token refresh failed')
      )
    }, TOKEN_REFRESH_MS)

    // Upload first snapshot immediately, then on interval
    await this._uploadSnapshot()
    this._snapshot_timer = setInterval(() => {
      if (!this._active) return
      this._uploadSnapshot().catch(err =>
        log.warn({ err: err.message, job_id: this.job_id }, 'Camera: snapshot upload failed')
      )
    }, SNAPSHOT_INTERVAL_MS)
  }

  stop() {
    this._active = false
    if (this._snapshot_timer)      clearInterval(this._snapshot_timer)
    if (this._token_refresh_timer) clearInterval(this._token_refresh_timer)
    this._snapshot_timer      = null
    this._token_refresh_timer = null
    log.info({ job_id: this.job_id }, 'Camera: stopped')
  }

  async _refreshTokens() {
    const bearer = await getBearerToken(
      this.handle.host,
      this.handle.username,
      this.handle.password,
    )
    this._stream_token = await getStreamToken(this.handle.host, bearer)
    log.debug({ job_id: this.job_id }, 'Camera: tokens refreshed')
  }

  async _uploadSnapshot() {
    if (!this._stream_token || !this._active) return

    // Fetch snapshot JPEG from Bambuddy
    const snapRes = await fetch(
      `${this.handle.host}/api/v1/printers/${this.handle.printerId}/camera/snapshot?token=${this._stream_token}`
    )
    if (!snapRes.ok) {
      // Stream token may have expired — try refreshing once
      if (snapRes.status === 401 || snapRes.status === 403) {
        await this._refreshTokens()
        return  // will retry on next interval
      }
      throw new Error(`Snapshot fetch failed: ${snapRes.status}`)
    }

    const jpeg = await snapRes.buffer()

    // Upload to NeuSlice backend snapshot endpoint
    const uploadRes = await fetch(
      `${this.api_url}/api/v1/jobs/${this.job_id}/snapshot`,
      {
        method:  'POST',
        headers: {
          'Authorization': `Bearer ${this.agent_token}`,
          'Content-Type':  'image/jpeg',
        },
        body: jpeg,
      }
    )
    if (!uploadRes.ok) {
      const text = await uploadRes.text()
      throw new Error(`Snapshot upload to backend failed: ${uploadRes.status} — ${text}`)
    }

    log.debug({ job_id: this.job_id, size: jpeg.length }, 'Camera: snapshot uploaded')
  }
}
