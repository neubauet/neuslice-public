/*
 * update_gate.js — the supervisor's all-idle update gate (spec §3.2 / SMA-N2).
 *
 * With N Agents in one process behind one container image, an UPDATE_AVAILABLE
 * fans out to every socket ([broker.js] broadcast_update_available). If any idle
 * Agent acted on it and exited, it would kill a sibling mid-print. So the exit/
 * defer decision moves OFF the individual Agent and up here: the gate holds the
 * pending update and only runs it once EVERY Agent is idle.
 *
 * How "an Agent finished" is learned: rather than thread an idle-callback through
 * every job-cleanup path in agent.js, the gate re-checks on a bounded poll while
 * an update is pending (rare, and only until the last print finishes). The Agent's
 * only change is to delegate its UPDATE_AVAILABLE to gate.request() instead of
 * deciding on its own active_job.
 */

import { all_idle } from './supervisor.js'
import log from './logger.js'

const DEFAULT_POLL_MS = 30_000

/**
 * @param {Array|function():Array} agents  the live Agents (array or getter); their
 *   is_busy() is read at check time, so the array can be the one start_supervisor returns.
 * @param {function(string):Promise} doUpdate  performs the actual restart (Watchtower
 *   handshake + drain + exit). MUST exit the process on success; if it RETURNS
 *   (or throws), the update did not happen (e.g. Watchtower unreachable / rejecting)
 *   and the gate retries on the next poll — it never latches permanently.
 * @param {function(Array):boolean} [allIdle]  predicate override for tests.
 * @param {number} [pollMs]  re-check cadence while an update waits on a busy Agent
 *   OR on a transient doUpdate failure.
 */
export function create_update_gate({ agents, doUpdate, allIdle = all_idle, pollMs = DEFAULT_POLL_MS } = {}) {
  let pending_image = null
  let timer = null
  let updating = false

  const list = () => (typeof agents === 'function' ? agents() : (agents ?? []))

  function stop() {
    if (timer) { clearInterval(timer); timer = null }
  }

  async function attempt() {
    if (pending_image == null || updating) return
    if (!allIdle(list())) return   // a sibling is mid-print — wait for the next tick
    updating = true
    try {
      // pending_image is deliberately NOT cleared here: doUpdate exits the process
      // on success, so we only ever return from it on FAILURE — in which case the
      // pending update must survive for the next poll to retry. Clearing it first
      // (with the latch reset only in catch) was the wedge: a doUpdate that RESOLVES
      // on Watchtower-down left updating=true and pending=null forever, so the whole
      // host's fleet could never self-update again.
      const attempted_image = pending_image
      const result = await doUpdate(attempted_image)
      if (result === 'no-update') {
        if (pending_image === attempted_image) { pending_image = null; stop() }
        return
      }
      log.warn?.('[update-gate] self-update did not restart the process — will retry')
    } catch (err) {
      log.warn?.({ err: err?.message }, '[update-gate] self-update attempt failed — will retry')
    } finally {
      // In a `finally` on purpose: this latch's whole job is "never wedge", so it
      // must reset even if the catch's own logger throws (now that supervisor mode
      // swallows unhandled rejections).
      updating = false
    }
  }

  return {
    /**
     * Record (or refresh) the pending update, try it now, and arm a poll so it
     * retries whether it's blocked by a busy sibling OR a transient doUpdate
     * failure. The poll runs (unref'd) until a successful doUpdate exits the
     * process — self-healing, never wedged.
     */
    request(image) {
      pending_image = image
      attempt()
      if (timer == null) {
        timer = setInterval(attempt, pollMs)
        if (typeof timer.unref === 'function') timer.unref()  // never hold the loop open
      }
    },
    _attempt: attempt,                 // test hook: simulate a poll tick
    _pending: () => pending_image,     // test hook
    stop,
  }
}
