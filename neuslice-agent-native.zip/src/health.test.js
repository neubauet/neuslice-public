/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * Per-Agent metrics (spec §3.2, Phase 3).
 *
 * The guarantee: with N Agents in one process, each owns its metrics and the
 * health snapshot reports them separately — no last-writer-wins. And a single
 * Agent keeps the historic flat /metrics shape so existing tooling is unaffected.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  create_metrics,
  register_metrics,
  unregister_metrics,
  snapshot,
  _reset_metrics_registry,
} from './health.js'

test('create_metrics returns isolated bundles — one Agent cannot clobber another', () => {
  const a = create_metrics()
  const b = create_metrics()
  a.counters.jobs_completed = 5
  a.live.printer_state = 'printing'
  assert.equal(b.counters.jobs_completed, 0, 'b is independent of a')
  assert.equal(b.live.printer_state, 'unknown')
})

test('single Agent → the historic flat snapshot shape (back-compat)', () => {
  _reset_metrics_registry()
  const m = create_metrics()
  m.live.adapter = 'bambu'
  m.counters.jobs_completed = 3
  register_metrics('node-a', m)

  const snap = snapshot()
  assert.equal(snap.ok, true)
  assert.equal(snap.adapter, 'bambu')        // flat, not nested under nodes[]
  assert.equal(snap.jobs_completed, 3)
  assert.equal(snap.node_id, 'node-a')       // additive
  assert.equal(snap.nodes, undefined, 'no per-node array for a single agent')
})

test('SMA-N1: two Agents report SEPARATELY — no last-writer-wins', () => {
  _reset_metrics_registry()
  const a = create_metrics(); a.live.adapter = 'bambu';   a.counters.jobs_completed = 4
  const b = create_metrics(); b.live.adapter = 'klipper'; b.counters.jobs_completed = 1; b.counters.jobs_failed = 2
  register_metrics('node-a', a)
  register_metrics('node-b', b)

  const snap = snapshot()
  assert.equal(snap.agents, 2)
  assert.equal(snap.nodes.length, 2)

  const byId = Object.fromEntries(snap.nodes.map(n => [n.node_id, n]))
  assert.equal(byId['node-a'].jobs_completed, 4)
  assert.equal(byId['node-a'].adapter, 'bambu')
  assert.equal(byId['node-b'].jobs_completed, 1)
  assert.equal(byId['node-b'].jobs_failed, 2)
  assert.equal(byId['node-b'].adapter, 'klipper')

  // …and the aggregate rolls them up, so no node's numbers hide another's.
  assert.equal(snap.aggregate.jobs_completed, 5)
  assert.equal(snap.aggregate.jobs_failed, 2)
})

test('unregister drops a stopped Agent from the snapshot', () => {
  _reset_metrics_registry()
  register_metrics('node-a', create_metrics())
  register_metrics('node-b', create_metrics())
  unregister_metrics('node-a')

  const snap = snapshot()
  // Back to one → flat shape, and it's node-b.
  assert.equal(snap.node_id, 'node-b')
  assert.equal(snap.nodes, undefined)
})

test('an empty registry still produces a valid flat snapshot', () => {
  _reset_metrics_registry()
  const snap = snapshot()
  assert.equal(snap.ok, true)
  assert.equal(snap.adapter, 'unknown')
  assert.equal(snap.node_id, null)
})
