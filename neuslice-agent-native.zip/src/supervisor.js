/*
 * supervisor.js — one process, one Agent per node (spec §3.2, Phase 3).
 *
 * Brings up N Agents in a single process instead of N containers. The three
 * things this must OWN (not discover in prod), all money- or reliability-
 * adjacent, are why the orchestration is factored out and dependency-injected so
 * every branch is unit-testable with fakes:
 *
 *   - Per-Agent failure isolation (SMA-4b): a thrown connect / bad handle / one
 *     Moonraker down must not stop the other nodes or exit the process.
 *   - Shutdown fan-out (SMA-N2): drain every Agent with a per-agent timeout, so
 *     one hung close can't block the whole drain past the stop grace period.
 *   - Update gate (SMA-N2): restart only when EVERY Agent is idle, so an
 *     UPDATE_AVAILABLE never exits the process mid-print on a sibling.
 */

import log from './logger.js'

const DEFAULT_SHUTDOWN_TIMEOUT_MS = 10_000

/**
 * Start one Agent per node config.
 *
 * Injected deps keep this pure enough to test:
 *   connect(cfg, opts) → { adapter, handle }                       per-node connect
 *   buildAgent({ token, node_id, api_url, adapter, handle }) → Agent
 *   fetchNodeOpts?(cfg) → opts                                     optional; may reject
 *
 * @returns {Promise<Array>} the Agents that started (failed nodes are omitted,
 *   never thrown — SMA-4b boot-time isolation).
 */
export async function start_supervisor({ configs, api_url, connect, buildAgent, fetchNodeOpts }) {
  const agents = []
  for (const cfg of configs ?? []) {
    try {
      let opts = {}
      if (fetchNodeOpts) {
        try {
          opts = (await fetchNodeOpts(cfg)) ?? {}
        } catch (err) {
          // Non-fatal — the node can run on adapter defaults, same as the single
          // agent's index.js does when the config fetch fails.
          log.warn?.({ node_id: cfg.node_id, err: err.message }, '[supervisor] node opts fetch failed — using defaults')
        }
      }

      const { adapter, handle } = await connect(cfg, opts)
      const agent = buildAgent({ token: cfg.token, node_id: cfg.node_id, api_url, adapter, handle })
      agent.start()
      agents.push(agent)
      log.info?.({ node_id: cfg.node_id, adapter: adapter?.name }, '[supervisor] node started')
    } catch (err) {
      // SMA-4b (boot-time): isolate the failure, keep the rest coming up.
      log.error?.({ node_id: cfg.node_id, err: err.message },
        '[supervisor] node failed to start — continuing with the rest')
    }
  }
  log.info?.({ started: agents.length, configured: (configs ?? []).length }, '[supervisor] boot complete')
  return agents
}

/**
 * Drain every Agent (SMA-N2). `Promise.allSettled` + a per-agent timeout: a
 * single hung close resolves via its timeout and the drain still completes, so
 * the stop grace period is never blocked by one bad agent.
 */
export async function shutdown_all(agents, signal, { timeoutMs = DEFAULT_SHUTDOWN_TIMEOUT_MS } = {}) {
  await Promise.allSettled((agents ?? []).map(a => shutdown_one(a, signal, timeoutMs)))
}

function shutdown_one(agent, signal, timeoutMs) {
  let timer
  const timed_out = new Promise(resolve => {
    timer = setTimeout(() => {
      log.warn?.({ node_id: agent?.node_id }, '[supervisor] agent shutdown timed out — proceeding')
      resolve()
    }, timeoutMs)
  })
  const drained = Promise.resolve()
    .then(() => agent.shutdown(signal))
    .catch(err => log.warn?.({ node_id: agent?.node_id, err: err?.message }, '[supervisor] agent shutdown errored'))
  return Promise.race([drained, timed_out]).finally(() => clearTimeout(timer))
}

/**
 * The update gate's predicate (SMA-N2). The supervisor restarts the process for
 * an UPDATE_AVAILABLE only when this is true — no Agent mid-print. An Agent with
 * no is_busy() is treated as idle (back-compat).
 */
export function all_idle(agents) {
  return (agents ?? []).every(a => typeof a.is_busy === 'function' ? !a.is_busy() : true)
}

/**
 * Reconcile the local config store against the owner's backend node list on boot
 * (spec §3.4 / SMA-6 / R-6). Pure — returns the three-way split by node_id so the
 * caller can LOG orphans; drift is an ops signal, never fatal. A backend node's
 * id may be carried as `node_id` or `id`.
 *
 *   matched       config entry ↔ backend node (healthy)
 *   config_only   a config entry with no backend node (stale/typo/deleted node —
 *                 its Agent will fail WS auth; surfaced instead of silently retrying)
 *   backend_only  a backend node with no local config (a registered printer this
 *                 host won't serve — offline in the dashboard until a config lands)
 */
export function reconcile_configs(configs, backend_nodes) {
  const cfg_ids = new Set((configs ?? []).map(c => c.node_id).filter(Boolean))
  const backend_ids = new Set((backend_nodes ?? []).map(n => n?.node_id ?? n?.id).filter(Boolean))
  return {
    matched:      [...cfg_ids].filter(id => backend_ids.has(id)),
    config_only:  [...cfg_ids].filter(id => !backend_ids.has(id)),
    backend_only: [...backend_ids].filter(id => !cfg_ids.has(id)),
  }
}

/** Reconcile + log drift (SMA-6/R-6). Non-fatal; returns the split for callers/tests. */
export function log_config_drift(configs, backend_nodes) {
  const split = reconcile_configs(configs, backend_nodes)
  if (split.config_only.length)
    log.warn?.({ node_ids: split.config_only },
      '[supervisor] config entries with no backend node — check node_id / re-register')
  if (split.backend_only.length)
    log.warn?.({ node_ids: split.backend_only },
      '[supervisor] registered nodes with no local config — this host will not serve them')
  if (!split.config_only.length && !split.backend_only.length)
    log.info?.({ nodes: split.matched.length }, '[supervisor] config ↔ backend reconciled, no drift')
  return split
}
