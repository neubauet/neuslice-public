/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

import { api_base } from './api_base.js'

/**
 * Owner/operator-controlled settings that live on the node document and reach
 * the agent over the API, rather than through the container's environment.
 *
 * The parsing lived inline in two places in index.js and now needs to run in a
 * third (the periodic refresh in agent.js). Three copies of "which fields count
 * and what shape must they be" is how one of them quietly stops matching the
 * backend.
 */

/**
 * Map a node document to adapter opts. Only well-formed values are carried:
 * anything missing or wrong-typed is simply absent, which leaves the adapter's
 * own default in charge rather than overriding it with a bad value.
 *
 * @param {object} data node document as returned by GET /nodes/:id
 */
export function parse_node_opts(data) {
  const opts = {}

  if (Array.isArray(data?.default_filament_types) && data.default_filament_types.length > 0) {
    opts.defaultFilamentTypes = data.default_filament_types
  }

  // Only a real boolean is a decision. null/undefined mean "not set" and must
  // not be coerced to false, or a node with no opinion would override config
  // set locally on the machine.
  if (typeof data?.cfs_inventory === 'boolean') {
    opts.cfsInventory = data.cfs_inventory
  }

  return opts
}

/**
 * Fetch this node's settings, authenticated with the node's own token.
 *
 * Throws on a failed fetch rather than returning empty opts: an empty object is
 * indistinguishable from "the owner cleared every setting", and callers must be
 * able to tell a network blip from a real change before acting on it.
 *
 * @param {string} api_url  the backend ORIGIN, e.g. https://host — api_base()
 *                          adds the /api/v1 prefix the REST routes live under
 * @param {object} [deps]   injectable fetch for tests
 */
export async function fetch_node_opts(api_url, node_id, token, { fetchImpl = fetch, timeout_ms = 8000 } = {}) {
  const res = await fetchImpl(`${api_base(api_url)}/nodes/${node_id}`, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(timeout_ms),
  })
  if (!res.ok) throw new Error(`node opts fetch failed: ${res.status}`)
  return parse_node_opts(await res.json())
}
