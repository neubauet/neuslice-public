// Release identity is compiled in. Backend notifications never supply a download URL.
export const FEED_URL = 'https://storage.googleapis.com/neuslice_agent/win/'
export const PACK_ID = 'NeuSliceAgent'
export const PINNED_PUBLISHER = 'CN=NeuSlice LLC, O=NeuSlice LLC, L=Knoxville, S=Tennessee, C=US'
export const SIGNING_THUMBPRINT = 'EB608765EA2AB793EC93EE74B1D2F7272C602305'

export function numeric_version(value) {
  return typeof value === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value)
    && value.split('.').every(p => Number.isSafeInteger(Number(p)))
}

export function is_forward_version(candidate, current) {
  if (!numeric_version(candidate) || !numeric_version(current)) return false
  const a = candidate.split('.').map(Number), b = current.split('.').map(Number)
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i]
  return false
}

export function publisher_matches(sig, pinned) {
  if (sig?.status !== 'Valid' || typeof pinned !== 'string' || !pinned.trim()) return false
  const hex = s => String(s ?? '').replace(/\s/g, '').toUpperCase()
  if (/^[A-Fa-f0-9\s]+$/.test(pinned)) return hex(sig.thumbprint) === hex(pinned)
  // No CN substring matching: another organization's similarly named certificate is not ours.
  return String(sig.subject ?? '').trim() === pinned.trim()
}

export function validate_release_asset(asset) {
  if (!asset || asset.PackageId !== PACK_ID || asset.Type !== 'Full' || !numeric_version(asset.Version)
      || asset.FileName !== `${PACK_ID}-${asset.Version}-full.nupkg`
      || !/^[a-fA-F0-9]{64}$/.test(asset.SHA256 ?? '')
      || !Number.isSafeInteger(asset.Size) || asset.Size <= 0 || asset.Size > 512 * 1024 * 1024) {
    throw new Error('Invalid Windows release metadata')
  }
  return asset
}
