/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * bambuddy_status.js — read-only detection of this node's Bambuddy.
 *
 * Answers two questions the owner portal needs, and nothing else:
 *
 *   1. Is this node's Bambuddy data at risk?  Bambuddy's DATA_DIR is
 *      /app/data, but our compose mounted the named volume at /data until
 *      2026-09-04. On those nodes the volume is empty and the database,
 *      archives and secrets live in the container's writable layer, which
 *      Docker discards on any recreate. `legacy_data_mount` is that exposure.
 *
 *   2. Can it be fixed from here?  Only when the agent can both SEE the
 *      container locally and is actually talking to that same container.
 *      A node pointed at a Bambuddy on another host (Path B) must never be
 *      offered a one-click upgrade — the agent would migrate a container that
 *      is not the one serving its prints, or find none at all.
 *
 * Strictly read-only: one inspect and two GETs. It never stops, creates or
 * recreates anything. Acting on what it finds is a separate, explicit step.
 */
import fetch from 'node-fetch'
import log from './logger.js'

// Bambuddy's own data directory, from the image's DATA_DIR env. The volume has
// to land exactly here; anything else means the data is in the writable layer.
export const CORRECT_DATA_MOUNT = '/app/data'
export const LEGACY_DATA_MOUNT = '/data'

// Hosts that can only mean "the Bambuddy this agent manages". `bambuddy` is the
// compose service name (Path A); the rest are the loopback forms an owner may
// have typed. A LAN IP is deliberately NOT in this list even when it happens to
// be this machine's own address: from inside a container we cannot tell that
// apart from a Bambuddy on another host, and guessing wrong offers a
// destructive button on the wrong machine. Being wrongly conservative only
// hides a button; being wrongly permissive migrates someone else's printer.
const LOCAL_HOSTS = new Set([
  'bambuddy',
  'localhost',
  '127.0.0.1',
  '::1',
  'host.docker.internal',
])

/**
 * Is BAMBUDDY_BASE_URL pointing at a Bambuddy this agent could manage?
 * @param {string|null|undefined} base_url
 * @returns {boolean}
 */
export function is_local_bambuddy_url(base_url) {
  if (typeof base_url !== 'string' || !base_url.trim()) return false
  let host
  try {
    host = new URL(base_url.trim()).hostname
  } catch {
    return false
  }
  // URL() keeps IPv6 literals in brackets — strip them so '::1' matches.
  if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1)
  return LOCAL_HOSTS.has(host.toLowerCase())
}

/**
 * Pull the Bambuddy data mount out of a Docker inspect response.
 *
 * A container with neither data path (an owner who bind-mounted somewhere
 * else entirely) is reported as unknown rather than legacy — we only flag an
 * exposure we can actually prove.
 *
 * @param {object|null} inspect  parsed GET /containers/{id}/json body
 * @returns {{destination: string|null, volume: string|null, type: string|null, legacy: boolean}}
 */
export function parse_data_mount(inspect) {
  const none = { destination: null, volume: null, type: null, legacy: false }
  if (!inspect || typeof inspect !== 'object') return none
  const mounts = Array.isArray(inspect.Mounts) ? inspect.Mounts : []

  // Prefer the correct mount if BOTH somehow exist: a container carrying
  // /app/data is already migrated whatever else is attached to it.
  const correct = mounts.find(m => m && m.Destination === CORRECT_DATA_MOUNT)
  if (correct) {
    return {
      destination: CORRECT_DATA_MOUNT,
      volume: correct.Name ?? null,
      type: correct.Type ?? null,
      legacy: false,
    }
  }
  const legacy = mounts.find(m => m && m.Destination === LEGACY_DATA_MOUNT)
  if (legacy) {
    return {
      destination: LEGACY_DATA_MOUNT,
      volume: legacy.Name ?? null,
      type: legacy.Type ?? null,
      // Only a NAMED volume is the bug this flags. A bind mount at /data is
      // someone's deliberate layout, and its data is on the host either way.
      legacy: (legacy.Type ?? null) === 'volume',
    }
  }
  return none
}

/**
 * Read the image reference a container was created from.
 * @param {object|null} inspect
 * @returns {string|null}
 */
export function parse_image(inspect) {
  const image = inspect && inspect.Config ? inspect.Config.Image : null
  return typeof image === 'string' && image.trim() ? image.trim() : null
}

/**
 * Build the status object the backend stores. Kept pure so the decision logic
 * is testable without Docker or a live Bambuddy.
 *
 * @param {object} parts
 * @param {boolean} parts.url_is_local      is_local_bambuddy_url(BAMBUDDY_BASE_URL)
 * @param {object|null} parts.inspect       docker inspect body, or null if absent
 * @param {object|null} parts.version_info  Bambuddy /api/v1/system/info body
 * @param {object|null} parts.update_info   Bambuddy /api/v1/updates/check body
 */
export function build_status({ url_is_local, inspect, version_info, update_info }) {
  const container_present = !!inspect
  const mount = parse_data_mount(inspect)

  // The gate for offering a one-click upgrade. BOTH must hold: we can see a
  // local container, and the Bambuddy we actually talk to is that container.
  // Either alone is not enough — a Path B node can have a stale local bambuddy
  // container sitting stopped from an earlier install.
  const manageable = container_present && url_is_local

  return {
    container_present,
    // Reported separately so the portal can explain WHY there is no button
    // instead of silently omitting it.
    url_is_local,
    manageable,
    image: parse_image(inspect),
    running: inspect && inspect.State ? (inspect.State.Running ?? null) : null,
    data_mount: mount.destination,
    data_volume: mount.volume,
    data_mount_type: mount.type,
    legacy_data_mount: mount.legacy,
    // migration_needed is the exposure; migration_possible is whether THIS
    // node can act on it. An at-risk container we cannot reach is a support
    // conversation, not a button.
    migration_needed: mount.legacy,
    migration_possible: manageable && mount.legacy,
    version: version_info && version_info.app ? (version_info.app.version ?? null) : null,
    latest_version: update_info ? (update_info.latest_version ?? null) : null,
    update_available: update_info ? (update_info.update_available ?? null) : null,
    checked_at: new Date().toISOString(),
  }
}

/**
 * Run the detection. Every call is best-effort: a node with no Docker access,
 * no local container, or an unreachable Bambuddy still returns a usable object
 * rather than throwing into the heartbeat path.
 *
 * @param {object} deps
 * @param {(method: string, path: string) => Promise<{status:number, body:any}>} deps.docker_request
 * @param {string|null} deps.base_url     BAMBUDDY_BASE_URL
 * @param {string} [deps.container_name]  defaults to the compose service name
 * @param {Function} [deps.fetch_impl]
 */
export async function detect_bambuddy({
  docker_request,
  base_url,
  container_name = 'bambuddy',
  fetch_impl = fetch,
}) {
  const url_is_local = is_local_bambuddy_url(base_url)

  let inspect = null
  try {
    const res = await docker_request('GET', '/containers/' + encodeURIComponent(container_name) + '/json')
    inspect = res && res.body ? res.body : null
  } catch (err) {
    // A 404 is the ordinary "this node runs no Bambuddy container" answer, not
    // a fault. Anything else (no socket, proxy denies it) is logged and treated
    // the same way — detection must never break the heartbeat that carries it.
    const msg = err && err.message ? err.message : ''
    if (!/404/.test(msg)) {
      log.debug?.({ err: msg }, 'Bambuddy detection: docker inspect unavailable')
    }
  }

  let version_info = null
  let update_info = null
  if (base_url) {
    const root = base_url.replace(/\/+$/, '')
    const probes = [
      ['/api/v1/system/info', v => { version_info = v }],
      ['/api/v1/updates/check', v => { update_info = v }],
    ]
    for (const [path, assign] of probes) {
      try {
        const res = await fetch_impl(root + path, { timeout: 5000 })
        if (res.ok) assign(await res.json())
      } catch (err) {
        log.debug?.({ path, err: err && err.message }, 'Bambuddy detection: version probe failed')
      }
    }
  }

  return build_status({ url_is_local, inspect, version_info, update_info })
}
