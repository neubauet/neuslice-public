/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * This source file is part of the NeuSlice platform. Unauthorized
 * copying, distribution, modification, public display, public
 * performance, or other use of this file, in whole or in part, in
 * any form or by any means, without the express prior written
 * permission of Tommy Neubauer, is strictly prohibited and may
 * constitute infringement of one or more pending U.S. patent
 * applications, copyrights, and trade-secret rights.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * bambuddy_status.js — read-only detection of this node's Bambuddy.
 *
 * Answers two questions the owner portal needs, and nothing else:
 *
 *   1. Is this node's Bambuddy data at risk?  Bambuddy's DATA_DIR is
 *      /app/data, but our compose mounted the named volume at /data until
 *      2026-09-04. On those nodes the volume is empty and the database,
 *      archives and secrets live in the container's writable layer, which
 *      Docker discards on any recreate. `legacy_data_mount` is that exposure.
 *
 *   2. Can it be fixed from here?  Only when the agent can both SEE the
 *      container locally and is actually talking to that same container.
 *      A node pointed at a Bambuddy on another host (Path B) must never be
 *      offered a one-click upgrade — the agent would migrate a container that
 *      is not the one serving its prints, or find none at all.
 *
 * Strictly read-only: one inspect and two GETs. It never stops, creates or
 * recreates anything. Acting on what it finds is a separate, explicit step.
 */
import fetch from 'node-fetch'
import log from './logger.js'

// Bambuddy's own data directory, from the image's DATA_DIR env. The volume has
// to land exactly here; anything else means the data is in the writable layer.
export const CORRECT_DATA_MOUNT = '/app/data'
export const LEGACY_DATA_MOUNT = '/data'

// Hosts that can only mean "the Bambuddy this agent manages". `bambuddy` is the
// compose service name (Path A); the rest are the loopback forms an owner may
// have typed. A LAN IP is deliberately NOT in this list: from inside a container
// we cannot tell this machine's own LAN address apart from another host's.
//
// This used to VETO the upgrade, which was wrong. An agent that can inspect a
// local `bambuddy` container AND is talking to a live Bambuddy has strong
// evidence, just not proof, and hiding the action behind an unactionable
// warning is not safety - it is a dead end with a scary message on it. So this
// list now decides whether we can VERIFY co-location on our own
// (`url_is_local`); when we cannot, the owner is asked to confirm what the
// upgrade will act on, and that confirmation is carried explicitly all the way
// to the agent. See `needs_confirmation` below.
const LOCAL_HOSTS = new Set([
  'bambuddy',
  'localhost',
  '127.0.0.1',
  '::1',
  'host.docker.internal',
])

/**
 * Is BAMBUDDY_BASE_URL pointing at a Bambuddy this agent could manage?
 * @param {string|null|undefined} base_url
 * @returns {boolean}
 */
export function is_local_bambuddy_url(base_url) {
  if (typeof base_url !== 'string' || !base_url.trim()) return false
  let host
  try {
    host = new URL(base_url.trim()).hostname
  } catch {
    return false
  }
  // URL() keeps IPv6 literals in brackets — strip them so '::1' matches.
  if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1)
  return LOCAL_HOSTS.has(host.toLowerCase())
}

/**
 * Pull the Bambuddy data mount out of a Docker inspect response.
 *
 * A container with neither data path (an owner who bind-mounted somewhere
 * else entirely) is reported as unknown rather than legacy — we only flag an
 * exposure we can actually prove.
 *
 * @param {object|null} inspect  parsed GET /containers/{id}/json body
 * @returns {{destination: string|null, volume: string|null, type: string|null, legacy: boolean}}
 */
export function parse_data_mount(inspect) {
  const none = { destination: null, volume: null, type: null, legacy: false }
  if (!inspect || typeof inspect !== 'object') return none
  const mounts = Array.isArray(inspect.Mounts) ? inspect.Mounts : []

  // Prefer the correct mount if BOTH somehow exist: a container carrying
  // /app/data is already migrated whatever else is attached to it.
  const correct = mounts.find(m => m && m.Destination === CORRECT_DATA_MOUNT)
  if (correct) {
    return {
      destination: CORRECT_DATA_MOUNT,
      volume: correct.Name ?? null,
      type: correct.Type ?? null,
      legacy: false,
    }
  }
  const legacy = mounts.find(m => m && m.Destination === LEGACY_DATA_MOUNT)
  if (legacy) {
    return {
      destination: LEGACY_DATA_MOUNT,
      volume: legacy.Name ?? null,
      type: legacy.Type ?? null,
      // Only a NAMED volume is the bug this flags. A bind mount at /data is
      // someone's deliberate layout, and its data is on the host either way.
      legacy: (legacy.Type ?? null) === 'volume',
    }
  }
  return none
}

/**
 * Read the image reference a container was created from.
 * @param {object|null} inspect
 * @returns {string|null}
 */
export function parse_image(inspect) {
  const image = inspect && inspect.Config ? inspect.Config.Image : null
  return typeof image === 'string' && image.trim() ? image.trim() : null
}

/**
 * Build the status object the backend stores. Kept pure so the decision logic
 * is testable without Docker or a live Bambuddy.
 *
 * @param {object} parts
 * @param {boolean} parts.url_is_local      is_local_bambuddy_url(BAMBUDDY_BASE_URL)
 * @param {object|null} parts.inspect       docker inspect body, or null if absent
 * @param {object|null} parts.version_info  Bambuddy /api/v1/system/info body
 * @param {object|null} parts.update_info   Bambuddy /api/v1/updates/check body
 */
export function build_status({ url_is_local, inspect, version_info, update_info, reachable = false, base_url = null }) {
  const container_present = !!inspect
  const mount = parse_data_mount(inspect)

  // The gate for offering a one-click upgrade: we can see a local container to
  // act on, AND we are actually talking to a live Bambuddy. `reachable` is
  // load-bearing — without it a node whose Bambuddy is unreachable would be
  // offered an upgrade whose final health check could never pass, reporting
  // failure for work that succeeded.
  //
  // Co-location is NOT required here, only verified where possible. When
  // url_is_local is false the action is still offered, but only behind an
  // explicit confirmation naming what it will touch.
  const manageable = container_present && reachable

  return {
    container_present,
    // Reported separately so the portal can explain WHY there is no button
    // instead of silently omitting it.
    url_is_local,
    manageable,
    image: parse_image(inspect),
    running: inspect && inspect.State ? (inspect.State.Running ?? null) : null,
    data_mount: mount.destination,
    data_volume: mount.volume,
    data_mount_type: mount.type,
    legacy_data_mount: mount.legacy,
    // migration_needed is the exposure; migration_possible is whether THIS
    // node can act on it. An at-risk container we cannot reach is a support
    // conversation, not a button.
    migration_needed: mount.legacy,
    migration_possible: manageable && mount.legacy,
    // True when we could not prove for ourselves that the container we can see
    // is the Bambuddy this node prints through. The action stays available; the
    // owner is asked to confirm it, and that answer travels to the agent.
    needs_confirmation: manageable && !url_is_local,
    reachable,
    // The address this node prints through. Owner-scoped data (it never enters
    // the public projection) and it is what the confirmation has to name — an
    // owner cannot answer "is this the right Bambuddy?" without seeing it.
    base_url,
    version: version_info && version_info.app ? (version_info.app.version ?? null) : null,
    latest_version: update_info ? (update_info.latest_version ?? null) : null,
    update_available: update_info ? (update_info.update_available ?? null) : null,
    checked_at: new Date().toISOString(),
  }
}

/**
 * Run the detection. Every call is best-effort: a node with no Docker access,
 * no local container, or an unreachable Bambuddy still returns a usable object
 * rather than throwing into the heartbeat path.
 *
 * @param {object} deps
 * @param {(method: string, path: string) => Promise<{status:number, body:any}>} deps.docker_request
 * @param {string|null} deps.base_url     BAMBUDDY_BASE_URL
 * @param {string} [deps.container_name]  defaults to the compose service name
 * @param {Function} [deps.fetch_impl]
 */
export async function detect_bambuddy({
  docker_request,
  base_url,
  container_name = 'bambuddy',
  fetch_impl = fetch,
}) {
  const url_is_local = is_local_bambuddy_url(base_url)

  let inspect = null
  try {
    const res = await docker_request('GET', '/containers/' + encodeURIComponent(container_name) + '/json')
    inspect = res && res.body ? res.body : null
  } catch (err) {
    // A 404 is the ordinary "this node runs no Bambuddy container" answer, not
    // a fault. Anything else (no socket, proxy denies it) is logged and treated
    // the same way — detection must never break the heartbeat that carries it.
    const msg = err && err.message ? err.message : ''
    // A 404 is the ordinary "no Bambuddy container here" answer. Anything else
    // means we cannot see a container that may well be running, which silently
    // removes the card — so it is a warning, not a debug line nobody will read
    // at the default log level.
    if (/404/.test(msg)) {
      log.debug?.({ err: msg }, 'Bambuddy detection: no bambuddy container on this node')
    } else {
      log.warn?.({ err: msg, container_name }, 'Bambuddy detection: cannot inspect the Bambuddy container — the portal will show no Bambuddy for this node')
    }
  }

  let version_info = null
  let update_info = null
  let reachable = false
  if (base_url) {
    const root = base_url.replace(/\/+$/, '')
    const probes = [
      ['/api/v1/system/info', v => { version_info = v }],
      ['/api/v1/updates/check', v => { update_info = v }],
    ]
    for (const [path, assign] of probes) {
      try {
        const res = await fetch_impl(root + path, { timeout: 5000 })
        if (res.ok) {
          assign(await res.json())
          // system/info answering is what "we are talking to a live Bambuddy"
          // means. updates/check is best-effort on top of it.
          if (path.endsWith('/system/info')) reachable = true
        }
      } catch (err) {
        log.debug?.({ path, err: err && err.message }, 'Bambuddy detection: version probe failed')
      }
    }
  }

  if (inspect && !url_is_local) {
    log.warn?.({ base_url, container_name },
      'Bambuddy detection: a local Bambuddy container is visible but the configured URL is not provably this machine — the upgrade will ask the owner to confirm')
  }
  return build_status({ url_is_local, inspect, version_info, update_info, reachable, base_url: base_url ?? null })
}
