/*
 * stop_sentinel.js — file-sentinel graceful-stop bridge for the native Windows
 * service runtime (spec §3.5 / SMA-N2 / Procedure B2).
 *
 * A native Windows service is stopped by the Service Control Manager, which does
 * NOT deliver a POSIX signal Node can catch — and WinSW kills the process by
 * default, which would abort an in-flight print. So the WinSW <stopexecutable>
 * helper (service_stop.js) writes a small sentinel file into the (ACL-locked)
 * config dir, and the running agent watches for it and translates it into the very
 * same graceful drain the SIGTERM path uses (shutdown_all, then exit). WinSW then
 * waits for the process to exit on its own within <stoptimeout>.
 *
 * File-sentinel (not a network endpoint) was chosen to add ZERO inbound surface —
 * it reuses the config dir the store already locks down (SMA-7). The sentinel is a
 * NON-.json name so read_node_configs() never picks it up as a node config.
 *
 * Cross-platform pure fs, so it unit-tests on the Linux CI runner even though it
 * only fires under a Windows service.
 */

import fs from 'node:fs'
import path from 'node:path'
import { default_config_dir } from './config_store.js'
import log from './logger.js'

const SENTINEL_NAME = '.stop-request'

/** The agreed sentinel path — the SAME function the helper and the agent call, so
 *  they can never disagree. Overridable via NEUSLICE_STOP_SENTINEL. */
export function sentinel_path(dir = default_config_dir()) {
  const override = process.env.NEUSLICE_STOP_SENTINEL
  return override && override.trim() ? override : path.join(dir, SENTINEL_NAME)
}

/** Helper side (service_stop.js): ask the running agent to drain. Best-effort. */
export function request_stop(dir = default_config_dir()) {
  const file = sentinel_path(dir)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, `${new Date().toISOString()} stop requested\n`)
  return file
}

/** Remove the sentinel if present (never throws). */
export function clear_stop_sentinel(dir = default_config_dir()) {
  const file = sentinel_path(dir)
  try { fs.rmSync(file, { force: true }) } catch { /* already gone */ }
  return file
}

/**
 * Agent side: poll for the sentinel and, when it APPEARS, fire onStop exactly once.
 *
 * A sentinel already present at start is a stale leftover (a prior crash, or the
 * stop that preceded this restart) — it is cleared on the way in and does NOT
 * trigger a stop, so only a sentinel written AFTER this process started counts.
 * Polling (not fs.watch) is deliberate: fs.watch is unreliable on Windows, and a
 * 1s poll is far faster than a service stop needs.
 *
 * @param {object}   o
 * @param {string}   [o.dir]     config dir (defaults to default_config_dir()).
 * @param {function} o.onStop    called once with 'SERVICE_STOP' when the sentinel appears.
 * @param {number}   [o.pollMs]  poll cadence.
 * @returns {{ stop: function }} call stop() to tear the watcher down.
 */
export function start_stop_watch({ dir = default_config_dir(), onStop, pollMs = 1000 } = {}) {
  const file = sentinel_path(dir)
  // Clear any stale sentinel so a leftover can't instantly stop a fresh boot.
  try { fs.rmSync(file, { force: true }) } catch { /* ignore */ }

  let fired = false
  const timer = setInterval(() => {
    if (fired) return
    let exists = false
    try { exists = fs.existsSync(file) } catch { exists = false }
    if (!exists) return
    fired = true
    clearInterval(timer)
    // Remove it so a subsequent restart doesn't re-trigger on the same file.
    try { fs.rmSync(file, { force: true }) } catch { /* ignore */ }
    log.info?.({ file }, '[service] stop sentinel detected — draining gracefully')
    Promise.resolve()
      .then(() => onStop?.('SERVICE_STOP'))
      .catch(err => log.warn?.({ err: err?.message }, '[service] stop handler error'))
  }, pollMs)
  if (typeof timer.unref === 'function') timer.unref()   // never hold the loop open

  return { stop() { clearInterval(timer) } }
}
