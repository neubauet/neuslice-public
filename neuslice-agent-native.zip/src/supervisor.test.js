/*
 * Copyright (c) 2024-2026 Tommy Neubauer. All rights reserved.
 *
 * NeuSlice Proprietary and Confidential. Patent Pending.
 *
 * See LICENSE and NOTICE in the repository root for full terms.
 * Contact: tommy@neuslice.com
 */

/*
 * The supervisor orchestration (spec §3.2): SMA-4 (multiplex), SMA-4b (failure
 * isolation — the load-bearing one), SMA-5 (mixed adapters), SMA-N2 (shutdown
 * fan-out + per-agent timeout, update-gate predicate). All with fake agents /
 * adapters, no fetch or WebSocket.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { start_supervisor, shutdown_all, all_idle, reconcile_configs, log_config_drift } from './supervisor.js'

function fakeAgent(node_id, { busy = false } = {}) {
  return {
    node_id,
    started: false,
    shutdownCalled: false,
    start() { this.started = true },
    is_busy() { return busy },
    async shutdown() { this.shutdownCalled = true },
  }
}

test('SMA-4 / SMA-5: one Agent per config, mixed adapters, each connected + started', async () => {
  const connected = []
  const agents = await start_supervisor({
    configs: [
      { node_id: 'a', token: 't', adapter: 'bambu' },
      { node_id: 'b', token: 't', adapter: 'klipper', config: { host: 'h' } },
    ],
    api_url: 'http://x',
    connect: async (cfg) => { connected.push(cfg.adapter); return { adapter: { name: cfg.adapter }, handle: {} } },
    buildAgent: ({ node_id }) => fakeAgent(node_id),
  })
  assert.deepEqual(connected, ['bambu', 'klipper'])
  assert.equal(agents.length, 2)
  assert.ok(agents.every(a => a.started), 'every agent was started')
})

test('SMA-4b: a node whose connect throws does not stop the others or throw', async () => {
  const agents = await start_supervisor({
    configs: [
      { node_id: 'bad',  token: 't', adapter: 'klipper' },
      { node_id: 'good', token: 't', adapter: 'bambu' },
    ],
    api_url: 'http://x',
    connect: async (cfg) => {
      if (cfg.node_id === 'bad') throw new Error('Moonraker down')
      return { adapter: { name: cfg.adapter }, handle: {} }
    },
    buildAgent: ({ node_id }) => fakeAgent(node_id),
  })
  assert.deepEqual(agents.map(a => a.node_id), ['good'], 'the good node came up; the bad one was isolated')
})

test('a failing per-node opts fetch is non-fatal — the node still starts on defaults', async () => {
  let optsSeen
  const agents = await start_supervisor({
    configs: [{ node_id: 'a', token: 't' }],
    api_url: 'http://x',
    fetchNodeOpts: async () => { throw new Error('backend 500') },
    connect: async (_cfg, opts) => { optsSeen = opts; return { adapter: { name: 'bambu' }, handle: {} } },
    buildAgent: ({ node_id }) => fakeAgent(node_id),
  })
  assert.equal(agents.length, 1)
  assert.deepEqual(optsSeen, {}, 'connect ran with default opts')
})

test('SMA-N2: shutdown_all drains every agent', async () => {
  const agents = [fakeAgent('a'), fakeAgent('b')]
  await shutdown_all(agents, 'SIGTERM', { timeoutMs: 1000 })
  assert.ok(agents.every(a => a.shutdownCalled), 'both agents drained')
})

test('SMA-N2: one hung agent shutdown times out without blocking the drain', async () => {
  const hung = { node_id: 'hung', shutdown: () => new Promise(() => {}) }  // never resolves
  const ok = fakeAgent('ok')
  const started = Date.now()
  await shutdown_all([hung, ok], 'SIGTERM', { timeoutMs: 50 })
  assert.ok(Date.now() - started < 2000, 'the drain completed via the per-agent timeout, not blocked')
  assert.ok(ok.shutdownCalled, 'the healthy agent still drained')
})

test('all_idle: true when none busy; false when one is printing; no is_busy() ⇒ idle', () => {
  assert.equal(all_idle([fakeAgent('a'), fakeAgent('b')]), true)
  assert.equal(all_idle([fakeAgent('a'), fakeAgent('b', { busy: true })]), false)
  assert.equal(all_idle([{ node_id: 'legacy' }]), true)
})

// ── reconcile_configs (SMA-6 / R-6) ───────────────────────────────────────────

test('reconcile_configs: matched / config-only / backend-only split by node_id', () => {
  const configs = [{ node_id: 'a' }, { node_id: 'b' }, { node_id: 'ghost' }]
  const backend = [{ node_id: 'a' }, { id: 'b' }, { node_id: 'unmanaged' }]  // id or node_id
  const split = reconcile_configs(configs, backend)
  assert.deepEqual(split.matched.sort(), ['a', 'b'])
  assert.deepEqual(split.config_only, ['ghost'])        // config points at a node the backend doesn't have
  assert.deepEqual(split.backend_only, ['unmanaged'])   // registered node this host has no config for
})

test('reconcile_configs: empty inputs never throw', () => {
  assert.deepEqual(reconcile_configs([], []), { matched: [], config_only: [], backend_only: [] })
  assert.deepEqual(reconcile_configs(undefined, undefined), { matched: [], config_only: [], backend_only: [] })
})

test('log_config_drift returns the split (and does not throw while logging)', () => {
  const split = log_config_drift([{ node_id: 'a' }, { node_id: 'ghost' }], [{ node_id: 'a' }, { id: 'x' }])
  assert.deepEqual(split.matched, ['a'])
  assert.deepEqual(split.config_only, ['ghost'])
  assert.deepEqual(split.backend_only, ['x'])
})
